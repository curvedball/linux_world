
modprobe cfg80211
insmod rtl8812au.ko   ###test ok in tirmed linux4.12.4z

