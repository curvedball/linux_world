


#ifndef _NORM_ENCODER
#define _NORM_ENCODER



#include "protokit.h"  // protolib stuff



class NormEncoder
{
public:
    virtual ~NormEncoder();

    virtual bool Init(unsigned int numData, unsigned int numParity, UINT16 vectorSize) = 0;
    virtual void Destroy() = 0;

    virtual void Encode(unsigned int segmentId, const char *dataVector, char **parityVectorList) = 0;
};




class NormDecoder
{
public:
    virtual ~NormDecoder();

    virtual bool Init(unsigned int numData, unsigned int numParity, UINT16 vectorSize) = 0;
    virtual void Destroy() = 0;

    virtual int Decode(char** vectorList, unsigned int numData,  unsigned int erasureCount, unsigned int* erasureLocs) = 0;
};



#endif



