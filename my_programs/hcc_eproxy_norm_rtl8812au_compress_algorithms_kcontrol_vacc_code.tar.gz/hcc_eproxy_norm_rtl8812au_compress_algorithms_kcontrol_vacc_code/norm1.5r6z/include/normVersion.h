
 
#ifndef _NORM_VERSION
#define _NORM_VERSION

#define VERSION "1.5r6"

#endif
        
