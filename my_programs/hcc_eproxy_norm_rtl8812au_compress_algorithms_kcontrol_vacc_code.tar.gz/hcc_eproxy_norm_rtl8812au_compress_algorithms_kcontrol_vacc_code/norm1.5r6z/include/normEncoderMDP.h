
 
#ifndef _NORM_ENCODER_MDP
#define _NORM_ENCODER_MDP

#include "normEncoder.h"


class NormEncoderMDP : public NormEncoder
{
    // Methods
    public:
	    NormEncoderMDP();
	    ~NormEncoderMDP();
	    bool Init(unsigned int numData, unsigned int numParity, UINT16 vectorSize);
        void Destroy();
		
        bool IsReady()
		{
			return (bool)(gen_poly != NULL);
		}

        // "Encode" MUST be called in order of source vector0, vector1, vector2, etc
	    void Encode(unsigned int segmentId, const char *dataVector, char **parityVectorList);
	
    private:
	    bool CreateGeneratorPolynomial();
    
    // Members
	    unsigned int    npar;	      // No. of parity packets (n-k)
	    UINT16		    vector_size;  // Size of biggest vector to encode
	    unsigned char*  gen_poly;     // Ptr to generator polynomial
	    unsigned char*  scratch;      // scratch space for encoding
        
};





class NormDecoderMDP : public NormDecoder
{
    // Methods
    public:
	    NormDecoderMDP();
	    ~NormDecoderMDP();
		
	    bool Init(unsigned int numData, unsigned int numParity, UINT16 vectorSize);
	    int Decode(char** vectorList, unsigned int numData,  unsigned int erasureCount, unsigned int* erasureLocs);
		
        int NumParity() 
		{
			return npar;
		}
	    int VectorSize() 
		{
			return vector_size;
		}
        void Destroy();
        
    // Members
    private:
	    unsigned int    npar;        // No. of parity packets (n-k)
	    UINT16          vector_size; // Size of biggest vector to encode  			
	    unsigned char*  lambda;      // Erasure location polynomial ("2*npar" ints)
	    unsigned char** s_vec;       // Syndrome vectors (pointers to "npar" vectors)
	    unsigned char** o_vec;       // Omega vectors (pointers to "npar" vectors)
	    unsigned char*  scratch;
    
};


#endif




