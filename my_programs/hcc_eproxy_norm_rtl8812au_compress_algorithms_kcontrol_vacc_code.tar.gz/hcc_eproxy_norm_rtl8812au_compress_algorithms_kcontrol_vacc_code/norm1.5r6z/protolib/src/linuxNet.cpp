



#include "protoNet.h"
#include "protoDebug.h"


#include <unistd.h>
#include <stdlib.h>  // for atoi()
#include <stdio.h>  // for sprintf()
#include <ifaddrs.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <errno.h>
#include <fcntl.h>




unsigned int ProtoNet::GetInterfaceName(const ProtoAddress& ifAddr, char* buffer, unsigned int buflen)
{
    int family;

    switch(ifAddr.GetType())
    {
        case ProtoAddress::IPv4:
            family = AF_INET;
            break;

        default:
            PLOG(PL_ERROR, "UnixNet::GetInterfaceName() error: invalid address type\n");
            return 0;
    }

    struct ifaddrs* ifap;

    if(0 == getifaddrs(&ifap))
    {
        // Look for addrType address for given "interfaceName"
        struct ifaddrs* ptr = ifap;
        unsigned int namelen = 0;

        while(ptr)
        {
            if((NULL != ptr->ifa_addr) && (family == ptr->ifa_addr->sa_family))
            {
                ProtoAddress theAddr;
                theAddr.SetSockAddr(* (ptr->ifa_addr));

                if(theAddr.HostIsEqual(ifAddr))
                {
                    namelen = strlen(ptr->ifa_name);

                    if(namelen > IFNAMSIZ)
                    {
                        namelen = IFNAMSIZ;
                    }

                    if(NULL == buffer)
                    {
                        break;
                    }

                    unsigned int maxlen = (buflen > IFNAMSIZ) ? IFNAMSIZ : buflen;
                    strncpy(buffer, ptr->ifa_name, maxlen);
                    break;
                }
            }

            ptr = ptr->ifa_next;
        }

        freeifaddrs(ifap);

        if(0 == namelen)
        {
            PLOG(PL_ERROR, "UnixNet::GetInterfaceName() error: unknown interface address\n");
        }

        return namelen;
    }
    else
    {
        PLOG(PL_ERROR, "UnixNet::GetInterfaceName() getifaddrs() error: %s\n", GetErrorString());
        return 0;
    }
}





bool ProtoNet::GetInterfaceAddressList(const char* interfaceName, ProtoAddress::Type addressType, ProtoAddressList& addrList, unsigned int* interfaceIndex)
{
    struct ifreq req;
    memset(&req, 0, sizeof(struct ifreq));
    strncpy(req.ifr_name, interfaceName, IFNAMSIZ);
    int socketFd = -1;

    switch(addressType)
    {
        case ProtoAddress::IPv4:
            req.ifr_addr.sa_family = AF_INET;
            socketFd = socket(PF_INET, SOCK_DGRAM, 0);
            break;

        default:
            req.ifr_addr.sa_family = AF_UNSPEC;
            socketFd = socket(PF_INET, SOCK_DGRAM, 0);
            break;
    }

    if(socketFd < 0)
    {
        PLOG(PL_ERROR, "ProtoNet::GetInterfaceAddressList() socket() error: %s\n", GetErrorString());
        return false;
    }

    if(ProtoAddress::ETH == addressType)
    {
        // Probably Linux
        // Get hardware (MAC) address instead of IP address
        if(ioctl(socketFd, SIOCGIFHWADDR, &req) < 0)
        {
            PLOG(PL_ERROR, "ProtoNet::GetInterfaceAddressList() ioctl(SIOCGIFHWADDR) error: %s\n", GetErrorString());
            close(socketFd);
            return false;
        }
        else
        {
            close(socketFd);

            if(NULL != interfaceIndex)
            {
                *interfaceIndex = req.ifr_ifindex;
            }

            ProtoAddress ethAddr;

            if(!ethAddr.SetRawHostAddress(ProtoAddress::ETH, (const char*) &req.ifr_hwaddr.sa_data, IFHWADDRLEN))
            {
                PLOG(PL_ERROR, "ProtoNet::GetInterfaceAddressList() error: invalid ETH addr?\n");
                return false;
            }

            if(!addrList.Insert(ethAddr))
            {
                PLOG(PL_ERROR, "ProtoNet::GetInterfaceAddressList() error: unable to add ETH addr to list.\n");
                return false;
            }

            return true;
        }
    }


    // Try using getifaddrs() to get all address else resort to ioctl(SIOCGIFADDR) below
    struct ifaddrs* ifap;

    if(0 == getifaddrs(&ifap))
    {
        close(socketFd);
        // Look for addrType address for given "interfaceName"
        struct ifaddrs* ptr = ifap;
        bool foundIface = false;

        while(NULL != ptr)
        {
            char ifname[IFNAMSIZ + 1];
            ifname[IFNAMSIZ] = '\0';
            strncpy(ifname, ptr->ifa_name, IFNAMSIZ);

            // This lets us find alias addrs on Linux
            if(NULL == strchr(interfaceName, ':'))
            {
                // "interfaceName" is a primary (non-alias) interface,
                // so match any aliases, too
                char* colon = strchr(ifname, ':');

                if(NULL != colon)
                {
                    *colon = '\0';
                }
            }


            if(0 == strcmp(interfaceName, ifname))
            {
                if((NULL != ptr->ifa_addr) && (ptr->ifa_addr->sa_family == req.ifr_addr.sa_family))
                {
                    ProtoAddress ifAddr;

                    if(!ifAddr.SetSockAddr(* (ptr->ifa_addr)))
                    {
                        PLOG(PL_WARN, "ProtoNet::GetInterfaceAddressList() error: invalid address family\n");
                        ptr = ptr->ifa_next;
                        continue;
                    }

                    if(!addrList.Insert(ifAddr))
                    {
                        PLOG(PL_ERROR, "ProtoNet::GetInterfaceAddressList() error: unable to add address to list!\n");
                        freeifaddrs(ifap);
                        close(socketFd);
                        return false;
                    }
                }

                foundIface = true;
            }

            ptr = ptr->ifa_next;
        }

        freeifaddrs(ifap);

        if(foundIface)
        {
            if(NULL != interfaceIndex)
            {
                *interfaceIndex = GetInterfaceIndex(interfaceName);
            }
        }
        else
        {
            // Perhaps "interfaceName" is an address string?
            ProtoAddress ifAddr;

            if(ifAddr.ConvertFromString(interfaceName))
            {
                char nameBuffer[IFNAMSIZ + 1];

                if(GetInterfaceName(ifAddr, nameBuffer, IFNAMSIZ + 1))
                {
                    return GetInterfaceAddressList(nameBuffer, addressType, addrList, interfaceIndex);
                }
                else
                {
                    PLOG(PL_ERROR, "ProtoNet::GetInterfaceAddressList() error: unknown interface address\n");
                }
            }

            return false;

        }
    }
    else if(ioctl(socketFd, SIOCGIFADDR, &req) < 0)
    {
        // (TBD - more sophisticated warning logic here
        PLOG(PL_DEBUG, "ProtoNet::GetInterfaceAddressList() ioctl(SIOCGIFADDR) error for iface>%s: %s\n", interfaceName, GetErrorString());
        close(socketFd);

        // Perhaps "interfaceName" is an address string?
        ProtoAddress ifAddr;

        if(ifAddr.ConvertFromString(interfaceName))
        {
            char nameBuffer[IFNAMSIZ + 1];

            if(GetInterfaceName(ifAddr, nameBuffer, IFNAMSIZ + 1))
            {
                return GetInterfaceAddressList(nameBuffer, addressType, addrList, interfaceIndex);
            }
            else
            {
                PLOG(PL_ERROR, "ProtoNet::GetInterfaceAddressList() error: unknown interface address\n");
            }
        }

        return false;
    }
    else
    {
        close(socketFd);
        ProtoAddress ifAddr;

        if(ifAddr.SetSockAddr(req.ifr_addr))
        {
            if(addrList.Insert(ifAddr))
            {
                return true;
            }
            else
            {
                PLOG(PL_ERROR, "ProtoNet::GetInterfaceAddressList() error: unable to add ifAddr to list\n");
                return false;
            }
        }
        else
        {
            PLOG(PL_ERROR, "ProtoNet::GetInterfaceAddressList() error: invalid address family\n");
            return false;
        }

        if(NULL != interfaceIndex)
        {
            *interfaceIndex = GetInterfaceIndex(req.ifr_name);
        }
    }

    return true;
}




unsigned int ProtoNet::GetInterfaceAddressMask(const char* ifaceName, const ProtoAddress& theAddr)
{
    int family;

    switch(theAddr.GetType())
    {
        case ProtoAddress::IPv4:
            family = AF_INET;
            break;

        case ProtoAddress::IPv6:
            family = AF_INET6;
            break;

        default:
            PLOG(PL_ERROR, "ProtoNet::GetInterfaceAddressMask() error: invalid address type\n");
            return 0;
    }

    struct ifaddrs* ifap;

    if(0 == getifaddrs(&ifap))
    {
        // Look for addrType address for given "interfaceName"
        struct ifaddrs* ptr = ifap;
        bool foundIface = false;

        while(NULL != ptr)
        {
            if((NULL == ptr->ifa_addr) || (ptr->ifa_addr->sa_family != family))
            {
                ptr = ptr->ifa_next;
                continue;
            }

            char ifname[IFNAMSIZ + 1];
            ifname[IFNAMSIZ] = '\0';
            strncpy(ifname, ptr->ifa_name, IFNAMSIZ);

            // This lets us find alias addrs on Linux
            char* colon = strchr(ifname, ':');

            if(NULL != colon)
            {
                *colon = '\0';
            }



            if(0 == strcmp(ifaceName, ifname))
            {
                ProtoAddress ifAddr;

                if(!ifAddr.SetSockAddr(* (ptr->ifa_addr)))
                {
                    ptr = ptr->ifa_next;
                    continue;
                }

                if(theAddr.HostIsEqual(ifAddr))
                {
                    if(NULL == ptr->ifa_netmask)
                    {
                        // No netmask, so assume full address length?
                        freeifaddrs(ifap);
                        return (ifAddr.GetLength() << 3);
                    }

                    ProtoAddress maskAddr;

                    if(0 != ptr->ifa_netmask->sa_family)
                    {
                        maskAddr.SetSockAddr(* (ptr->ifa_netmask));
                    }
                    else
                    {
                        // For some reason (at least on MacOSX), we sometimes get a null sa_family on the mask
                        // So we assume netmask _is_ same family as the ifAddr
                        // This seems to happen on "alias" addresses. (TBD - maybe this helps us know which are aliases
                        // and which are not?)
                        struct sockaddr maddr;
                        memcpy(&maddr, ptr->ifa_netmask, sizeof(sockaddr));
                        maddr.sa_family = ptr->ifa_addr->sa_family;
                        maskAddr.SetSockAddr(maddr);
                    }

                    freeifaddrs(ifap);
                    return maskAddr.GetPrefixLength();
                }

                foundIface = true;
            }

            ptr = ptr->ifa_next;
        }

        freeifaddrs(ifap);

        if(!foundIface)
        {
            // Perhaps "interfaceName" is an address string instead?
            ProtoAddress ifAddr;

            if(ifAddr.ConvertFromString(ifaceName))
            {
                char nameBuffer[IFNAMSIZ + 1];

                if(GetInterfaceName(ifAddr, nameBuffer, IFNAMSIZ + 1))
                {
                    return GetInterfaceAddressMask(nameBuffer, theAddr);
                }
                else
                {
                    PLOG(PL_ERROR, "ProtoNet::GetInterfaceAddressMask() error: unknown interface name\n");
                }
            }
        }
    }
    else
    {
        PLOG(PL_ERROR, "ProtoNet::GetInterfaceAddressMask() getifaddrs() error: %s\n");
    }

    return 0;
}





unsigned int ProtoNet::GetInterfaceIndices(unsigned int* indexArray, unsigned int indexArraySize)
{
    unsigned int indexCount = 0;
    struct if_nameindex* ifdx = if_nameindex();

    if(NULL == ifdx)
    {
        return 0;    // no interfaces found
    }

    struct if_nameindex* ifPtr = ifdx;

    while((0 != ifPtr->if_index))
    {
        // need to take into account (NULL, 0) input (see GetInterfaceName)
        if((NULL != indexArray) && (indexCount < indexArraySize))
        {
            indexArray[indexCount] = ifPtr->if_index;
        }

        indexCount++;
        ifPtr++;
    }

    if_freenameindex(ifdx);
    return indexCount;
}





unsigned int ProtoNet::GetInterfaceIndex(const char* interfaceName)
{
    unsigned int index = 0;
    index = if_nametoindex(interfaceName);

    if(0 == index)
    {
        // Perhaps "interfaceName" was an address string?
        ProtoAddress ifAddr;

        if(ifAddr.ResolveFromString(interfaceName))
        {
            char nameBuffer[IFNAMSIZ + 1];

            if(GetInterfaceName(ifAddr, nameBuffer, IFNAMSIZ + 1))
            {
                return GetInterfaceIndex(nameBuffer);
            }
        }
    }

    return index;
}




unsigned int ProtoNet::GetInterfaceName(unsigned int index, char* buffer, unsigned int buflen)
{
    char ifName[IFNAMSIZ + 1];

    if(NULL != if_indextoname(index, ifName))
    {
        strncpy(buffer, ifName, buflen);
        return strlen(ifName);
    }
    else
    {
        return 0;
    }
}




ProtoNet::InterfaceStatus ProtoNet::GetInterfaceStatus(const char* ifaceName)
{
    int fd = socket(PF_INET, SOCK_DGRAM, 0);
    if(fd < 0)
    {
        PLOG(PL_ERROR, "ProtoNet::GetInterfaceStatus() socket() error: %s\n", GetErrorString());
        return IFACE_UNKNOWN;
    }

    struct ifreq req;
    memset(&req, 0, sizeof(req));
    strncpy(req.ifr_name, ifaceName, IFNAMSIZ);

    if(ioctl(fd, SIOCGIFFLAGS, &req) < 0)
    {
        PLOG(PL_ERROR, "ProtoNet::GetInterfaceStatus() ioctl(SIOCGIFFLAGS) error: %s\n", GetErrorString());
        close(fd);
        return IFACE_UNKNOWN;
    }

    close(fd);

    if(0 != (req.ifr_flags & IFF_UP))
    {
        return IFACE_UP;
    }
    else
    {
        return IFACE_DOWN;
    }

}




ProtoNet::InterfaceStatus ProtoNet::GetInterfaceStatus(unsigned int ifaceIndex)
{
    char ifaceName[IFNAMSIZ + 1];
    ifaceName[IFNAMSIZ] = '\0';

    if(!GetInterfaceName(ifaceIndex, ifaceName, IFNAMSIZ))
    {
        PLOG(PL_ERROR, "ProtoNet::InterfaceIsUp() socket() error: %s\n", GetErrorString());
        return IFACE_UNKNOWN;
    }

    return GetInterfaceStatus(ifaceName);
}





// TBD - implement with proper system APIs instead of "ifconfig" command
bool ProtoNet::AddInterfaceAddress(const char* ifaceName, const ProtoAddress& ifaceAddr, unsigned int maskLen)
{
    char cmd[1024];

    switch(ifaceAddr.GetType())
    {
        case ProtoAddress::IPv4:
        {
            // Does the interface have any IPv4 addresses already assigned?
            ProtoAddressList addrList;
            GetInterfaceAddressList(ifaceName, ProtoAddress::IPv4, addrList);
			
            // See if we need to make an alias addr (or set this as primary)
            unsigned int addrCount = 0;
            bool hasPrimary = false;
            ProtoAddress addr;

			//
            ProtoAddressList::Iterator iterator(addrList);
            while(iterator.GetNextAddress(addr))
            {
                addrCount++;
                if(!hasPrimary)
                {
                    char ifname[IFNAMSIZ + 1];
                    ifname[IFNAMSIZ] = '\0';

                    if(!GetInterfaceName(addr, ifname, IFNAMSIZ))
                    {
                        PLOG(PL_ERROR, "ProtoNet::AddInterfaceAddress() error: unable to get interface name for addr %s\n", addr.GetHostString());
                        continue;
                    }

                    if(0 == strcmp(ifname, ifaceName))
                    {
                        hasPrimary = true;
                    }
                }
            }

            if(hasPrimary)
            {
                char aliasName[IFNAMSIZ + 1];
                aliasName[IFNAMSIZ] = '\0';
                strncpy(aliasName, ifaceName, IFNAMSIZ);
                unsigned int namelen = strlen(aliasName);

                if(namelen < IFNAMSIZ)
                {
                    strcat(aliasName, ":");
                    namelen++;
                }
                else
                {
                    PLOG(PL_ERROR, "ProtoNet::AddInterfaceAddress() error: interface name too long to alias\n");
                    return false;
                }

                char* iptr = aliasName + namelen;
                int space = IFNAMSIZ - namelen;
                int index = addrCount - 1;

                while(index < 10)
                {
                    int result = snprintf(iptr, space, "%d", index);
                    if(result < 0)
                    {
                        PLOG(PL_ERROR, "ProtoNet::AddInterfaceAddress() snprintf() error: %s\n", GetErrorString());
                        return false;
                    }
                    else if(result > space)
                    {
                        PLOG(PL_ERROR, "ProtoNet::AddInterfaceAddress() error: alias exceeds max interface name length\n");
                        return false;
                    }

                    ProtoAddress ifAddr;
                    if(!GetInterfaceAddress(aliasName, ProtoAddress::IPv4, ifAddr))
                    {
                        // This alias is available, so set address
                        if(32 == maskLen)
                        {
                            sprintf(cmd, "/sbin/ifconfig %s %s broadcast 0.0.0.0 netmask 255.255.255.255", aliasName, ifaceAddr.GetHostString());
                        }
                        else
                        {
                            sprintf(cmd, "/sbin/ifconfig %s %s/%u", aliasName, ifaceAddr.GetHostString(), maskLen);
                        }

                        break;
                    }

                    index++;
                }

                if(10 == index)
                {
                    return false;
                }

                if(index < 0)
                {
                    PLOG(PL_ERROR, "ProtoNet::AddInterfaceAddress() error: no available alias found\n");
                    return false;
                }
            }
            else
            {
                // Set primary address for interface ifaceName
                if(32 == maskLen)
                {
                    sprintf(cmd, "/sbin/ifconfig %s %s broadcast 0.0.0.0 netmask 255.255.255.255", ifaceName, ifaceAddr.GetHostString());
                }
                else
                {
                    sprintf(cmd, "/sbin/ifconfig %s %s/%u", ifaceName, ifaceAddr.GetHostString(), maskLen);
                }
            }

            break;
        }

        default:
        {
            PLOG(PL_ERROR, "ProtoNet::AddInterfaceAddress() error: invalid address type\n");
            return false;
        }
    }

    if(system(cmd) < 0)
    {
        PLOG(PL_ERROR, "ProtoNet::AddInterfaceAddress() /sbin/ifconfig error: %s\n", GetErrorString());
        return false;
    }

    return true;
}





bool ProtoNet::RemoveInterfaceAddress(const char* ifaceName, const ProtoAddress& ifaceAddr, unsigned int maskLen)
{
    char cmd[1024];

    switch(ifaceAddr.GetType())
    {
        case ProtoAddress::IPv4:
        {
            // On linux we need to find the right interface alias
            char ifname[IFNAMSIZ + 1];
            ifname[IFNAMSIZ] = '\0';

            if(!GetInterfaceName(ifaceAddr, ifname, IFNAMSIZ))
            {
                PLOG(PL_ERROR, "ProtoNet::RemoveInterfaceAddress() error: unknown interface address\n");
                return false;
            }

            if(NULL == strchr(ifname, ':'))
            {
                // Assign INADDR_NONE to remove address
                sprintf(cmd, "/sbin/ifconfig %s 0.0.0.0", ifname);
            }
            else
            {
                // Bring down alias interface
                sprintf(cmd, "/sbin/ifconfig %s down", ifname);
            }

            break;
        }

        default:
        {
            PLOG(PL_ERROR, "ProtoNet::RemoveInterfaceAddress() error: invalid address type\n");
            return false;
        }
    }


    if(system(cmd) < 0)
    {
        PLOG(PL_ERROR, "ProtoNet::RemoveInterfaceAddress() /sbin/ifconfig error: %s\n", GetErrorString());
        return false;
    }

    return true;
}




