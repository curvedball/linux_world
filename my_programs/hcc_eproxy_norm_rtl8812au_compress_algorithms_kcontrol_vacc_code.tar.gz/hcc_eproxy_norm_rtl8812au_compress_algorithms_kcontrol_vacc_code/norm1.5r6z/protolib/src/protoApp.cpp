



/**
* @file protoApp.cpp
*
* @brief Base class for implementing protolib-based command-line applications
*/

#include "protoApp.h"
#include <stdio.h>
#include <signal.h>



ProtoApp* ProtoApp::the_app = NULL;




ProtoApp::ProtoApp()
{
    the_app = this;
}

ProtoApp::~ProtoApp()
{

}


bool ProtoApp::ProcessCommandString(const char* cmdline)
{
    char** argv = new char*[1];

    if(argv)
    {
        if(!(argv[0] = new char[strlen("protoApp") + 1]))    //dummy argument which is usually pointer to app
        {
            delete[] argv;
            PLOG(PL_ERROR, "protoApp: memory allocation error: %s\n", GetErrorString());
            return false;
        }

        strcpy(argv[0], "protoApp");
    }
    else
    {
        PLOG(PL_ERROR, "protoApp: memory allocation error: %s\n", GetErrorString());
        return false;
    }


    // 2) Parse "cmdline" for additional arguments
    int argc = 1;
    const char* ptr = cmdline;
    char fieldBuffer[PATH_MAX];

    while(*ptr != '\0')
    {
        // Skip leading white space
        while(('\t' == *ptr) || (' ' == *ptr))
        {
            ptr++;
        }

        if(1 == sscanf(ptr, "%s", fieldBuffer))
        {
            // Look for "quoted" args to group args with spaces
            if('"' == fieldBuffer[0])
            {
                // Copy contents of quote into fieldBuffer
                ptr++;  // skip '"' character
                const char* end = strchr(ptr, '"');

                if(!end)
                {
                    PLOG(PL_ERROR, "protoApp: Error parsing command line: Unterminated quoted string\n");

                    for(int i = 0; i < argc; i++)
                    {
                        delete[] argv[i];
                    }

                    if(argv)
                    {
                        delete[] argv;
                    }

                    return false;
                }

                unsigned int len = (unsigned int)(end - ptr);
                len = len < (PATH_MAX - 1) ? len : PATH_MAX - 1;
                memcpy(fieldBuffer, ptr, len);
                fieldBuffer[len] = '\0';
                ptr = end + 1;
            }
            else
            {
                ptr += strlen(fieldBuffer);
            }

            argc++;
            char** tempv = new char*[argc];

            if(!tempv)
            {
                argc--;

                for(int i = 0; i < argc; i++)
                {
                    delete[] argv[i];
                }

                if(argv)
                {
                    delete[] argv;
                }

                PLOG(PL_ERROR, "protoApp: memory allocation error: %s\n", GetErrorString());
                return false;
            }

            if(argv)
            {
                memcpy(tempv, argv, (argc - 1) *sizeof(char*));
                delete[] argv;
            }

            argv = tempv;

            if(!(argv[argc - 1] = new char[strlen(fieldBuffer) + 1]))
            {
                for(int i = 0; i < argc; i++)
                {
                    delete[] argv[i];
                }

                if(argv)
                {
                    delete[] argv;
                }

                PLOG(PL_ERROR, "protoApp: memory allocation error: %s\n", GetErrorString());
                return false;
            }

            strcpy(argv[argc - 1], fieldBuffer);
        }
    }

    bool result = ProcessCommands(argc, argv);

    for(int i = 0; i < argc; i++)
    {
        delete[] argv[i];
    }

    if(argv)
    {
        delete[] argv;
    }

    return result;
}






int ProtoMain(int argc, char* argv[], bool pauseForUser)
{
    int exitCode = 0;
    ProtoApp* theApp = ProtoApp::GetApp();

    if(!theApp)
    {
        fprintf(stderr, "protoApp: error: no app was instantiated\n");
        return -1;
    }



    // Pass command-line options to application instance and startup
    if(!theApp->OnStartup(argc, argv))
    {
        theApp->OnShutdown();

        //fprintf(stderr, "protoApp: Error on startup!\n");
        if(pauseForUser)
        {
            fprintf(stderr, "Program Finished - Hit <Enter> to exit");
            getchar();
        }

        return -1;
    }

    signal(SIGTERM, ProtoApp::SignalHandler);
    signal(SIGINT,  ProtoApp::SignalHandler);

    exitCode = theApp->Run();

    theApp->OnShutdown();

    if(pauseForUser)
    {
        fprintf(stderr, "Program Finished - Hit <Enter> to exit");
        getchar();
    }

    return exitCode;  // exitCode contains "signum" causing exit
}





void ProtoApp::SignalHandler(int sigNum)
{

    switch(sigNum)
    {
        case SIGTERM:
        case SIGINT:
        {
            ProtoApp* theApp = ProtoApp::GetApp();

            if(theApp)
            {
                theApp->Stop(sigNum);    // causes theApp's main loop to exit
            }

            break;
        }

        default:
            fprintf(stderr, "protoApp: Unexpected signal: %d\n", sigNum);
            break;
    }
}






