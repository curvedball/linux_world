


/**
* @file protoDispatcher.cpp
*
* @brief This class provides a core around which Unix and Win32 applications using Protolib can be implemented
*/


#include "protoDispatcher.h"

#include <stdio.h>
#include <string.h>


#include <unistd.h>
#include <sys/time.h>
#include <sys/select.h>
#include <fcntl.h>

#ifdef HAVE_SCHED
#include <sched.h>
#else
#include <sys/resource.h>
#endif // HAVE_SCHED

const ProtoDispatcher::Descriptor ProtoDispatcher::INVALID_DESCRIPTOR = -1;



ProtoDispatcher::Stream::Stream(Type theType) :  type(theType), flags(0), prev(NULL), next(NULL)
{

}

ProtoDispatcher::SocketStream::SocketStream(ProtoSocket& theSocket) : Stream(SOCKET), socket(&theSocket)
{

}

ProtoDispatcher::ChannelStream::ChannelStream(ProtoChannel& theChannel) : Stream(CHANNEL), channel(&theChannel)
{

}

ProtoDispatcher::GenericStream::GenericStream(Descriptor theDescriptor) : Stream(GENERIC), descriptor(theDescriptor), callback(NULL), client_data(NULL)
{

}

ProtoDispatcher::ProtoDispatcher()
    : socket_stream_pool(NULL), socket_stream_list(NULL),
      channel_stream_pool(NULL), channel_stream_list(NULL),
      generic_stream_pool(NULL), generic_stream_list(NULL),
      run(false), wait_status(-1), exit_code(0), timer_delay(-1), precise_timing(false),
      thread_id((ThreadId)(NULL)), priority_boost(false), thread_started(false),
      thread_master((ThreadId)(NULL)), suspend_count(0), signal_count(0),
      controller(NULL),
      prompt_set(false), prompt_callback(NULL), prompt_client_data(NULL)
{
    break_pipe_fd[0] = break_pipe_fd[1] = INVALID_DESCRIPTOR;
}



ProtoDispatcher::~ProtoDispatcher()
{
    Destroy();
}



void ProtoDispatcher::Destroy()
{
    Stop();

    while(channel_stream_list)
    {
        channel_stream_list->GetChannel().SetNotifier(NULL);
        //ReleaseSocketStream(socket_stream_list);
    }

    while(channel_stream_pool)
    {
        ChannelStream* channelStream = channel_stream_pool;
        channel_stream_pool = (ChannelStream*) channelStream->GetNext();
        delete channelStream;
    }

    while(socket_stream_list)
    {
        socket_stream_list->GetSocket().SetNotifier(NULL);
    }

    while(socket_stream_pool)
    {
        SocketStream* socketStream = socket_stream_pool;
        socket_stream_pool = (SocketStream*) socketStream->GetNext();
        delete socketStream;
    }

    while(generic_stream_list)
    {
        RemoveGenericStream(generic_stream_list);
    }

    while(generic_stream_pool)
    {
        GenericStream* stream = (GenericStream*) generic_stream_pool;
        generic_stream_pool = (GenericStream*) stream->GetNext();
        delete stream;
    }
}




bool ProtoDispatcher::UpdateChannelNotification(ProtoChannel& theChannel, int notifyFlags)
{
    SignalThread();

    // Find stream in our "wait" list, or add it to the list ...
    ChannelStream* channelStream = GetChannelStream(theChannel);

    if(channelStream)
    {
        if(0 != notifyFlags)
        {
            channelStream->SetFlags(notifyFlags);
            UnsignalThread();
            return true;
        }
        else
        {
            ReleaseChannelStream(channelStream);    // remove channel from our "wait" list
            UnsignalThread();
            return true;
        }
    }
    else
    {
        PLOG(PL_ERROR, "ProtoDispatcher::UpdateChannelNotification() new ChannelStream error: %s\n", GetErrorString());
        UnsignalThread();
        return false;
    }
}





bool ProtoDispatcher::UpdateSocketNotification(ProtoSocket& theSocket, int notifyFlags)
{
    SignalThread();  // TBD - check result? //zb001
    SocketStream* socketStream = GetSocketStream(theSocket);

    if(socketStream)
    {
        if(0 != notifyFlags)
        {
            socketStream->SetFlags(notifyFlags);
        }
        else
        {
            ReleaseSocketStream(socketStream);
        }

        UnsignalThread();
        return true;
    }
    else
    {
        PLOG(PL_ERROR, "ProtoDispatcher::UpdateSocketNotification() new SocketStream error: %s\n", GetErrorString());
        UnsignalThread();
        return false;
    }
}





ProtoDispatcher::SocketStream* ProtoDispatcher::GetSocketStream(ProtoSocket& theSocket)
{
    // First, search our list of active sockets
    SocketStream* socketStream = socket_stream_list;

    while(NULL != socketStream)
    {
        if(&theSocket == &socketStream->GetSocket())
        {
            break;
        }
        else
        {
            socketStream = (SocketStream*) socketStream->GetNext();
        }
    }

    if(NULL == socketStream)
    {
        // Get one from the pool or create a new one
        socketStream = socket_stream_pool;

        if(NULL != socketStream)
        {
            socket_stream_pool = (SocketStream*) socketStream->GetNext();
            socketStream->ClearFlags();
            socketStream->SetSocket(theSocket);
        }
        else
        {
            if(!(socketStream = new SocketStream(theSocket)))
            {
                PLOG(PL_ERROR, "ProtoDispatcher::GetSocketStream() new SocketStream error: %s\n", GetErrorString());
                return NULL;
            }
        }

        // Prepend to "active" socket stream list
        socketStream->SetPrev(NULL);
        socketStream->SetNext(socket_stream_list);

        if(socket_stream_list)
        {
            socket_stream_list->SetPrev(socketStream);
        }

        socket_stream_list = socketStream;
    }

    return socketStream;
}




void ProtoDispatcher::ReleaseSocketStream(SocketStream* socketStream)
{
    socketStream->ClearFlags();
    SocketStream* prevStream = (SocketStream*) socketStream->GetPrev();
    SocketStream* nextStream = (SocketStream*) socketStream->GetNext();

    if(prevStream)
    {
        prevStream->SetNext(nextStream);
    }
    else
    {
        socket_stream_list = nextStream;
    }

    if(nextStream)
    {
        nextStream->SetPrev(prevStream);
    }

    socketStream->SetNext(socket_stream_pool);
    socket_stream_pool = socketStream;
}



ProtoDispatcher::ChannelStream* ProtoDispatcher::GetChannelStream(ProtoChannel& theChannel)
{
    // First, search our list of active channels
    ChannelStream* channelStream = channel_stream_list;

    while(channelStream)
    {
        if(&theChannel == &channelStream->GetChannel())
        {
            break;
        }
        else
        {
            channelStream = (ChannelStream*) channelStream->GetNext();
        }
    }

    if(!channelStream)
    {
        // Get one from the pool or create a new one
        channelStream = channel_stream_pool;

        if(channelStream)
        {
            channel_stream_pool = (ChannelStream*) channelStream->GetNext();
            channelStream->ClearFlags();
            channelStream->SetChannel(theChannel);
        }
        else
        {
            if(!(channelStream = new ChannelStream(theChannel)))
            {
                PLOG(PL_ERROR, "ProtoDispatcher::GetChannelStream() new ChannelStream error: %s\n", GetErrorString());
                return NULL;
            }
        }

        // Prepend to "active" channel stream list
        channelStream->SetPrev(NULL);
        channelStream->SetNext(channel_stream_list);

        if(channel_stream_list)
        {
            channel_stream_list->SetPrev(channelStream);
        }

        channel_stream_list = channelStream;
    }

    return channelStream;
}




void ProtoDispatcher::ReleaseChannelStream(ChannelStream* channelStream)
{
    channelStream->ClearFlags();
    ChannelStream* prevStream = (ChannelStream*) channelStream->GetPrev();
    ChannelStream* nextStream = (ChannelStream*) channelStream->GetNext();

    if(prevStream)
    {
        prevStream->SetNext(nextStream);
    }
    else
    {
        channel_stream_list = nextStream;
    }

    if(nextStream)
    {
        nextStream->SetPrev(prevStream);
    }

    channelStream->SetNext(channel_stream_pool);
    channel_stream_pool = channelStream;
}  // end ProtoDispatcher::ReleaseChannelStream()



bool ProtoDispatcher::InstallGenericStream(ProtoDispatcher::Descriptor descriptor, Callback* callback, const void* userData, Stream::Flag flag)
{
    GenericStream* stream = GetGenericStream(descriptor);

    if(stream)
    {
        stream->SetCallback(callback, userData);
        stream->SetFlag(flag);
        return true;
    }
    else
    {
        PLOG(PL_ERROR, "ProtoDispatcher::InstallGenericStream() error getting GenericStream\n");
        return false;
    }
}



ProtoDispatcher::GenericStream* ProtoDispatcher::GetGenericStream(Descriptor descriptor)
{
    // First, search our list of active generic streams
    GenericStream* stream = generic_stream_list;

    while(stream)
    {
        if(descriptor == stream->GetDescriptor())
        {
            break;
        }
        else
        {
            stream = (GenericStream*) stream->GetNext();
        }
    }

    if(!stream)
    {
        // Get one from the pool or create a new one
        stream = generic_stream_pool;

        if(stream)
        {
            generic_stream_pool = (GenericStream*) stream->GetNext();
            stream->ClearFlags();
            stream->SetDescriptor(descriptor);
        }
        else
        {
            if(!(stream = new GenericStream(descriptor)))
            {
                PLOG(PL_ERROR, "ProtoDispatcher::GetGenericStream() new GenericStream error: %s\n", GetErrorString());
                return NULL;
            }
        }

        // Add to "active" generic stream list
        stream->SetPrev(NULL);
        stream->SetNext(generic_stream_list);

        if(generic_stream_list)
        {
            generic_stream_list->SetPrev(stream);
        }

        generic_stream_list = stream;
    }

    return stream;
}




ProtoDispatcher::GenericStream* ProtoDispatcher::FindGenericStream(Descriptor descriptor) const
{
    GenericStream* next = generic_stream_list;

    while(next)
    {
        if(next->GetDescriptor() == descriptor)
        {
            return next;
        }
        else
        {
            next = (GenericStream*) next->GetNext();
        }
    }

    return NULL;
}



void ProtoDispatcher::ReleaseGenericStream(GenericStream* stream)
{
    stream->ClearFlags();
    // Move from "active" generic stream list to generic stream "pool"
    GenericStream* prevStream = (GenericStream*) stream->GetPrev();
    GenericStream* nextStream = (GenericStream*) stream->GetNext();

    if(prevStream)
    {
        prevStream->SetNext(nextStream);
    }
    else
    {
        generic_stream_list = nextStream;
    }

    if(nextStream)
    {
        nextStream->SetPrev(prevStream);
    }

    stream->SetNext(generic_stream_pool);
    generic_stream_pool = stream;
}




/**
 * @brief Boost process priority for real-time operation
 */
bool ProtoDispatcher::BoostPriority()
{
    //int who = IsThreaded() ? thread_id : 0;

#ifdef HAVE_SCHED
    // (This _may_ work on Linux-only at this point)
    // (TBD) We should probably look into pthread-setschedparam() instead
    struct sched_param schp;
    memset(&schp, 0, sizeof(schp));
    schp.sched_priority =  sched_get_priority_max(SCHED_FIFO);

    if(sched_setscheduler(0, SCHED_FIFO, &schp))
    {
        schp.sched_priority =  sched_get_priority_max(SCHED_OTHER);

        if(sched_setscheduler(0, SCHED_OTHER, &schp))
        {
            PLOG(PL_ERROR, "ProtoDispatcher::BoostPriority() error: sched_setscheduler() error: %s\n", GetErrorString());
            return false;
        }
    }

#else

    // (TBD) Do something differently if "pthread sched param"?
    if(0 != setpriority(PRIO_PROCESS, getpid(), -20))
    {
        PLOG(PL_ERROR, "PrototDispatcher::BoostPriority() error: setpriority() error: %s\n", GetErrorString());
        return false;
    }

#endif // HAVE_SCHED

    return true;
}






/**
 * A ProtoDispatcher "main loop"
 */
int ProtoDispatcher::Run(bool oneShot)
{
    exit_code = 0;
    wait_status = -1;

    if(priority_boost)
    {
        BoostPriority();
    }

    // TBD - should we keep "run" true while in the do loop so "IsRunning()"
    //       can be interpreted properly (or just deprecate IsRunning() ???
    run = oneShot ? false : true;

    do
    {
        if(IsPending())
        {
            // Here we "latch" the next timeout _before_
            // we open the suspend window to be safe
            timer_delay = ProtoTimerMgr::GetTimeRemaining(); //zb400: a list of ascend sorted timer nodes

            if(IsThreaded())
            {
                Lock(signal_mutex);

                Unlock(suspend_mutex);

                //
                Wait(); //zb200, zb300, zb400, timeout should also be processed by select mechanism bacause timer_delay is set!

                Unlock(signal_mutex);


                // <-- this is where a dispatcher rests after SignalThread() call

                // what if another thread calls SignalThread() at this exact moment?
                // and gets the suspend and signal mutexes ...
                // a) WasSignaled() will be false on Unix (break_pipe fd not set)
                // b) then Dispatch() will be called ... but only valid descriptors, etc are checked
                //    as Wait resets/builds the FD_SET
                // c) next time WasSignaled() will be true, but no big deal

                Lock(suspend_mutex);

                if(prompt_set)
                {

                    if(NULL != prompt_callback)
                    {
                        prompt_callback(prompt_client_data);
                    }

                    prompt_set = false;
                }

                if(WasSignaled())
                {
                    continue;
                }
                else if(controller)
                {
                    // Relinquish to controller thread
                    // Note this assumes the controller thread is the _only_
                    // other thread vying for control of this dispatcher thread
                    Unlock(suspend_mutex);

                    //
                    controller->DoDispatch(); //zb

                    Lock(suspend_mutex);
                }
                else
                {
                    // Do our own event dispatching
                    Dispatch();
                }
            }
            else
            {
                Wait();
                Dispatch();
            }
        }
        else
        {
            PLOG(PL_DEBUG, "ProtoDispatcher::Run() would be stuck with infinite timeout & no inputs!\n");
            break;
        }

    }
    while(run);   //zb500


    return exit_code;
}






void ProtoDispatcher::Stop(int exitCode)
{
    if(controller)
    {
        controller->OnThreadStop();
        controller = NULL;
    }

    SignalThread();
    exit_code = run ? exitCode : exit_code;
    run = false; //zb500

    UnsignalThread();
    DestroyThread();
}




void* ProtoDispatcher::DoThreadStart(void* param)    //zb200
{
    ProtoDispatcher* dp = reinterpret_cast<ProtoDispatcher*>(param);
    ASSERT(NULL != dp);

    if(NULL != dp->controller)
    {
        Lock(dp->controller->lock_b);
    }

    Lock(dp->suspend_mutex);

    dp->thread_started = true;

    // TBD - should have Run() set exit_status internally instead???
    //
    dp->exit_status = dp->Run();  //zb200, zb300

    Unlock(dp->suspend_mutex);



    DoThreadExit(dp->GetExitStatus());
    return (dp->GetExitStatus());
}  // end ProtoDispatcher::DoThreadStart()




bool ProtoDispatcher::StartThread(bool priorityBoost, ProtoDispatcher::Controller* theController)
{
    if(IsThreaded())
    {
        PLOG(PL_ERROR, "ProtoDispatcher::StartThread() error: thread already started\n");
        return false;
    }

    priority_boost = priorityBoost;

    if(!InstallBreak())
    {
        PLOG(PL_ERROR, "ProtoDispatcher::StartThread() error: InstallBreak() failed\n");
        return false;
    }

    controller = theController;
    Init(suspend_mutex);
    Init(signal_mutex);

    Lock(suspend_mutex);

    if(0 != pthread_create(&thread_id, NULL, DoThreadStart, this))       //zb200
    {
        PLOG(PL_ERROR, "ProtoDispatcher::StartThread() create thread error: %s\n", GetErrorString());
        RemoveBreak();
        Unlock(suspend_mutex);
        thread_id = (ThreadId) NULL;
        controller = NULL;
        return false;
    }

    Unlock(suspend_mutex);

    return true;
}




/**
 * This brings the thread to a suspended state _outside_
 * of _its_ ProtoDispatcher::Wait() state
 */
bool ProtoDispatcher::SignalThread() //zb001
{
    SuspendThread();

    if(IsThreaded() && !IsMyself())
    {
        if(signal_count > 0)
        {
            signal_count++;
            return true;
        }
        else
        {

            while(1)
            {
                char byte = 0;
                int result = write(break_pipe_fd[1], &byte, 1); //zb001

                if(1 == result)
                {
                    break;
                }
                else if(0 == result)
                {
                    PLOG(PL_ERROR, "ProtoDispatcher::SignalThread() warning: write() returned zero\n");
                    continue;
                }
                else
                {
                    if(EINTR == errno)
                    {
                        continue;    // (TBD) also for EAGAIN ???
                    }

                    PLOG(PL_ERROR, "ProtoDispatcher::SignalThread() write() error: %s\n", GetErrorString());
                    ResumeThread();
                    return false;
                }
            }

            Lock(signal_mutex);
            signal_count = 1;
        }
    }

    return true;
}




void ProtoDispatcher::UnsignalThread()
{
    if(IsThreaded() && !IsMyself() && (thread_master == GetCurrentThread()))
    {
        ASSERT(0 != signal_count);
        signal_count--;

        if(0 == signal_count)
        {
            Unlock(signal_mutex);
        }
    }

    ResumeThread();
}  // end ProtoDispatcher::UnsignalThread()



bool ProtoDispatcher::SuspendThread()
{
    if(IsThreaded() && !IsMyself())
    {
        if(GetCurrentThread() == thread_master)
        {
            suspend_count++;
            return true;
        }

        // We use while() here to make sure the thread started
        // (TBD) use a spin_count to limit iterations as safeguard
        while(!thread_started)
        {
            ;
        }

        Lock(suspend_mutex);    // TBD - check result of "Lock()"
        thread_master = GetCurrentThread();
        suspend_count = 1;
    }

    return true;
}



void ProtoDispatcher::ResumeThread()
{
    if(IsThreaded() && !IsMyself())
    {
        if(GetCurrentThread() == thread_master)
        {
            if(suspend_count > 1)
            {
                suspend_count--;
            }
            else
            {
                thread_master = (ThreadId) NULL;
                suspend_count = 0;
                Unlock(suspend_mutex);
            }
        }
    }
}



void ProtoDispatcher::DestroyThread()
{
    if(IsThreaded())
    {
        controller = NULL;

        if(!IsMyself())
        {
            pthread_join(thread_id, NULL);
        }

        thread_id = (ThreadId) NULL;
        RemoveBreak();
        Destroy(suspend_mutex);
        Destroy(signal_mutex);
    }
}





/////////////////////////////////////////////////////////////////////////
// Unix-specific methods and implementation
/**
 * (TBD) It would be nice to use something like SIGUSR or something to break
 * out of the select() (or pselect()) call in ProtoDispatcher::Wait()
 * instead of a pipe() ... but to support threaded operation and do
 * it right, we would need something like pthread-sigsetjmp() to deal
 * with the "edge-triggered" nature issue of signals, and/or we
 * might wish to consider kevent() for systems like BSD, etc
 */
bool ProtoDispatcher::InstallBreak()
{
    if(0 != pipe(break_pipe_fd))
    {
        PLOG(PL_ERROR, "ProtoDispatcher::InstallBreak() pipe() error: %s\n", GetErrorString());
        return false;
    }

    // make reading non-blocking
    if(-1 == fcntl(break_pipe_fd[0], F_SETFL, fcntl(break_pipe_fd[0], F_GETFL, 0)  | O_NONBLOCK))
    {
        PLOG(PL_ERROR, "ProtoDispatcher::InstallBreak() fcntl(F_SETFL(O_NONBLOCK)) error: %s\n", GetErrorString());
        return false;
    }

    return true;
}



void ProtoDispatcher::RemoveBreak()
{
    if(INVALID_DESCRIPTOR != break_pipe_fd[0])
    {
        close(break_pipe_fd[0]);
        close(break_pipe_fd[1]);
        break_pipe_fd[0] = INVALID_DESCRIPTOR;
    }
}




/**
 * Warning! This may block indefinitely iF !IsPending() ...
 */
void ProtoDispatcher::Wait()
{
    // (TBD) We could put some code here to protect this from
    // being called by the wrong thread?
    struct timeval timeout;
    struct timeval* timeoutPtr;

    //double timerDelay = ProtoTimerMgr::GetTimeRemaining();
    double timerDelay = timer_delay; //zb400: timer_delay is set in the loop of the thread (named "Run" funcion).

    if(timerDelay < 0.0)
    {
        timeoutPtr = NULL;
    }
    else
    {
        // If (true == precise_timing) essentially force polling for small delays
        // (Note this will consume CPU resources)
        if(precise_timing && (timerDelay < 0.010))
        {
            timerDelay = 0.0;
        }

        timeout.tv_sec = (unsigned long) timerDelay;
        timeout.tv_usec = (unsigned long)(1.0e+06 * (timerDelay - (double) timeout.tv_sec));
        timeoutPtr = &timeout;
    }

    FD_ZERO(&input_set);
    FD_ZERO(&output_set);
    int maxDescriptor = -1;


    // Monitor "break_pipe" if we are a threaded dispatcher
    // TBD - change this to use "eventfd()" on Linux
    if(IsThreaded())
    {
        FD_SET(break_pipe_fd[0], &input_set); //zb001

        if(break_pipe_fd[0] > maxDescriptor)
        {
            maxDescriptor = break_pipe_fd[0];
        }
    }


    // Monitor socket streams ...
    SocketStream* nextSocket = socket_stream_list;

    while(nextSocket)
    {
        Descriptor descriptor = nextSocket->GetSocket().GetHandle();

        if(nextSocket->IsInput())
        {
            FD_SET(descriptor, &input_set);    //zb200
        }

        if(nextSocket->IsOutput())
        {
            FD_SET(descriptor, &output_set);
        }

        if(descriptor > maxDescriptor)
        {
            maxDescriptor = descriptor;
        }

        nextSocket = (SocketStream*) nextSocket->GetNext();
    }


    // Monitor channel streams ...
    ChannelStream* nextChannel = channel_stream_list;

    while(nextChannel)
    {
        Descriptor descriptor = nextChannel->GetChannel().GetHandle();

        if(nextChannel->IsInput())
        {
            FD_SET(descriptor, &input_set);
        }

        if(nextChannel->IsOutput())
        {
            FD_SET(descriptor, &output_set);
        }

        if(descriptor > maxDescriptor)
        {
            maxDescriptor = descriptor;
        }

        nextChannel = (ChannelStream*) nextChannel->GetNext();
    }


    // Monitor generic streams ...
    GenericStream* nextStream = generic_stream_list;

    while(nextStream)
    {
        Descriptor descriptor = nextStream->GetDescriptor();

        if(nextStream->IsInput())
        {
            FD_SET(descriptor, &input_set);
        }

        if(nextStream->IsOutput())
        {
            FD_SET(descriptor, &output_set);
        }

        if(descriptor > maxDescriptor)
        {
            maxDescriptor = descriptor;
        }

        nextStream = (GenericStream*) nextStream->GetNext();
    }

    // (TBD) It might be nice to use "pselect()" here someday
    //
    //zb: the return value of select API call on linux platform
    //  >0:     read or write event generated
    //   =0:    timeout
    //   <0:   error occurs
    wait_status = select(maxDescriptor + 1, (fd_set*) &input_set, (fd_set*) &output_set, (fd_set*) NULL, timeoutPtr);  //zb200, zb400
}





void ProtoDispatcher::Dispatch()
{

    switch(wait_status)  //zb: the return value of select API call on linux platform
    {
        case -1:
            if(EINTR != errno)
            {
                PLOG(PL_ERROR, "ProtoDispatcher::Dispatch() select() error: %s\n", GetErrorString());
            }

            break;

        case 0:
            OnSystemTimeout();
            break;

        default:
            // (TBD) make this safer (we need a safe iterator for these)...
            // Check socket streams ...
            SocketStream* nextSocketStream = socket_stream_list;
            while(nextSocketStream)
            {
                SocketStream* savedNext = (SocketStream*) nextSocketStream->GetNext();
                ProtoSocket& theSocket = nextSocketStream->GetSocket();
                Descriptor descriptor = theSocket.GetHandle();

                if(nextSocketStream->IsInput() && FD_ISSET(descriptor, &input_set))
                {
                    theSocket.OnNotify(ProtoSocket::NOTIFY_INPUT);    //zb200
                    //break;
                }

                if(nextSocketStream->IsOutput() && FD_ISSET(descriptor, &output_set))
                {
                    theSocket.OnNotify(ProtoSocket::NOTIFY_OUTPUT);    //zb300
                    //break;
                }

                nextSocketStream = savedNext;
            }


            // Check channel streams ...
            ChannelStream* nextChannelStream = channel_stream_list;
            while(nextChannelStream)
            {
                ChannelStream* savedNext = (ChannelStream*) nextChannelStream->GetNext();
                ProtoChannel& theChannel = nextChannelStream->GetChannel();
                Descriptor descriptor = theChannel.GetHandle();

                if(nextChannelStream->IsInput() && FD_ISSET(descriptor, &input_set))
                {
                    theChannel.OnNotify(ProtoChannel::NOTIFY_INPUT);
                    //break;
                }

                if(nextChannelStream->IsOutput() && FD_ISSET(descriptor, &output_set))
                {
                    theChannel.OnNotify(ProtoChannel::NOTIFY_OUTPUT);
                    //break;
                }

                nextChannelStream = savedNext;
            }


            // Check generic streams ...
            GenericStream* nextStream = generic_stream_list;

            while(nextStream)
            {
                GenericStream* savedNext = (GenericStream*) nextStream->GetNext();
                Descriptor descriptor = nextStream->GetDescriptor();

                if(nextStream->IsInput() && FD_ISSET(descriptor, &input_set))
                {
                    nextStream->OnEvent(EVENT_INPUT);
                    //break;
                }

                if(nextStream->IsOutput() && FD_ISSET(descriptor, &output_set))
                {
                    nextStream->OnEvent(EVENT_OUTPUT);
                    //break;
                }

                nextStream = savedNext;
            }

            OnSystemTimeout();
            break;
    }
}





//========================================================================================================
/**
 * UNIX ProtoDispatcher::Controller implementation
 */
ProtoDispatcher::Controller::Controller(ProtoDispatcher& theDispatcher)
    : dispatcher(theDispatcher), use_lock_a(true)
{
    ProtoDispatcher::Init(lock_a);
    ProtoDispatcher::Init(lock_b);
    ProtoDispatcher::Lock(lock_a);
    // Note: "lock_b" gets an initial Lock() by the controlled
    // thread during "ProtoDispatcher::DoThreadStart()"
}

ProtoDispatcher::Controller::~Controller()
{
    Unlock(lock_a);
    Unlock(lock_b);
    Destroy(lock_a);
    Destroy(lock_b);
}



bool ProtoDispatcher::Controller::DoDispatch()
{
    // (TBD) make sure !IsMyself() ???
    if(use_lock_a)
    {
        ProtoDispatcher::Unlock(lock_b);
    }
    else
    {
        ProtoDispatcher::Unlock(lock_a);
    }

    if(!SignalDispatchReady())    //zb
    {
        PLOG(PL_ERROR, "ProtoDispatcher::Controller::DoDispatch()) SignalDispatchReady() error\n");
        return false;
    }

    if(use_lock_a)
    {
        ProtoDispatcher::Lock(lock_a);
        use_lock_a = false;
    }
    else
    {
        ProtoDispatcher::Lock(lock_b);
        use_lock_a = true;
    }

    return true;
}  // end ProtoDispatcher::Controller::DoDispatch()



void ProtoDispatcher::Controller::OnDispatch()
{
    dispatcher.SuspendThread();
    dispatcher.Dispatch(); //zb200

    if(use_lock_a)
    {
        ProtoDispatcher::Lock(lock_b);
        ProtoDispatcher::Unlock(lock_a);
    }
    else
    {
        ProtoDispatcher::Lock(lock_a);
        ProtoDispatcher::Unlock(lock_b);
    }

    dispatcher.ResumeThread();
}




