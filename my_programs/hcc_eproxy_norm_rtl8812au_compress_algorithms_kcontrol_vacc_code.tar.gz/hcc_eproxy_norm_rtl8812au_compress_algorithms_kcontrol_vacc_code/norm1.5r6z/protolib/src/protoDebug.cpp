

/**
* @file protoDebug.cpp
*
* @brief Debugging functions
*/


#include "protoDebug.h"
#include "protoPipe.h" // to support OpenDebugPipe() option

#include <stdio.h>
#include <stdlib.h>  // for abort()
#include <stdarg.h>  // for variable args





#if defined(PROTO_DEBUG)



// Note - the static debug_level, debug_log, etc variables are
//        now "wrapped" in function calls to avoid the
//        "static initialization order fiasco"



/**
* @brief set default to pick up errors as well as fatal errors by default.
*/
static unsigned int DebugLevel(bool set = false, unsigned int value = PL_ERROR)
{
    static unsigned int debug_level = PL_ERROR;

    if(set)
    {
        debug_level = value;
    }

    return debug_level;
}



/**
* @brief log to stderr by default
*/
static FILE* DebugLog(bool set = false, FILE* value = stderr)
{
    static FILE* debug_log = stderr; //zb

    if(set)
    {
        debug_log = value;
    }

    return debug_log;
}



static ProtoAssertFunction* assert_function = NULL;
static void*                assert_data = NULL;


static ProtoPipe debug_pipe(ProtoPipe::MESSAGE);





void SetDebugLevel(unsigned int level)
{
    unsigned int debugLevel = DebugLevel();
    DebugLevel(true, level);  // this sets the underlying static "debug_level" state variable

    if(level != debugLevel)
    {
        PLOG(PL_INFO, "ProtoDebug>SetDebugLevel: debug level changed from %d to %d\n", debugLevel, level);
    }
}


unsigned int GetDebugLevel()
{
    return DebugLevel();
}




bool OpenDebugLog(const char *path)
{
    PLOG(PL_INFO, "ProtoDebug>OpenDebugLog: debug log is being set to \"%s\"\n", path);

    CloseDebugLog();

    FILE* ptr = fopen(path, "w+");

    if(ptr)
    {
        DebugLog(true, ptr);
        return true;
    }
    else
    {
        DebugLog(true, stderr);
        PLOG(PL_ERROR, "OpenDebugLog: Error opening debug log file: %s\n", path);
        return false;
    }
}




void CloseDebugLog()
{
    FILE* debugLog = DebugLog();

    if(debugLog && (debugLog != stderr) && (debugLog != stdout))
    {
        fclose(debugLog);
    }


    if(debug_pipe.IsOpen())
    {
        debug_pipe.Close();
    }

    DebugLog(true, stderr);
}





/**
* @brief log debug messages to a datagram channel
*/
bool OpenDebugPipe(const char* pipeName)
{
    if(!debug_pipe.Connect(pipeName))
    {
        PLOG(PL_ERROR, "OpenDebugPipe: error opening/connecting debug_pipe!\n");
        return false;
    }

    return true;
}



void CloseDebugPipe()
{
    if(debug_pipe.IsOpen())
    {
        debug_pipe.Close();
    }
}





/**
 * @brief Display string if statement's debug level is large enough
 */
void DMSG(unsigned int level, const char *format, ...)
{
    if(level <= DebugLevel())
    {
        FILE* debugLog = DebugLog();
        va_list args;
        va_start(args, format);
        vfprintf(debugLog, format, args);
        fflush(debugLog);
        va_end(args);
    }
}



/**
 * @brief Provides a basic logging facility for Protlib that uses the typical logging levels
 * to allow different levels for logging and run-time debugging of protolib applications.
 */
void PLOG(ProtoDebugLevel level, const char *format, ...)
{
    if(((unsigned int) level <= DebugLevel()) || (PL_ALWAYS == level))
    {
        va_list args;
        va_start(args, format);
        const char * header = "";

        switch(level)
        {
            // Print out the Logging Type before the message
            case PL_FATAL:
                header = "Proto Fatal: ";
                break;

            case PL_ERROR:
                header = "Proto Error: ";
                break;

            case PL_WARN:
                header = "Proto Warn: ";
                break;

            case PL_INFO:
                header = "Proto Info: ";
                break;

            case PL_DEBUG:
                header = "Proto Debug: ";
                break;

            case PL_TRACE:
                header = "Proto Trace: ";
                break;

            case PL_DETAIL:
                header = "Proto Detail: ";
                break;

            case PL_MAX:
                header = "Proto Max: ";
                break;

            default:
                break;
        }

        size_t headerLen = strlen(header);
        FILE* debugLog = DebugLog();

        if(debug_pipe.IsOpen())
        {
            char buffer[8192];
            buffer[8191] = '\0';
            strcpy(buffer, header);
            unsigned int count = (unsigned int) vsnprintf(buffer + headerLen, 8191 - headerLen, format, args) + 1;
            count += headerLen;

            if(count > 8192)
            {
                count = 8192;
            }


            if(!debug_pipe.Send(buffer, count))
            {
                // We have no recourse but to go to stderr here
                fprintf(stderr, "PLOG() error: unable to send to debug pipe!!!\n");
                vfprintf(stderr, format, args);
                fflush(stderr);
            }
        }
        else
        {
            fprintf(debugLog, "%s", header);
            vfprintf(debugLog, format, args);
            fflush(debugLog);
        }

        va_end(args);
    }

}






void TRACE(const char *format, ...)
{
    FILE* debugLog = DebugLog();
    va_list args;
    va_start(args, format);
    vfprintf(debugLog, format, args);
    fflush(debugLog);
    va_end(args);
}




void PROTO_ABORT(const char *format, ...)
{

    FILE* debugLog = DebugLog();
    va_list args;
    va_start(args, format);
    vfprintf(debugLog, format, args);
    fflush(debugLog);
    va_end(args);
    abort();
}



void SetAssertFunction(ProtoAssertFunction* assertFunction, void* userData)
{
    assert_function = assertFunction;
    assert_data = userData;
}



void ClearAssertFunction()
{
    assert_function = NULL;
}



bool HasAssertFunction()
{
    return (NULL != assert_function);
}



void ProtoAssertHandler(bool condition, const char* conditionText, const char* fileName, int lineNumber)
{
    if(NULL != assert_function)
    {
        assert_function(condition, conditionText, fileName, lineNumber, assert_data);
    }
}



#endif










