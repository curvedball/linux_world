

#include "protoFile.h"

#include <string.h>  // for strerror()
#include <stdio.h>   // for rename()
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>




ProtoFile::ProtoFile()
{

}

ProtoFile::~ProtoFile()
{
    if(IsOpen())
    {
        Close();
    }
}





// This should be called with a full path only!
bool ProtoFile::Open(const char* thePath, int theFlags)
{
    bool returnvalue = false;
    ASSERT(!IsOpen());

    if(theFlags & O_CREAT)
    {
        // Create sub-directories as needed.
        char tempPath[PATH_MAX];
        strncpy(tempPath, thePath, PATH_MAX);
        char* ptr = strrchr(tempPath, PROTO_PATH_DELIMITER);

        if(NULL != ptr)
        {
            *ptr = '\0';
            ptr = NULL;

            while(!ProtoFile::Exists(tempPath))
            {
                char* ptr2 = ptr;
                ptr = strrchr(tempPath, PROTO_PATH_DELIMITER);

                if(ptr2)
                {
                    *ptr2 = PROTO_PATH_DELIMITER;
                }

                if(ptr)
                {
                    *ptr = '\0';
                }
                else
                {
                    ptr = tempPath;
                    break;
                }
            }
        }

        if(ptr && ('\0' == *ptr))
        {
            *ptr++ = PROTO_PATH_DELIMITER;
        }

        while(ptr)
        {
            ptr = strchr(ptr, PROTO_PATH_DELIMITER);

            if(ptr)
            {
                *ptr = '\0';
            }

            if(mkdir(tempPath, 0755))
            {
                PLOG(PL_FATAL, "ProtoFile::Open() mkdir(%s) error: %s\n", tempPath, GetErrorString());
                return false;
            }

            if(ptr)
            {
                *ptr++ = PROTO_PATH_DELIMITER;
            }
        }
    }

    if((descriptor = open(thePath, theFlags, 0640)) >= 0)
    {
        offset = 0;
        returnvalue = true; // no error
    }
    else
    {
        PLOG(PL_FATAL, "protoFile: Error opening file \"%s\": %s\n",
             thePath, GetErrorString());
        return false;
    }

    if(returnvalue)
    {
        return ProtoChannel::Open();
    }

    return returnvalue;
}


void ProtoFile::Close()
{
    if(IsOpen())
    {
        close(descriptor);
        descriptor = -1;
        ProtoChannel::Close();
    }
}



// Routines to try to get an exclusive lock on a file
bool ProtoFile::Lock()
{
    fchmod(descriptor, 0640 | S_ISGID);

#ifdef HAVE_LOCKF

    if(lockf(descriptor, F_LOCK, 0))   // assume lockf if not flock
    {
        return false;
    }
    else
#endif

        return true;
}



void ProtoFile::Unlock()
{
#ifdef HAVE_LOCKF
    int ret = lockf(descriptor, F_ULOCK, 0);
#endif // HAVE_LOCKF
    fchmod(descriptor, 0640);
}



bool ProtoFile::Rename(const char* oldName, const char* newName)
{
    if(!strcmp(oldName, newName))
    {
        return true;    // no change required
    }

    // Make sure the new file name isn't an existing "busy" file
    // (This also builds sub-directories as needed)
    if(ProtoFile::IsLocked(newName))
    {
        PLOG(PL_FATAL, "ProtoFile::Rename() error: file is locked\n");
        return false;
    }

    // Create sub-directories as needed.
    char tempPath[PATH_MAX];
    strncpy(tempPath, newName, PATH_MAX);
    char* ptr = strrchr(tempPath, PROTO_PATH_DELIMITER);

    if(ptr)
    {
        *ptr = '\0';
    }

    ptr = NULL;

    while(!ProtoFile::Exists(tempPath))
    {
        char* ptr2 = ptr;
        ptr = strrchr(tempPath, PROTO_PATH_DELIMITER);

        if(ptr2)
        {
            *ptr2 = PROTO_PATH_DELIMITER;
        }

        if(ptr)
        {
            *ptr = '\0';
        }
        else
        {
            ptr = tempPath;
            break;
        }
    }

    if(ptr && ('\0' == *ptr))
    {
        *ptr++ = PROTO_PATH_DELIMITER;
    }

    while(ptr)
    {
        ptr = strchr(ptr, PROTO_PATH_DELIMITER);

        if(ptr)
        {
            *ptr = '\0';
        }

        if(mkdir(tempPath, 0755))
        {
            PLOG(PL_FATAL, "ProtoFile::Rename() mkdir(%s) error: %s\n",
                 tempPath, GetErrorString());
            return false;
        }

        if(ptr)
        {
            *ptr++ = PROTO_PATH_DELIMITER;
        }
    }

    if(rename(oldName, newName))
    {
        PLOG(PL_ERROR, "ProtoFile::Rename() rename() error: %s\n", GetErrorString());
        return false;
    }
    else
    {
        return true;
    }
}





bool ProtoFile::Read(char* buffer, unsigned int& numBytes)
{
    ASSERT(IsOpen());

    while(true)
    {

        ssize_t result = read(descriptor, buffer, numBytes);

        if(result < 0)
        {
            numBytes = 0;

            switch(errno)
            {
                case EINTR:
                    continue;

                case EAGAIN:
                    return true;//reached eof

                default:
                    break;//bad error will print and return false;
            }

            PLOG(PL_ERROR, "ProtoFile::Read() error: %s\n", GetErrorString());
            return false;
        }
        else
        {
            numBytes = result;
            return true;
        }
    }
}



bool ProtoFile::bufferedRead(char* buffer, unsigned int& numBytes)
{
    unsigned int want = numBytes;

    if(savecount)
    {
        unsigned int ncopy = MIN(want, savecount);
        memcpy(buffer, saveptr, ncopy);
        savecount -= ncopy;
        saveptr += ncopy;
        buffer += ncopy;
        want -= ncopy;
    }

    while(want)
    {
        unsigned int blocksize = BLOCKSIZE;

        if(!Read(savebuf, blocksize))
        {
            PLOG(PL_ERROR, "ProtoFile::bufferedRead() error calling Read()\n");
            return false;
        }

        if(blocksize > 0)
        {
            // This check skips NULLs that have been read on some
            // use of trpr via tail from an NFS mounted file
            if(!isprint(*savebuf) &&
               ('\t' != *savebuf) &&
               ('\n' != *savebuf) &&
               ('\r' != *savebuf))
            {
                continue;
            }

            unsigned int ncopy = MIN(want, blocksize);
            memcpy(buffer, savebuf, ncopy);
            savecount = blocksize - ncopy;
            saveptr = savebuf + ncopy;
            buffer += ncopy;
            want -= ncopy;
        }
        else
        {
            //nothing was read in
            numBytes -= want;
            return true;
        }
    }

    //we finished filling in the buffer up to numBytes
    return true;
}



bool ProtoFile::Readline(char* buffer, unsigned int& bufferSize)
{
//    TRACE("ProtoFile::Readline: enter\n");
    unsigned int count = 0;
    unsigned int length = bufferSize;
    char* ptr = buffer;

    while(count < length)
    {
        unsigned int one = 1;

        if(bufferedRead(ptr, one))
        {
            if(one == 0)  //hit eof return;
            {
                //TRACE("ProtoFile::Readline: Hit end of file returning false.\n");
                bufferSize = count; //this is checked to see how much was read in
                return false;
            }
            else
            {
                //read in a char check to see if its end of line char
                if(('\n' == *ptr) || ('\r' == *ptr))
                {
                    // if('\r'==*ptr)
                    //    TRACE("ProtoFile::ReadLine: returning true r\n");
                    //if('\n'==*ptr)
                    //   TRACE("ProtoFile::ReadLine: returning true n\n");
                    *ptr = '\0';
                    bufferSize = count;
                    return true;
                }

                count++;
                ptr++;
            }
        }
        else
        {
            //error on calling ReadBuffer
            PLOG(PL_ERROR, "ProtoFile::Readline() error: ReadBuffer call failed\n");
            return false;
        }
    }

    //We've filled up the buffer provided with no end-of-line
    PLOG(PL_ERROR, "ProtoFile::Readline() error: bufferSize %d is too small)\n", bufferSize);
    return false;
}




size_t ProtoFile::Write(const char* buffer, size_t len)
{
    ASSERT(IsOpen());
    size_t put = 0;

    while(put < len)
    {
        size_t result = write(descriptor, buffer + put, len - put);

        if(result <= 0)
        {

            if(EINTR != errno)
            {
                PLOG(PL_FATAL, "ProtoFile::Write() write(%d) result:%d error: %s\n", len, result, GetErrorString());
                return 0;
            }
        }
        else
        {
            offset += (Offset) result;
            put += result;
        }
    }

    return put;
}




bool ProtoFile::Seek(Offset theOffset)
{
    ASSERT(IsOpen());

    Offset result = lseek(descriptor, theOffset, SEEK_SET);

    if(result == (Offset) - 1)
    {
        PLOG(PL_FATAL, "ProtoFile::Seek() lseek() error: %s\n", GetErrorString());
        return false;
    }
    else
    {
        offset = result;
        return true; // no error
    }
}



bool ProtoFile::Pad(Offset theOffset)
{
    if(theOffset > GetSize())
    {
        if(Seek(theOffset - 1))
        {
            char byte = 0;

            if(1 != Write(&byte, 1))
            {
                PLOG(PL_FATAL, "ProtoFile::Pad() write error: %s\n", GetErrorString());
                return false;
            }
        }
        else
        {
            PLOG(PL_FATAL, "ProtoFile::Pad() seek error: %s\n", GetErrorString());
            return false;
        }
    }

    return true;
}



ProtoFile::Offset ProtoFile::GetSize() const
{
    ASSERT(IsOpen());

    struct stat info;
    int result = fstat(descriptor, &info);

    if(result)
    {
        PLOG(PL_FATAL, "Error getting file size: %s\n", GetErrorString());
        return 0;
    }
    else
    {
        return info.st_size;
    }

}




//==========================================================================================================

/***********************************************
 * The ProtoDirectoryIterator classes is used to
 * walk directory trees for file transmission
 */
ProtoDirectoryIterator::ProtoDirectoryIterator() : current(NULL)
{

}

ProtoDirectoryIterator::~ProtoDirectoryIterator()
{
    Close();
}



bool ProtoDirectoryIterator::Open(const char *thePath)
{
    if(current)
    {
        Close();
    }

    if(thePath && access(thePath, X_OK))

    {
        PLOG(PL_FATAL, "ProtoDirectoryIterator: can't access directory: %s\n", thePath);
        return false;
    }

    current = new ProtoDirectory(thePath);

    if(current && current->Open())
    {
        path_len = (int) strlen(current->Path());
        path_len = MIN(PATH_MAX, path_len);
        return true;
    }
    else
    {
        PLOG(PL_FATAL, "ProtoDirectoryIterator: can't open directory: %s\n", thePath);

        if(current)
        {
            delete current;
        }

        current = NULL;
        return false;
    }
} 



void ProtoDirectoryIterator::Close()
{
    ProtoDirectory* d;

    while((d = current))
    {
        current = d->parent;
        d->Close();
        delete d;
    }
}



bool ProtoDirectoryIterator::GetPath(char* pathBuffer)
{
    if(current)
    {
        ProtoDirectory* d = current;

        while(d->parent)
        {
            d = d->parent;
        }

        strncpy(pathBuffer, d->Path(), PATH_MAX);
        return true;
    }
    else
    {
        pathBuffer[0] = '\0';
        return false;
    }
}




bool ProtoDirectoryIterator::GetNextFile(char* fileName)
{
    if(!current)
    {
        return false;
    }

    struct dirent *dp;

    while((dp = readdir(current->dptr)))
    {
        // Make sure it's not "." or ".."
        if(dp->d_name[0] == '.')
        {
            if((1 == strlen(dp->d_name)) ||
               ((dp->d_name[1] == '.') && (2 == strlen(dp->d_name))))
            {
                continue;  // skip "." and ".." directory names
            }
        }

        current->GetFullName(fileName);
        strcat(fileName, dp->d_name);
        ProtoFile::Type type = ProtoFile::GetType(fileName);

        if(ProtoFile::NORMAL == type)
        {
            int nameLen = strlen(fileName);
            nameLen = MIN(PATH_MAX, nameLen);
            nameLen -= path_len;
            memmove(fileName, fileName + path_len, nameLen);

            if(nameLen < PATH_MAX)
            {
                fileName[nameLen] = '\0';
            }

            return true;
        }
        else if(ProtoFile::DIRECTORY == type && search_dirs)
        {
            ProtoDirectory *dir = new ProtoDirectory(dp->d_name, current);

            if(dir && dir->Open())
            {
                // Push sub-directory onto stack and search it
                current = dir;
                return GetNextFile(fileName);
            }
            else
            {
                // Couldn't open this one, try next one
                if(dir)
                {
                    delete dir;
                }
            }
        }
        else
        {
            // ProtoFile::INVALID, try next one
        }
    }  // end while(readdir())

    // Pop up a level and recursively continue or finish if done
    if(current->parent)
    {
        char path[PATH_MAX];
        current->parent->GetFullName(path);
        current->Close();
        ProtoDirectory *dir = current;
        current = current->parent;
        delete dir;
        return GetNextFile(fileName);
    }
    else
    {
        current->Close();
        delete current;
        current = NULL;
        return false;  // no more files remain
    }
}






void
ProtoDirectoryIterator::Recursive(bool stepIntoDirs)
{
    search_dirs = stepIntoDirs;
    return;
}








//==========================================================================================================

ProtoDirectoryIterator::ProtoDirectory::ProtoDirectory(const char* thePath,  ProtoDirectory* theParent) : parent(theParent), dptr(NULL)
{
    strncpy(path, thePath, PATH_MAX);
    size_t len  = MIN(PATH_MAX, strlen(path));

    if((len < PATH_MAX) && (PROTO_PATH_DELIMITER != path[len - 1]))
    {
        path[len++] = PROTO_PATH_DELIMITER;

        if(len < PATH_MAX)
        {
            path[len] = '\0';
        }
    }
}



ProtoDirectoryIterator::ProtoDirectory::~ProtoDirectory()
{
    Close();
}


bool ProtoDirectoryIterator::ProtoDirectory::Open()
{
    Close();  // in case it's already open
    char fullName[PATH_MAX];
    GetFullName(fullName);
    // Get rid of trailing PROTO_PATH_DELIMITER
    size_t len = MIN(PATH_MAX, strlen(fullName));

    if(PROTO_PATH_DELIMITER == fullName[len - 1])
    {
        fullName[len - 1] = '\0';
    }

    if((dptr = opendir(fullName)))
    {
        return true;
    }
    else
    {
        return false;
    }
}



void ProtoDirectoryIterator::ProtoDirectory::Close()
{
    if(dptr)
    {
        closedir(dptr);
        dptr = NULL;
    }
}



void ProtoDirectoryIterator::ProtoDirectory::GetFullName(char* ptr)
{
    ptr[0] = '\0';
    RecursiveCatName(ptr);
}




void ProtoDirectoryIterator::ProtoDirectory::RecursiveCatName(char* ptr)
{
    if(parent)
    {
        parent->RecursiveCatName(ptr);
    }

    size_t len = MIN(PATH_MAX, strlen(ptr));
    strncat(ptr, path, PATH_MAX - len);
}









//==========================================================================================================

// Below are some static routines for getting file/directory information
// Is the named item a valid directory or file (or neither)??
ProtoFile::Type ProtoFile::GetType(const char* path)
{
    struct stat file_info;

    if(stat(path, &file_info))
    {
        return INVALID;    // stat() error
    }
    else if((S_ISDIR(file_info.st_mode)))
    {
        return DIRECTORY;
    }
    else
    {
        return NORMAL;
    }
}


ProtoFile::Offset ProtoFile::GetSize(const char* path)
{
    struct stat info;
    int result = stat(path, &info);

    if(result)
    {
        return 0;
    }
    else
    {
        return info.st_size;
    }
}



time_t ProtoFile::GetUpdateTime(const char* path)
{
    struct stat info;
    int result = stat(path, &info);
    if(result)
    {
        return (time_t) 0; // stat() error
    }
    else
    {
        return info.st_ctime;
    }
}



bool ProtoFile::IsLocked(const char* path)
{
    // If file doesn't exist, it's not locked
    if(!Exists(path))
    {
        return false;
    }

    ProtoFile testFile;

    if(!testFile.Open(path, O_WRONLY | O_CREAT))
    {
        return true;
    }
    else if(testFile.Lock())
    {
        // We were able to lock the file successfully
        testFile.Unlock();
        testFile.Close();
        return false;
    }
    else
    {
        testFile.Close();
        return true;
    }
}



bool ProtoFile::Unlink(const char* path)
{
    // Don't unlink a file that is open (locked)
    if(ProtoFile::IsLocked(path))
    {
        return false;
    }

    if(unlink(path))
    {
        PLOG(PL_FATAL, "ProtoFile::Unlink() unlink error: %s\n", GetErrorString());
        return false;
    }

    else
    {
        return true;
    }
}



//=======================================================================================================
ProtoFileList::ProtoFileList() : this_time(0), big_time(0), last_time(0), updates_only(false), head(NULL), tail(NULL), next(NULL)
{

}

ProtoFileList::~ProtoFileList()
{
    Destroy();
}


void ProtoFileList::Destroy()
{
    while((next = head))
    {
        head = next->next;
        delete next;
    }

    tail = NULL;
}


bool ProtoFileList::Append(const char* path)
{
    FileItem* theItem = NULL;

    switch(ProtoFile::GetType(path))
    {
        case ProtoFile::NORMAL:
            theItem = new FileItem(path);
            break;

        case ProtoFile::DIRECTORY:
            theItem = new DirectoryItem(path);
            break;

        default:

            // Allow non-existent files for update_only mode
            // (TBD) allow non-existent directories?
            if(updates_only)
            {
                theItem = new FileItem(path);
            }
            else
            {
                PLOG(PL_FATAL, "ProtoFileList::Append() Bad file/directory name: %s\n",
                     path);
                return false;
            }

            break;
    }

    if(theItem)
    {
        theItem->next = NULL;

        if((theItem->prev = tail))
        {
            tail->next = theItem;
        }
        else
        {
            head = theItem;
        }

        tail = theItem;
        return true;
    }
    else
    {
        PLOG(PL_FATAL, "ProtoFileList::Append() Error creating file/directory item: %s\n",
             GetErrorString());
        return false;
    }
}


bool ProtoFileList::Remove(const char* path)
{
    FileItem* nextItem = head;
    size_t pathLen = strlen(path);
    pathLen = MIN(pathLen, PATH_MAX);

    while(nextItem)
    {
        size_t nameLen = strlen(nextItem->Path());
        nameLen = MIN(nameLen, PATH_MAX);
        nameLen = MAX(nameLen, pathLen);

        if(!strncmp(path, nextItem->Path(), nameLen))
        {
            if(nextItem == next)
            {
                next = nextItem->next;
            }

            if(nextItem->prev)
            {
                nextItem->prev = next = nextItem->next;
            }
            else
            {
                head = nextItem->next;
            }

            if(nextItem->next)
            {
                nextItem->next->prev = nextItem->prev;
            }
            else
            {
                tail = nextItem->prev;
            }

            return true;
        }
    }

    return false;
}



bool ProtoFileList::GetNextFile(char* pathBuffer)
{
    if(!next)
    {
        next = head;
        reset = true;
    }

    if(next)
    {
        if(next->GetNextFile(pathBuffer, reset, updates_only,
                             last_time, this_time, big_time))
        {
            reset = false;
            return true;
        }
        else
        {
            if(next->next)
            {
                next = next->next;
                reset = true;
                return GetNextFile(pathBuffer);
            }
            else
            {
                reset = false;
                return false;  // end of list
            }
        }
    }
    else
    {
        return false;  // empty list
    }
}



void ProtoFileList::GetCurrentBasePath(char* pathBuffer)
{
    if(next)
    {
        if(ProtoFile::DIRECTORY == next->GetType())
        {
            strncpy(pathBuffer, next->Path(), PATH_MAX);
            size_t len = strlen(pathBuffer);
            len = MIN(len, PATH_MAX);

            if(PROTO_PATH_DELIMITER != pathBuffer[len - 1])
            {
                if(len < PATH_MAX)
                {
                    pathBuffer[len++] = PROTO_PATH_DELIMITER;
                }

                if(len < PATH_MAX)
                {
                    pathBuffer[len] = '\0';
                }
            }
        }
        else  // ProtoFile::NORMAL
        {
            const char* ptr = strrchr(next->Path(), PROTO_PATH_DELIMITER);

            if(ptr++)
            {
                size_t len = ptr - next->Path();
                strncpy(pathBuffer, next->Path(), len);
                pathBuffer[len] = '\0';
            }
            else
            {
                pathBuffer[0] = '\0';
            }
        }
    }
    else
    {
        pathBuffer[0] = '\0';
    }
}






//=======================================================================================================
ProtoFileList::FileItem::FileItem(const char* thePath) : prev(NULL), next(NULL)
{
    size_t len = strlen(thePath);
    len = MIN(len, PATH_MAX);
    strncpy(path, thePath, PATH_MAX);
    size = ProtoFile::GetSize(thePath);
}

ProtoFileList::FileItem::~FileItem()
{

}

bool ProtoFileList::FileItem::GetNextFile(char* thePath, bool reset, bool updatesOnly, time_t lastTime, time_t thisTime, time_t& bigTime)
{
    if(reset)
    {
        if(updatesOnly)
        {
            time_t updateTime = ProtoFile::GetUpdateTime(thePath);

            if(updateTime > bigTime)
            {
                bigTime = updateTime;
            }

            if((updateTime <= lastTime) || (updateTime > thisTime))
            {
                return false;
            }
        }

        strncpy(thePath, path, PATH_MAX);
        return true;
    }
    else
    {
        return false;
    }
}






//=======================================================================================================
ProtoFileList::DirectoryItem::DirectoryItem(const char* thePath) : ProtoFileList::FileItem(thePath)
{

}

ProtoFileList::DirectoryItem::~DirectoryItem()
{
    diterator.Close();
}



bool ProtoFileList::DirectoryItem::GetNextFile(char* thePath, bool reset, bool updatesOnly, time_t lastTime, time_t thisTime, time_t& bigTime)
{
    if(reset)
    {
        /* For now we are going to poll all files in a directory individually
          since directory update times aren't always changed when files are
          are replaced within the directory tree ... uncomment this code
          if you only want to check directory nodes that have had their
          change time updated
           if (updates_only)
           {
               // Check to see if directory has been touched
               time_t update_time = ProtoFile::GetUpdateTime(path);
               if (updateTime > bigTime) *bigTime = updateTime;
               if ((updateTime <= lastTime) || (updateTime > thisTime))
                   return false;
           } */

        if(!diterator.Open(path))
        {
            PLOG(PL_FATAL, "ProtoFileList::DirectoryItem::GetNextFile() Directory iterator init error\n");
            return false;
        }
    }

    strncpy(thePath, path, PATH_MAX);
    size_t len = strlen(thePath);
    len = MIN(len, PATH_MAX);

    if((PROTO_PATH_DELIMITER != thePath[len - 1]) && (len < PATH_MAX))
    {
        thePath[len++] = PROTO_PATH_DELIMITER;

        if(len < PATH_MAX)
        {
            thePath[len] = '\0';
        }
    }

    char tempPath[PATH_MAX];

    while(diterator.GetNextFile(tempPath))
    {
        size_t maxLen = PATH_MAX - len;
        strncat(thePath, tempPath, maxLen);

        if(updatesOnly)
        {
            time_t updateTime = ProtoFile::GetUpdateTime(thePath);

            if(updateTime > bigTime)
            {
                bigTime = updateTime;
            }

            if((updateTime <= lastTime) || (updateTime > thisTime))
            {
                thePath[len] = '\0';
                continue;
            }
        }

        return true;
    }

    return false;
}




