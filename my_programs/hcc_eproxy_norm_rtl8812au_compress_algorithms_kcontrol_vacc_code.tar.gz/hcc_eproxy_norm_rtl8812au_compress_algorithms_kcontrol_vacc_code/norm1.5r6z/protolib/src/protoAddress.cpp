

/**
* @file protoAddress.cpp
*
* @brief Network address container class with support for IPv4, IPv6, and "SIM" address types. Also includes functions for name/address resolution.
*/

#include "protoAddress.h"
#include "protoSocket.h"  // for ProtoSocket::GetInterfaceAddress() routines
#include "protoDebug.h"   // for print out of warnings, etc



/**
 * @file protoAddress.cpp
 * @brief Network address container class.
 */
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netdb.h>
#include <unistd.h>     // for gethostname()


#include <stdlib.h>  // for atoi()
#include <stdio.h>   // for sprintf()
#include <string.h>  // for memset()



const ProtoAddress PROTO_ADDR_NONE;




ProtoAddress::ProtoAddress() : type(INVALID), length(0)
{
    memset(&addr, 0, sizeof(addr));
}

ProtoAddress::ProtoAddress(const ProtoAddress& theAddr)
{
    *this = theAddr;
}

ProtoAddress::~ProtoAddress()
{

}




// This infers the ProtoAddress::Type from length (in bytes)
ProtoAddress::Type ProtoAddress::GetType(UINT8 addrLength)
{
    switch(addrLength)
    {
        case 4:
            return IPv4;

        case 16:
            return IPv6;

        case 6:
            return ETH;

        default:
            return INVALID;
    }
}


bool ProtoAddress::IsMulticast() const
{
    switch(type)
    {
        case IPv4:
        {
            UINT32 addrVal = (UINT32)(((struct sockaddr_in*) &addr)->sin_addr.s_addr);
            return (((UINT32)(htonl(0xf0000000) & addrVal)) == htonl(0xe0000000));
        }

        case ETH:
            // ethernet broadcast also considered mcast here
            return (0 != (0x01 & ((char*) &addr) [0]));

        default:
            return false;
    }
}


bool ProtoAddress::IsBroadcast() const
{
    switch(type)
    {
        case IPv4:
        {
            UINT32 addrVal = (UINT32)(((struct sockaddr_in*) &addr)->sin_addr.s_addr);
            return (addrVal == htonl(0xffffffff));
        }

        case ETH:
        {
            const unsigned char temp[6] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
            return (0 == memcmp((const char*) &addr, temp, 6));
        }

        default:
            return false;
    }
}



bool ProtoAddress::IsLoopback() const
{
    switch(type)
    {
        case IPv4:
        {
            // This was changed since any 127.X.X.X is a loopback address
            // and many Linux configs have started using this fact for some purpose
            UINT32 addrVal = (UINT32)((struct sockaddr_in*) &addr)->sin_addr.s_addr;
            return (0x7f == (ntohl(addrVal) >> 24));
        }

        case ETH:
            return false;

        default:
            return false;
    }
}


bool ProtoAddress::IsUnspecified() const
{
    switch(type)
    {
        case IPv4:
        {
            UINT32 addrVal = (UINT32)(((struct sockaddr_in*) &addr)->sin_addr.s_addr);
            return (0x00000000 == addrVal);
        }

        case ETH:
            return false;

        default:
            return false;
    }
}


bool ProtoAddress::IsLinkLocal() const
{
    switch(type)
    {
        case IPv4:
        {
            UINT32 addrVal = (UINT32)(((struct sockaddr_in*) &addr)->sin_addr.s_addr);

            if(((UINT32)(htonl(0xffffff00) & addrVal)) == (UINT32) htonl(0xe0000000))
            {
                // Address is 224.0.0/24 multicast.
                return true;
            }
            else if(((UINT32)(htonl(0xffff0000) & addrVal)) == (UINT32) htonl(0xa9fe0000))
            {
                // Address is 169.254/16 unicast.
                return true;
            }

            return false;
        }

        case ETH:
            return false;  // or return true???

        default:
            return false;
    }
}  // end ProtoAddress::IsLinkLocal()



bool ProtoAddress::IsSiteLocal() const
{
    switch(type)
    {
        case IPv4:
        case ETH:
            return false;

        default:
            return false;
    }
}



/**
*
* @brief Translates the address to a host string
*
* @param buffer
* @param buflen
*
* @retval Returns the address as a host string
*/
const char* ProtoAddress::GetHostString(char* buffer, unsigned int buflen) const
{
    static char altBuffer[256];
    altBuffer[255] = '\0';
    buflen = (NULL != buffer) ? buflen : 255;

#ifdef _UNICODE
    buflen /= 2;
#endif // _UNICODE

    buffer = (NULL != buffer) ? buffer : altBuffer;

    switch(type)
    {
        case IPv4:
            strncpy(buffer, inet_ntoa(((struct sockaddr_in *) &addr)->sin_addr), buflen);
            return buffer;

        case ETH:
        {
            // Print as a hexadecimal number
            unsigned int len = 0;

            for(int i = 0; i < 6; i++)
            {
                if(len < buflen)
                {
                    if(i < 1)
                    {
                        len += sprintf(buffer + len, "%02x", ((unsigned char*) &addr) [i]);
                    }
                    else
                    {
                        len += sprintf(buffer + len, ":%02x", ((unsigned char*) &addr) [i]);
                    }
                }
                else
                {
                    break;
                }
            }

            return buffer;
        }

        default:
            PLOG(PL_ERROR, "ProtoAddress: GetHostString(): Invalid address type!\n");
            return "(invalid address)";
    }
}


void ProtoAddress::PortSet(UINT16 thePort)
{
    SetPort(thePort);
}

void ProtoAddress::SetPort(UINT16 thePort)
{
    switch(type)
    {
        case IPv4:
            ((struct sockaddr_in*) &addr)->sin_port = htons(thePort);
            break;

        case ETH:
            break;

        default:
            Reset(IPv4);
            SetPort(thePort);
            break;
    }
}

UINT16 ProtoAddress::GetPort() const
{
    switch(type)
    {
        case IPv4:
            return ntohs(((struct sockaddr_in *) &addr)->sin_port);

        case ETH:
        default:
            return 0;  // port 0 is an invalid port
    }
}




/**
*
* @brief Resets the address to zero or high values.
*
* @param theType
* @param zero
*
*/
void ProtoAddress::Reset(ProtoAddress::Type theType, bool zero)
{
    char value = zero ? 0x00 : 0xff;
    char fill[16];

    switch(theType)
    {
        case IPv4:
            memset(fill, value, 4);
            SetRawHostAddress(IPv4, fill, 4);
            break;

        case ETH:
            memset(fill, value, 6);
            SetRawHostAddress(ETH, fill, 6);
            break;

        default:
            PLOG(PL_ERROR, "ProtoAddress::Reset() Invalid address type!\n");
            break;
    }

    SetPort(0);
}





/**
*
* @brief Initializes the address (incl. port) from the provided sockaddr struct.
*
* @param theAddr
*
* @retval Returns success/failure
*/
bool ProtoAddress::SetSockAddr(const struct sockaddr& theAddr)
{
    switch(theAddr.sa_family)
    {
        case AF_INET:
            //((struct sockaddr_in&)addr) = ((struct sockaddr_in&)theAddr);
            // memcpy() safer here due to memory alignment issues on
            // some compilers / platforms (e.g. Android ARM)??
            memcpy(&addr, &theAddr, sizeof(struct sockaddr_in));
            type = IPv4;
            length = 4;
            return true;

        default:
            PLOG(PL_ERROR, "ProtoAddress::SetSockAddr() warning: Invalid address type: %d\n", theAddr.sa_family);
            type = INVALID;
            length = 0;
            return false;
    }
}  // end ProtoAddress:SetAddress()




/**
*
* @brief Initializes the address from the buffer contents
*
* @param theType
* @param buffer
* @param buflen
*
* @retval Returns success/failure
*/
bool ProtoAddress::SetRawHostAddress(ProtoAddress::Type theType, const char* buffer, UINT8 buflen)
{
    UINT16 thePort = GetPort();

    switch(theType)
    {
        case IPv4:
            if(buflen > 4)
            {
                return false;
            }

            type = IPv4;
            length = 4;
            memset(& ((struct sockaddr_in*) &addr)->sin_addr, 0, 4);
            memcpy(& ((struct sockaddr_in*) &addr)->sin_addr, buffer, buflen);
            ((struct sockaddr_in*) &addr)->sin_family = AF_INET;
            break;

        case ETH:
            if(buflen > 6)
            {
                return false;
            }

            type = ETH;
            length = 6;
            memset((char*) &addr, 0, 6);
            memcpy((char*) &addr, buffer, buflen);
            break;

        default:
            PLOG(PL_ERROR, "ProtoAddress::SetRawHostAddress() Invalid address type!\n");
            return false;
    }

    SetPort(thePort);
    return true;
}


const char* ProtoAddress::GetRawHostAddress() const
{
    switch(type)
    {
        case IPv4:
            return ((char*) & ((struct sockaddr_in*) &addr)->sin_addr);

        case ETH:
            return ((char*) &addr);

        default:
            PLOG(PL_ERROR, "ProtoAddress::RawHostAddress() Invalid address type!\n");
            return NULL;
    }
}



//zb: build the prefix mask with the same vaule of the two addresses!
unsigned int ProtoAddress::SetCommonHead(const ProtoAddress& theAddr)
{
    unsigned int commonBytes = 0;

    if((GetType() != theAddr.GetType()) && (!IsValid()))
    {
        Reset(GetType());
        return commonBytes;
    }

    const char *myRawHost = GetRawHostAddress();
    const char *theirRawHost = theAddr.GetRawHostAddress();

    for(commonBytes = 1 ; commonBytes <= GetLength() ; commonBytes++)  //zb: find the same prefix bytes of the two address

    {
        if(memcmp(myRawHost, theirRawHost, commonBytes))
        {
            commonBytes--;
            ApplyPrefixMask(commonBytes * 8);  //ApplyPrefixMask takes size in bits
            return commonBytes;
        }
    }

    return GetLength();
}



//zb: build the suffix mask with the same vaule of the two addresses!
unsigned int ProtoAddress::SetCommonTail(const ProtoAddress& theAddr)
{
    unsigned int commonBytes = 0;

    if((GetType() != theAddr.GetType()) && (!IsValid()))
    {
        Reset(GetType());
        return commonBytes;
    }

    const char *myRawHost = GetRawHostAddress();
    const char *theirRawHost = theAddr.GetRawHostAddress();

    for(commonBytes = 1 ; commonBytes <= GetLength() ; commonBytes++)
    {
        if(memcmp(myRawHost - commonBytes + GetLength(), theirRawHost - commonBytes + GetLength(), commonBytes))
        {
            commonBytes--;
            ApplySuffixMask(commonBytes * 8);
            return commonBytes;
        }
    }

    return GetLength();
}



UINT8 ProtoAddress::GetPrefixLength() const
{
    UINT8* ptr = NULL;
    UINT8 maxBytes = 0;

    switch(type)
    {
        case IPv4:
            ptr = ((UINT8*) & ((struct sockaddr_in*) &addr)->sin_addr);
            maxBytes = 4;
            break;

        case ETH:
        default:
            PLOG(PL_ERROR, "ProtoAddress::PrefixLength() Invalid address type of %d!\n", type);
            return 0;
    }

    UINT8 prefixLen = 0;

    for(UINT8 i = 0; i < maxBytes; i++)
    {
        if(0xff == *ptr)
        {
            prefixLen += 8;
            ptr++;
        }
        else
        {
            UINT8 bit = 0x80;

            while(0 != (bit & *ptr))
            {
                bit >>= 1;
                prefixLen += 1;
            }

            break;
        }
    }

    return prefixLen;
}


void ProtoAddress::GeneratePrefixMask(ProtoAddress::Type type, UINT8 prefixLen)
{
    unsigned char* ptr;

    switch(type)
    {
        case IPv4:
            ptr = ((unsigned char*) & ((struct sockaddr_in*) &addr)->sin_addr);
            break;

        case ETH:
            ptr = ((unsigned char*) &addr);
            break;

        default:
            PLOG(PL_ERROR, "ProtoAddress::GeneratePrefixMask() Invalid address type!\n");
            return ;
    }


    Reset(type, true);  // init to zero

    if(prefixLen > GetLength())
    {
        prefixLen = GetLength();
    }

    while(0 != prefixLen)
    {
        if(prefixLen < 8)
        {
            *ptr = 0xff << (8 - prefixLen);
            return;
        }
        else
        {
            *ptr++ = 0xff;
            prefixLen -= 8;
        }
    }
}



void ProtoAddress::ApplyPrefixMask(UINT8 prefixLen)  //zb: fill the prefix with "1" to build the mask
{
    UINT8* ptr = NULL;
    UINT8 maxLen = 0;

    switch(type)
    {
        case IPv4:
            ptr = ((UINT8*) & ((struct sockaddr_in*) &addr)->sin_addr);
            maxLen = 32;
            break;

        case ETH:
        default:
            PLOG(PL_ERROR, "ProtoAddress::ApplyPrefixMask() Invalid address type!\n");
            return;
    }

    if(prefixLen >= maxLen)
    {
        return;
    }

    UINT8 nbytes = prefixLen >> 3;
    UINT8 remainder = prefixLen & 0x07;

    if(remainder)
    {
        ptr[nbytes] &= (UINT8)(0x00ff << (8 - remainder));
        nbytes++;
    }

    memset(ptr + nbytes, 0, length - nbytes);
}




void ProtoAddress::ApplySuffixMask(UINT8 suffixLen)  //zb: fill the suffix with "1" to build the mask
{
    UINT8* ptr = NULL;
    UINT8 maxLen = 0;

    switch(type)
    {
        case IPv4:
            ptr = ((UINT8*) & ((struct sockaddr_in*) &addr)->sin_addr);
            maxLen = 32;
            break;

        case ETH:
        default:
            PLOG(PL_ERROR, "ProtoAddress::ApplyPrefixMask() Invalid address type!\n");
            return;
    }

    if(suffixLen >= maxLen)
    {
        return;
    }

    UINT8 nbytes = suffixLen >> 3;
    UINT8 remainder = suffixLen & 0x07;

    if(remainder)
    {
        ptr[(maxLen >> 3) - nbytes - 1] &= (UINT8)(0x00ff >> (8 - remainder));
        nbytes++;
    }

    memset(ptr, 0, length - nbytes);
}



//zb: 192.168.100.12 --> 192.168.0.0
void ProtoAddress::GetSubnetAddress(UINT8 prefixLen,  ProtoAddress& subnetAddr) const
{
    subnetAddr = *this;
    UINT8* ptr = NULL;
    UINT8 maxLen = 0;

    switch(type)
    {
        case IPv4:
            ptr = ((UINT8*) & ((struct sockaddr_in*) &subnetAddr.addr)->sin_addr);
            maxLen = 32;
            break;

        case ETH:
            return;

        default:
            PLOG(PL_ERROR, "ProtoAddress::GetSubnetAddress() Invalid address type!\n");
            return;
    }

    if(prefixLen >= maxLen)
    {
        return;
    }

    UINT8 nbytes = prefixLen >> 3;
    UINT8 remainder = prefixLen & 0x07;

    if(remainder)
    {
        ptr[nbytes] &= (UINT8)(0xff << (8 - remainder));
        nbytes++;
    }

    memset(ptr + nbytes, 0, length - nbytes);
}



//zb: 192.168.100.12 --> 192.168.255.255
void ProtoAddress::GetBroadcastAddress(UINT8 prefixLen,  ProtoAddress& broadcastAddr) const
{
    broadcastAddr = *this;
    UINT8* ptr = NULL;
    UINT8 maxLen = 0;

    switch(type)
    {
        case IPv4:
            ptr = ((UINT8*) & ((struct sockaddr_in*) &broadcastAddr.addr)->sin_addr);
            maxLen = 32;
            break;

        case ETH:
            ptr = (UINT8*) &broadcastAddr.addr;
            maxLen = 48;
            prefixLen = 0;
            break;

        default:
            PLOG(PL_ERROR, "ProtoAddress::GetBroadcastAddress() Invalid address type!\n");
            return;
    }

    if(prefixLen >= maxLen)
    {
        return;
    }

    UINT8 nbytes = prefixLen >> 3;
    UINT8 remainder = prefixLen & 0x07;

    if(remainder)
    {
        ptr[nbytes] |= (0x00ff >> remainder);
        nbytes++;
    }

    memset(ptr + nbytes, 0xff, length - nbytes);
}



//zb: 224.0.0.1 --> 0x01, 0x00, 0x5e, 0x00, 0x00, 0x01
void ProtoAddress::GetEthernetMulticastAddress(const ProtoAddress& ipMcastAddr)
{
    if(!ipMcastAddr.IsMulticast())
    {
        Invalidate();
        return;
    }

    // Ethernet mcast addr begins with 00:00:5e ...
    UINT8 ethMcastAddr[6];
    const UINT8* ipAddrPtr;

    switch(ipMcastAddr.GetType())
    {
        // Point to lower 24-bits of IP mcast address
        case IPv4:
            ethMcastAddr[0] = 0x01;
            ethMcastAddr[1] = 0x00;
            ethMcastAddr[2] = 0x5e;
            ipAddrPtr = (const UINT8*)(ipMcastAddr.GetRawHostAddress() + 1);
            ethMcastAddr[3] = (0x7f & ipAddrPtr[0]);
            ethMcastAddr[4] = ipAddrPtr[1];
            ethMcastAddr[5] = ipAddrPtr[2];
            break;

            break;

        default:
            PLOG(PL_ERROR, "ProtoAddress::GetEthernetMulticastAddress() error : non-IP address!\n");
            Invalidate();
            return;
    }

    SetRawHostAddress(ETH, (char*) ethMcastAddr, 6);
}


void ProtoAddress::SetEndIdentifier(UINT32 endIdentifier)
{
    endIdentifier = htonl(endIdentifier);

    switch(type)
    {
        case IPv4:
            SetRawHostAddress(IPv4, (char*) &endIdentifier, 4);
            break;

        case ETH:
        {
            UINT8 vendorHash;
            memcpy(&vendorHash, (char*) &endIdentifier, 1);
            UINT8* addrPtr = (UINT8*) &addr;
            addrPtr[0] = addrPtr[1] = addrPtr[2] = vendorHash;
            memcpy(addrPtr + 3, (((char*) &endIdentifier) + 1), 3);
            break;
        }

        default:
            SetRawHostAddress(IPv4, (char*) &endIdentifier, 4);
            break;
    }
}




UINT32 ProtoAddress::GetEndIdentifier() const
{
    switch(type)
    {
        case IPv4:
        {
            return ntohl(((struct sockaddr_in*) &addr)->sin_addr.s_addr);

        }

        case ETH:
        {
            // a dumb little hash: MSB is randomized vendor id, 3 LSB's is device id
            UINT8* addrPtr = (UINT8*) &addr;
            UINT8 vendorHash = addrPtr[0] ^ addrPtr[1] ^ addrPtr[2]; //zb: xor
            UINT32 temp32;
            memcpy((char*) &temp32, &vendorHash, 1);
            memcpy((((char*) &temp32) + 1), addrPtr + 3, 3);
            return ntohl(temp32);
        }

        default:
            PLOG(PL_ERROR, "ProtoAddress::GetEndIdentifier(): Invalid address type!\n");
            return INADDR_NONE;
    }
}



bool ProtoAddress::HostIsEqual(const ProtoAddress& theAddr) const
{
    if(!IsValid() && !theAddr.IsValid())
    {
        return true;
    }

    switch(type)
    {
        case IPv4:
        {
            struct in_addr myAddrIn = ((struct sockaddr_in *) &addr)->sin_addr;
            struct in_addr theAddrIn = ((struct sockaddr_in *) & (theAddr.addr))->sin_addr;

            if((IPv4 == theAddr.type) && (myAddrIn.s_addr == theAddrIn.s_addr))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        case ETH:
            if((ETH == theAddr.type) && 0 == memcmp((char*) &addr, (char*) &theAddr.addr, 6))
            {
                return true;
            }
            else
            {
                return false;
            }

        default:
            PLOG(PL_ERROR, "ProtoAddress::HostIsEqual(): Invalid address type!\n");
            return false;
    }
}



int ProtoAddress::CompareHostAddr(const ProtoAddress& theAddr) const
{
    switch(type)
    {
        case IPv4:
            return memcmp(& ((struct sockaddr_in *) &addr)->sin_addr, & ((struct sockaddr_in *) &theAddr.addr)->sin_addr, 4);

        case ETH:
            return memcmp((char*) &addr, (char*) &theAddr.addr, 6);

        default:
            PLOG(PL_ERROR, "ProtoAddress: CompareHostAddr(): Invalid address type!\n");
            return -1;
    }
}


bool ProtoAddress::ResolveEthFromString(const char* text)
{
    unsigned int a[6];
    char b[6];

    if(6 != sscanf(text, "%x:%x:%x:%x:%x:%x", &a[0], &a[1], &a[2], &a[3], &a[4], &a[5]))
    {
        PLOG(PL_DEBUG, "ProtoAddress: ResolveEthFromString(%s): Invalid ETH address type!\n", text);
        return false;
    }

    for(int i = 0; i <= 5; i++)
    {
        b[i] = (char) a[i];
    }

    SetRawHostAddress(ETH, b, 6);
    return true;
}




// non-DNS (i.e numeric address notation)
bool ProtoAddress::ConvertFromString(const char* text)
{
    // First try for IPv4 addr
    struct sockaddr_in sa;

    if(1 == inet_pton(AF_INET, text, &sa.sin_addr))
    {
        sa.sin_family = AF_INET;
        return SetSockAddr((struct sockaddr&) sa);
    }


    // Finally, see if it's an Ethertype addr string
    return ResolveEthFromString(text);
}





// (TBD) Provide a mechanism for async lookup with optional user interaction
bool ProtoAddress::ResolveFromString(const char* text)
{
    UINT16 thePort = GetPort();

    // Use DNS to look it up
    // Get host address, looking up by hostname if necessary
    // Use this approach as a backup
    // 1) is it a "dotted decimal" address?
    struct sockaddr_in* addrPtr = (struct sockaddr_in*) &addr;

    if(INADDR_NONE != (addrPtr->sin_addr.s_addr = inet_addr(text)))
    {
        addrPtr->sin_family = AF_INET;
    }
    else
    {
        // 2) Use "gethostbyname()" to lookup IPv4 address
        struct hostent *hp = gethostbyname(text);

        if(hp)
        {
            addrPtr->sin_family = hp->h_addrtype;
            memcpy((char*) &addrPtr->sin_addr,  hp->h_addr,  hp->h_length);
        }
        else
        {
            PLOG(PL_WARN, "ProtoAddress::ResolveFromString() gethostbyname() error: %s\n", GetErrorString());
            return false;
        }
    }

    if(addrPtr->sin_family == AF_INET)
    {
        type = IPv4;
        length =  4;  // IPv4 addresses are always 4 bytes in length
        SetPort(thePort);  // restore port number
        return true;
    }
    else
    {
        PLOG(PL_ERROR, "ProtoAddress::ResolveFromString gethostbyname() returned unsupported address family!\n");
        return false;
    }
}




bool ProtoAddress::ResolveToName(char* buffer, unsigned int buflen) const
{
    struct hostent* hp = NULL;

    switch(type)
    {
        case IPv4:
            hp = gethostbyaddr((char*) & (((struct sockaddr_in*) &addr)->sin_addr), 4, AF_INET);
            break;

        case ETH:
            GetHostString(buffer, buflen);
            return true;

        default:
            PLOG(PL_ERROR, "ProtoAddress::ResolveToName(): Invalid address type!\n");
            return false;
    }


    if(hp)
    {
        // Use the hp->h_name hostname by default
        size_t nameLen = 0;
        unsigned int dotCount = 0;
        strncpy(buffer, hp->h_name, buflen);
        nameLen = strlen(hp->h_name);
        nameLen = nameLen < buflen ? nameLen : buflen;
        const char* ptr = hp->h_name;

        while((ptr = strchr(ptr, '.')))
        {
            ptr++;
            dotCount++;
        }

        char** alias = hp->h_aliases;

        // Use first alias by default
        if(alias && *alias && buffer)
        {
            // Try to find the fully-qualified name
            // (longest alias with most '.')
            while(NULL != *alias)
            {
                unsigned int dc = 0;
                ptr = *alias;
                bool isArpa = false;

                while(NULL != (ptr = strchr(ptr, '.')))
                {
                    ptr++;
                    // don't let ".arpa" aliases override
                    isArpa = (0 == strcmp(ptr, "arpa"));
                    dc++;
                }

                size_t alen = strlen(*alias);
                bool override = (dc > dotCount) ||
                                ((dc == dotCount) && (alen > nameLen));

                if(isArpa)
                {
                    override = false;
                }

                if(override)
                {
                    strncpy(buffer, *alias, buflen);
                    nameLen = alen;
                    dotCount = dc;
                    nameLen = nameLen < buflen ? nameLen : buflen;
                }

                alias++;
            }
        }

        return true;
    }
    else
    {
        PLOG(PL_WARN, "ProtoAddress::ResolveToName() gethostbyaddr() error: %s\n", GetErrorString());
        GetHostString(buffer, buflen);
        return false;
    }
}




bool ProtoAddress::ResolveLocalAddress(char* buffer, unsigned int buflen)
{
    UINT16 thePort = GetPort();  // save port number
    // Try to get fully qualified host name if possible
    char hostName[256];
    hostName[0] = '\0';
    hostName[255] = '\0';

    int result = gethostname(hostName, 255);

    if(result)
    {
        PLOG(PL_ERROR, "ProtoAddress::ResolveLocalAddress(): gethostname() error: %s\n", GetErrorString());
        return false;
    }
    else
    {
        // Terminate at first '.' in name, if any (e.g. MacOS .local)
        char* dotPtr = strchr(hostName, '.');

        if(NULL != dotPtr)
        {
            *dotPtr = '\0';
        }

        bool lookupOK = ResolveFromString(hostName);

        if(lookupOK)
        {
            // Invoke ResolveToName() to get fully qualified name and use that address
            ResolveToName(hostName, 255);
            lookupOK = ResolveFromString(hostName);
        }

        if(!lookupOK || IsLoopback())
        {
            // darn it! lookup failed or we got the loopback address ...
            // So, try to troll interfaces for a decent address
            // using our handy-dandy ProtoSocket::GetInterfaceInfo routines
            gethostname(hostName, 255);

            if(!lookupOK)
            {
                // Set IPv4 loopback address as fallback id if no good address is found
                UINT32 loopbackAddr = htonl(0x7f000001);
                SetRawHostAddress(IPv4, (char*) &loopbackAddr, 4);
            }

            // Use "ProtoSocket::FindLocalAddress()" that trolls through network interfaces
            // looking for an interface with a non-loopback address assigned.
            if(!ProtoSocket::FindLocalAddress(IPv4, *this))
            {

            }

            if(IsLoopback() || IsUnspecified())
            {
                PLOG(PL_ERROR, "ProtoAddress::ResolveLocalAddress() warning: only loopback address found!\n");
            }
        }

        SetPort(thePort);  // restore port number
        buflen = buflen < 255 ? buflen : 255;

        if(buffer)
        {
            strncpy(buffer, hostName, buflen);
        }

        return true;
    }
}






//=======================================================================================================
ProtoAddressList::ProtoAddressList()
{
}

ProtoAddressList::~ProtoAddressList()
{
    Destroy();
}

void ProtoAddressList::Destroy()
{
    Item* entry;

    while(NULL != (entry = static_cast<Item*>(addr_tree.GetRoot())))
    {
        //zb: Before  Remove, *entry is the root node of the tree! But after Remove, it is the smallest node of the tree.
        addr_tree.Remove(*entry);
        delete entry;
    }
}

bool ProtoAddressList::Insert(const ProtoAddress& theAddress, const void* userData)
{
    if(!theAddress.IsValid())
    {
        PLOG(PL_ERROR, "ProtoAddressList::Insert() error: invalid address\n");
        return false;
    }

    if(!Contains(theAddress))
    {
        Item* entry = new Item(theAddress, userData);

        if(NULL == entry)
        {
            PLOG(PL_ERROR, "ProtoAddressList::Insert() new ProtoTree::Item error: %s\n", GetErrorString());
            return false;
        }

        addr_tree.Insert(*entry);
    }

    return true;
}



void ProtoAddressList::Remove(const ProtoAddress& addr)
{
    Item* entry = static_cast<Item*>(addr_tree.Find(addr.GetRawHostAddress(), addr.GetLength() << 3));

    if(NULL != entry)
    {
        addr_tree.Remove(*entry);
        delete entry;
    }
}


bool ProtoAddressList::AddList(ProtoAddressList& addrList)
{
    ProtoAddressList::Iterator iterator(addrList);
    ProtoAddress addr;

    while(iterator.GetNextAddress(addr))
    {
        if(!Insert(addr))
        {
            return false;
        }
    }

    return true;
}


void ProtoAddressList::RemoveList(ProtoAddressList& addrList)
{
    ProtoAddressList::Iterator iterator(addrList);
    ProtoAddress addr;

    while(iterator.GetNextAddress(addr))
    {
        Remove(addr);
    }
}



// Returns the root of the addr_tree
bool ProtoAddressList::GetFirstAddress(ProtoAddress& firstAddr) const
{
    Item* rootItem = static_cast<Item*>(addr_tree.GetRoot());

    if(NULL != rootItem)
    {
        firstAddr = rootItem->GetAddress();
        return true;
    }
    else
    {
        firstAddr.Invalidate();
        return false;
    }
}







//=========================================================================================================
ProtoAddressList::Item::Item(const ProtoAddress& theAddr, const void* userData) : addr(theAddr), user_data(userData)
{

}

ProtoAddressList::Item::~Item()
{

}


ProtoAddressList::Iterator::Iterator(ProtoAddressList& addrList) : ptree_iterator(addrList.addr_tree)
{

}

ProtoAddressList::Iterator::~Iterator()
{

}

bool ProtoAddressList::Iterator::GetNextAddress(ProtoAddress& nextAddr)
{
    Item* nextItem = static_cast<Item*>(ptree_iterator.GetNextItem());

    if(NULL != nextItem)
    {
        nextAddr = nextItem->GetAddress();
        return true;
    }
    else
    {
        nextAddr.Invalidate();
        return false;
    }
}

bool ProtoAddressList::Iterator::PeekNextAddress(ProtoAddress& nextAddr)
{
    Item* nextItem = static_cast<Item*>(ptree_iterator.PeekNextItem());

    if(NULL != nextItem)
    {
        nextAddr = nextItem->GetAddress();
        return true;
    }
    else
    {
        nextAddr.Invalidate();
        return false;
    }
}




