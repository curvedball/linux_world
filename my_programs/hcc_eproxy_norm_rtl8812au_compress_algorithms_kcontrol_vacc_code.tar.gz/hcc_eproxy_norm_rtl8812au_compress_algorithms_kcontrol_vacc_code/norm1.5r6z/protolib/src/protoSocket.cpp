


/**
* @file protoSocket.cpp
*
* @brief Network socket container class that provides consistent interface for use of operating system (or simulation environment) transport sockets.
*/
#include <unistd.h>
#include <stdlib.h>  // for atoi()
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <errno.h>
#include <fcntl.h>



#include "protoSocket.h"
#include "protoDebug.h"

#include <stdio.h>
#include <string.h>




// Use this macro (-DSOCKLEN_T=X) in your system's Makefile if the type socklen_t is
// not defined for your system (use "man getsockname" to see what type is required).
#ifdef SOCKLEN_T
#define socklen_t SOCKLEN_T
#else
#endif // if/else SOCKLEN_T



const ProtoSocket::Handle ProtoSocket::INVALID_HANDLE = -1;





//=========================================================================================================
ProtoSocket::ProtoSocket(ProtoSocket::Protocol theProtocol)
    : domain(IPv4), protocol(theProtocol), raw_protocol(RAW), state(CLOSED),
      handle(INVALID_HANDLE), port(-1), tos(0), ecn_capable(false), ip_recvdstaddr(false),
      notifier(NULL), notify_output(false), notify_input(true), notify_exception(false),
      listener(NULL), user_data(NULL)
{

}

ProtoSocket::~ProtoSocket()
{
    Close();

    if(NULL != listener)
    {
        delete listener;
        listener = NULL;
    }
}


bool ProtoSocket::SetBlocking(bool blocking)
{
    if(blocking)
    {
        if(-1 == fcntl(handle, F_SETFL, fcntl(handle, F_GETFL, 0) & ~O_NONBLOCK))
        {
            PLOG(PL_ERROR, "ProtoSocket::SetBlocking() fcntl(F_SETFL(~O_NONBLOCK)) error: %s\n", GetErrorString());
            return false;
        }
    }
    else
    {
        if(-1 == fcntl(handle, F_SETFL, fcntl(handle, F_GETFL, 0) | O_NONBLOCK))
        {
            PLOG(PL_ERROR, "ProtoSocket::SetBlocking() fcntl(F_SETFL(O_NONBLOCK)) error: %s\n", GetErrorString());
            return false;
        }
    }

    return true;
}




bool ProtoSocket::SetNotifier(ProtoSocket::Notifier* theNotifier)
{
    if(notifier != theNotifier)
    {
        if(IsOpen())
        {
            // 1) Detach old notifier, if any
            if(notifier)
            {
                notifier->UpdateSocketNotification(*this, 0);

                if(!theNotifier)
                {
                    // Reset socket to "blocking"
                    if(!SetBlocking(true))
                    {
                        PLOG(PL_ERROR, "ProtoSocket::SetNotifier() SetBlocking(true) error\n", GetErrorString());
                    }
                }
            }
            else
            {
                // Set socket to "non-blocking"
                if(!SetBlocking(false))
                {
                    PLOG(PL_ERROR, "ProtoSocket::SetNotifier() SetBlocking(false) error\n", GetErrorString());
                    return false;
                }
            }

            // 2) Set and update new notifier (if applicable)
            notifier = theNotifier;

            if(!UpdateNotification())
            {
                notifier = NULL;
                return false;
            }
        }
        else
        {
            notifier = theNotifier;
        }
    }

    return true;
}



ProtoAddress::Type ProtoSocket::GetAddressType()
{
    switch(domain)
    {
        case LOCAL:
            return ProtoAddress::INVALID;

        case IPv4:
            return ProtoAddress::IPv4;

        default:
            return ProtoAddress::INVALID;
    }
}





/**
 * WIN32 needs the address type determine IPv6 _or_ IPv4 socket domain
 * @note WIN32 can't do IPv4 on an IPV6 socket!
 * Vista and above support dual stack sockets
 */
bool ProtoSocket::Open(UINT16 thePort,  ProtoAddress::Type   addrType, bool bindOnOpen)
{
    if(IsOpen())
    {
        Close();
    }

    domain = IPv4;
    int socketType = 0;

    switch(protocol)
    {
        case UDP:
            socketType = SOCK_DGRAM;
            break;

        case TCP:
            socketType = SOCK_STREAM;
            break;

        case RAW:
            socketType = SOCK_RAW;
            break;

        default:
            PLOG(PL_ERROR, "ProtoSocket::Open() error: Unsupported protocol\n");
            return false;
    }


    int family = AF_INET;
    int socketProtocol = 0;  // use default socket protocol type if not RAW

    if(SOCK_RAW == socketType)
    {
        switch(raw_protocol)
        {
            case RAW:
                socketProtocol = IPPROTO_RAW;
                break;

            case UDP:
                socketProtocol = IPPROTO_UDP;
                break;

            case TCP:
                socketProtocol = IPPROTO_TCP;
                break;

            default:
                socketProtocol = IPPROTO_RAW;
        }
    }

    if(INVALID_HANDLE == (handle = socket(family, socketType, socketProtocol)))
    {
        PLOG(PL_ERROR, "ProtoSocket: socket() error: %s\n", GetErrorString());
        return false;
    }

    // (TBD) set IP_HDRINCL option for raw socket
    state = IDLE;

    // Don't pass descriptor to child processes
    if(-1 == fcntl(handle, F_SETFD, FD_CLOEXEC))
    {
        PLOG(PL_ERROR, "ProtoSocket::Open() fcntl(FD_CLOEXEC) warning: %s\n", GetErrorString());
    }

    // Make the socket non-blocking
    if(notifier)
    {
        if(-1 == fcntl(handle, F_SETFL, fcntl(handle, F_GETFL, 0) | O_NONBLOCK))
        {
            PLOG(PL_ERROR, "ProtoSocket::Open() fcntl(F_SETFL(O_NONBLOCK)) error: %s\n", GetErrorString());
            Close();
            return false;
        }
    }

    if(bindOnOpen)
    {
        if(!Bind(thePort))
        {
            Close();
            return false;
        }
    }
    else
    {
        port = -1;

        if(!UpdateNotification())
        {
            PLOG(PL_ERROR, "ProtoSocket::Open() error installing async notification\n");
            Close();
            return false;
        }
    }

    // Do the following in case TOS or "ecn_capable" was set _before_
    // ProtoSocket::Open() was called.  Note that the "IPv6" flow label
    // "traffic class" is also updated as needed for IPv6 sockets
    if((0 != tos) || (ecn_capable))
    {
        SetTOS(tos);
    }

    ip_recvdstaddr = false;  // make sure this is reset
    return true;
}




bool ProtoSocket::SetRawProtocol(Protocol theProtocol)
{
    bool wasOpen = false;
    UINT16 portSave = 0;

    if(IsOpen())
    {
        portSave = GetPort();
        Close();
        wasOpen = true;
    }

    protocol = RAW;
    raw_protocol = theProtocol;

    if(wasOpen)
    {
        return Open(portSave);
    }
    else
    {
        return true;
    }
}



bool ProtoSocket::UpdateNotification()
{
    if(NULL != notifier)
    {
        if(IsOpen() && !SetBlocking(false))
        {
            PLOG(PL_ERROR, "ProtoSocket::UpdateNotification() SetBlocking() error\n");
            return false;
        }

        int notifyFlags = NOTIFY_NONE;

        if(NULL != listener)
        {
            switch(protocol)
            {
                case UDP:
                case RAW:
                    switch(state)
                    {
                        case CLOSED:
                            break;

                        default:
                            if(notify_input && IsBound())
                            {
                                notifyFlags = NOTIFY_INPUT;
                            }
                            else
                            {
                                notifyFlags = NOTIFY_NONE;
                            }

                            if(notify_output)
                            {
                                notifyFlags |= NOTIFY_OUTPUT;
                            }

                            if(IsOpen() && notify_exception)
                            {
                                notifyFlags |= NOTIFY_EXCEPTION;
                            }

                            break;
                    }

                    break;

                case TCP:
                    switch(state)
                    {
                        case CLOSED:
                        case IDLE:
                            break;

                        case CONNECTING:
                            notifyFlags = NOTIFY_OUTPUT;
                            break;

                        case LISTENING:
                            notifyFlags = NOTIFY_INPUT;
                            break;

                        case CONNECTED:
                            if(notify_input)
                            {
                                notifyFlags = NOTIFY_INPUT;
                            }

                            if(notify_output)
                            {
                                notifyFlags |= NOTIFY_OUTPUT;
                            }

                            break;
                    }

                    break;

                default:
                    PLOG(PL_ERROR, "ProtoSocket::UpdateNotification Error: Unsupported protocol.\n");
                    break;
            }
        }

        return notifier->UpdateSocketNotification(*this, notifyFlags);  //zb2: virtual function
    }
    else
    {
        return true;
    }
}





void ProtoSocket::OnNotify(ProtoSocket::Flag theFlag)  //zb200
{
    ProtoSocket::Event event = INVALID_EVENT;

    if(NOTIFY_INPUT == theFlag)
    {
        switch(state)
        {
            case CLOSED:
                break;

            case IDLE:
                event = RECV;
                break;

            case CONNECTING:
                break;

            case LISTENING:
                // (TBD) check for error
                event = ACCEPT;
                break;

            case CONNECTED:
                event = RECV; //zb200
                break;
        }
    }
    else if(NOTIFY_OUTPUT == theFlag)
    {
        switch(state)
        {
            case CLOSED:
                break;

            case IDLE:
                event = SEND;
                break;

            case CONNECTING:
            {

                int err;
                socklen_t errsize = sizeof(err);

                if(getsockopt(handle, SOL_SOCKET, SO_ERROR, (char*) &err, &errsize))
                {
                    PLOG(PL_ERROR, "ProtoSocket::OnNotify() getsockopt() error: %s\n", GetErrorString());
                }
                else if(0 != err)
                {
                    PLOG(PL_DEBUG, "ProtoSocket::OnNotify() getsockopt() error: %s\n", GetErrorString());
                    Disconnect();
                    event = ERROR_;  // TBD - should this be DISCONNECT instead?
                }
                else
                {
                    event = CONNECT;
                    state = CONNECTED;
                    UpdateNotification();
                }

                break;
            }

            case LISTENING:
                break;

            case CONNECTED:
                event = SEND;
                break;
        }
    }
    else if(NOTIFY_EXCEPTION == theFlag)
    {
        event = EXCEPTION;
    }
    else if(NOTIFY_ERROR == theFlag)
    {
        TRACE("ProtoSocket NOTIFY_ERROR notification\n");

        switch(state)
        {
            case CONNECTING:
            case CONNECTED:
                Disconnect();

            default:
                event = ProtoSocket::ERROR_;
                break;
        }
    }
    else  // NOTIFY_NONE  (connection was purposefully ended)
    {
        switch(state)
        {
            case CONNECTING:

            //PLOG(PL_ERROR, "ProtoSocket::OnNotify() Connect() error: %s\n", GetErrorString());
            case CONNECTED:
                Disconnect();
                event = DISCONNECT;
                break;

            default:
                break;
        }
    }

    ASSERT(INVALID_EVENT != event);

    if(listener)
    {
        listener->on_event(*this, event);
    }
}







bool ProtoSocket::Bind(UINT16 thePort, const ProtoAddress* localAddress)
{
    if(IsBound())
    {
        Close();
    }

    if(IsOpen() && (NULL != localAddress) && (GetAddressType() != localAddress->GetType()))
    {
        Close();
    }

    if(!IsOpen())
    {
        ProtoAddress::Type addrType = localAddress ? localAddress->GetType() : ProtoAddress::IPv4;

        if(!Open(thePort, addrType, false))
        {
            PLOG(PL_ERROR, "ProtoSocket::Bind() error opening socket on port %d\n", thePort);
            return false;
        }
    }


    struct sockaddr socketAddr;

    socklen_t addrSize = sizeof(struct sockaddr_in);

    memset((char*) &socketAddr, 0, sizeof(struct sockaddr_in));

    ((struct sockaddr_in*) &socketAddr)->sin_family = AF_INET;

    ((struct sockaddr_in*) &socketAddr)->sin_port = htons(thePort);

    if(NULL != localAddress)
    {
        ((struct sockaddr_in*) &socketAddr)->sin_addr = ((struct sockaddr_in*)(&localAddress->GetSockAddr()))->sin_addr;
    }
    else
    {
        struct in_addr inAddr;
        inAddr.s_addr = htonl(INADDR_ANY);
        ((struct sockaddr_in*) &socketAddr)->sin_addr = inAddr;
    }



    // Bind the socket to the given port
    if(bind(handle, (struct sockaddr*) &socketAddr, addrSize) < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket::Bind() bind() error: %s\n", GetErrorString());
        return false;
    }

    // Get socket name so we know our port number
    socklen_t sockLen = addrSize;

    if(getsockname(handle, (struct sockaddr*) &socketAddr, &sockLen) < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket::Bind() getsockname() error: %s\n", GetErrorString());
        return false;
    }

    switch(((struct sockaddr*) &socketAddr)->sa_family)
    {
        case AF_INET:
            source_addr.SetSockAddr((struct sockaddr&) socketAddr);
            port = ntohs(((struct sockaddr_in*) &socketAddr)->sin_port);
            break;

        default:
            PLOG(PL_ERROR, "ProtoSocket::Bind() error: getsockname() returned unknown address type\n");
            return false;
    }

    return UpdateNotification();
}




bool ProtoSocket::Shutdown()
{

    if(IsConnected() && TCP == protocol)
    {
        bool notifyOutput = notify_output;

        if(notifyOutput)
        {
            notify_output = false;
            UpdateNotification();
        }

        if(0 != shutdown(handle, 1))
        {
            if(notifyOutput)
            {
                notify_output = true;
                UpdateNotification();
            }

            PLOG(PL_ERROR, "ProtoSocket::Shutdown() error: %s\n", GetErrorString());
            return false;
        }
        else
        {
            return true;
        }
    }
    else
    {
        PLOG(PL_ERROR, "ProtoSocket::Shutdown() error: socket not connected\n");
        return false;
    }
}



void ProtoSocket::Close()
{
    if(IsOpen())
    {
        if(IsConnected())
        {
            Disconnect();
        }

        state = CLOSED;
        UpdateNotification();

        if(INVALID_HANDLE != handle)
        {
            close(handle);
            handle = INVALID_HANDLE;
        }

        port = -1;
    }
}




bool ProtoSocket::Connect(const ProtoAddress& theAddress)
{
    if(IsConnected())
    {
        Disconnect();
    }

    if(!IsOpen() && !Open(0, theAddress.GetType()))
    {
        PLOG(PL_ERROR, "ProtoSocket::Connect() error opening socket!\n");
        return false;
    }

    socklen_t addrSize = sizeof(struct sockaddr_in);
    state = CONNECTING;

    if(!UpdateNotification())
    {
        PLOG(PL_ERROR, "ProtoSocket::Connect() error updating notification\n");
        state = IDLE;
        return false;
    }

    int result = connect(handle, &theAddress.GetSockAddr(), addrSize);

    if(0 != result)
    {
        if(EINPROGRESS != errno)
        {
            PLOG(PL_ERROR, "ProtoSocket::Connect() connect() error: %s\n", GetErrorString());
            state = IDLE;
            UpdateNotification();
            return false;
        }
    }
    else
    {
        state = CONNECTED;

        if(!UpdateNotification())
        {
            PLOG(PL_ERROR, "ProtoSocket::Connect() error updating notification\n");
            state = IDLE;
            return false;
        }
    }

    // Use getsockname() to get local "port" and "source_addr"

    struct sockaddr socketAddr;
    socklen_t addrLen = sizeof(socketAddr);

    if(getsockname(handle, (struct sockaddr*) &socketAddr, &addrLen) < 0)
    {
        // getsockname() failed, so issue a warning
        PLOG(PL_ERROR, "ProtoSocket::Connect() getsockname() error: %s\n", GetErrorString());
        source_addr.Invalidate();
    }
    else
    {
        switch(((struct sockaddr*) &socketAddr)->sa_family)
        {
            case AF_INET:
                source_addr.SetSockAddr((struct sockaddr&) socketAddr);
                port = ntohs(((struct sockaddr_in*) &socketAddr)->sin_port);
                break;

            case AF_UNIX:
                source_addr.Invalidate();
                port = -1;
                break;

            default:
                PLOG(PL_ERROR, "ProtoSocket::Connect() error: getsockname() returned unknown address type");
                break;
        }  // end switch()
    }

    destination = theAddress;  // cache the destination address
    return true;
}




void ProtoSocket::Disconnect()
{
    if(IsConnected() || IsConnecting())
    {
        state = IDLE;

        //source_addr.Invalidate();
        //destination.Invalidate();
        UpdateNotification();

        struct sockaddr nullAddr;
        memset(&nullAddr, 0, sizeof(struct sockaddr));

        if(TCP != protocol)
        {
            nullAddr.sa_family = AF_UNSPEC;

            if(connect(handle, &nullAddr, sizeof(struct sockaddr)))
            {
                if(EAFNOSUPPORT != errno)
                {
                    PLOG(PL_WARN, "ProtoSocket::Disconnect() connect() error: %s)\n", GetErrorString());
                }
            }
        }
        else
        {
            // TCP doesn't like the connect(nullAddr) trick, best to just close
            // (TBD) should we Close() and re-Open() the socket here?
            // (but can't easily recall all socket options, so best not I guess)
            //UINT16 savePort = GetPort();

            // MACOSX & LINUX trigger server resets differently...

            nullAddr.sa_family = AF_UNSPEC;

            if(connect(handle, &nullAddr, sizeof(struct sockaddr)))
            {
                if(EAFNOSUPPORT != errno)
                {
                    PLOG(PL_WARN, "ProtoSocket::Disconnect() connect() error (%s)\n", GetErrorString());
                }

                Close();
            }

            //Open(savePort);
        }
    }
}





bool ProtoSocket::Listen(UINT16 thePort)
{
    if(IsBound())
    {
        if((0 != thePort) && (thePort != port))
        {
            PLOG(PL_ERROR, "ProtoSocket::Listen() error: socket bound to different port.\n");
            return false;
        }
    }
    else
    {
        if(!Bind(thePort))
        {
            PLOG(PL_ERROR, "ProtoSocket::Listen() error binding socket.\n");
            return false;
        }
    }

    if(UDP == protocol)
    {
        state = CONNECTED;
    }
    else
    {
        state = LISTENING;
    }

    if(!UpdateNotification())
    {
        state = IDLE;
        PLOG(PL_ERROR, "ProtoSocket::Listen() error updating notification\n");
        return false;
    }

    if(UDP == protocol)
    {
        return true;
    }

    if(listen(handle, 5) < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket: listen() error: %s\n", GetErrorString());
        return false;
    }

    return true;
}





bool ProtoSocket::Accept(ProtoSocket* newSocket)
{
    ProtoSocket& theSocket = (NULL != newSocket) ? *newSocket : *this;

    // Clone server socket
    if(this != &theSocket)
    {
        // TBD - should override ProtoSocket copy operator to delete old listener???
        if(NULL != theSocket.listener)
        {
            delete theSocket.listener;
        }

        theSocket = *this;
        theSocket.listener = NULL; // this->listener is duplicated later (or should we save our old one)
    }

    struct sockaddr socketAddr;

    socklen_t addrLen = sizeof(socketAddr);

    Handle theHandle = accept(handle, (struct sockaddr*) &socketAddr, &addrLen);

    if(INVALID_HANDLE == theHandle)
    {

        PLOG(PL_ERROR, "ProtoSocket::Accept() accept() error: %s\n", GetErrorString());

        if(this != &theSocket)
        {
            theSocket.handle = INVALID_HANDLE;
            theSocket.state = CLOSED;
        }

        return false;
    }

    if(LOCAL != domain)
    {
        theSocket.destination.SetSockAddr((struct sockaddr&) socketAddr);
    }

    // Get the socket name so we know our port number
    addrLen = sizeof(socketAddr);

    if(getsockname(theHandle, (struct sockaddr*) &socketAddr, &addrLen) < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket::Accept() getsockname() error: %s\n", GetErrorString());

        if(this != &theSocket)
        {
            theSocket.handle = INVALID_HANDLE;
            theSocket.state = CLOSED;
        }

        return false;
    }

    switch(((struct sockaddr*) &socketAddr)->sa_family)
    {
        case AF_INET:
            theSocket.source_addr.SetSockAddr((struct sockaddr&) socketAddr);
            theSocket.port = ntohs(((struct sockaddr_in*) &socketAddr)->sin_port);
            break;

        case AF_UNIX:
            theSocket.source_addr.Invalidate();
            theSocket.port = -1;
            break;

        default:
            PLOG(PL_ERROR, "ProtoSocket::Accept() error: getsockname() returned unknown address type");

            if(this != &theSocket)
            {
                theSocket.handle = INVALID_HANDLE;
                theSocket.state = CLOSED;
            }

            return false;;
    }

    if(this == &theSocket)
    {
        state = CLOSED;
        UpdateNotification();
        close(theSocket.handle);
    }
    else
    {
        // TBD - keep old listener / notifier and just do an UpdateNotification() here
        if(NULL != listener)
        {
            if(NULL == (theSocket.listener = listener->duplicate()))
            {
                PLOG(PL_ERROR, "ProtoSocket::Accept() listener duplication error: %s\n", ::GetErrorString());
                theSocket.Close();
                return false;
            }
        }

        if(NULL != notifier)
        {
            theSocket.handle = theHandle;

            if(!theSocket.SetBlocking(false))
            {
                PLOG(PL_ERROR, "ProtoSocket::Accept() SetBlocking(false) error\n");
                theSocket.Close();
                return false;
            }
        }
    }  // end if/else (this == &theSocket)

    theSocket.handle = theHandle;
    theSocket.state = CONNECTED;
    theSocket.UpdateNotification();
    return true;
}





bool ProtoSocket::Send(const char* buffer, unsigned int& numBytes)
{
    if(IsConnected())
    {
        int result = send(handle, buffer, (size_t) numBytes, 0);

        if(result < 0)
        {
            numBytes = 0;

            switch(errno)
            {
                case EINTR:
                case EAGAIN:
                    return true;

                case ENETRESET:
                case ECONNABORTED:
                case ECONNRESET:
                case ESHUTDOWN:
                case ENOTCONN:
                    OnNotify(NOTIFY_ERROR);
                    break;

                default:
                    PLOG(PL_ERROR, "ProtoSocket::Send() send() error: %s\n", GetErrorString());
                    break;
            }

            return false;
        }
        else
        {
            numBytes = result;
            return true;
        }
    }
    else
    {
        PLOG(PL_ERROR, "ProtoSocket::Send() error unconnected socket\n");
        numBytes = 0;
        return false;
    }
}



bool ProtoSocket::Recv(char* buffer, unsigned int& numBytes)
{
    int result = recv(handle, buffer, numBytes, 0);

    if(result < 0)
    {
        numBytes = 0;

        switch(errno)
        {
            case EINTR:
            case EAGAIN:
                PLOG(PL_WARN, "ProtoSocket::Recv() recv() error: %s\n", GetErrorString());
                return true;
                break;

            case ENETRESET:
            case ECONNABORTED:
            case ECONNRESET:
            case ESHUTDOWN:
            case ENOTCONN:
                OnNotify(NOTIFY_ERROR);
                break;

            default:
                PLOG(PL_ERROR, "ProtoSocket::Recv() recv() error: %s\n", GetErrorString());
                break;
        }

        return false;
    }
    else
    {
        numBytes = result;

        if(0 == result)
        {
            OnNotify(NOTIFY_NONE);
        }

        return true;
    }
}



bool ProtoSocket::SendTo(const char* buffer, unsigned int buflen, const ProtoAddress& dstAddr)
{
    if(!IsOpen())
    {
        if(!Open(0, dstAddr.GetType()))
        {
            PLOG(PL_ERROR, "ProtoSocket::SendTo() error: socket not open\n");
            return false;
        }
    }

    if(IsConnected())
    {
        unsigned int numBytes = buflen;

        if(!Send(buffer, numBytes))
        {

            PLOG(PL_WARN, "ProtoSocket::SendTo() error: Send() error\n");
            return false;
        }
        else if(numBytes != buflen)
        {

            PLOG(PL_ERROR, "ProtoSocket::SendTo() error: Send() incomplete\n");
            return false;
        }
        else
        {
            return true;
        }
    }
    else
    {
        socklen_t addrSize;
        addrSize = sizeof(struct sockaddr_in);

        int result = sendto(handle, buffer, (size_t) buflen, 0, &dstAddr.GetSockAddr(), addrSize);

        if(result < 0)
        {
            PLOG(PL_WARN, "ProtoSocket::SendTo() sendto() error: %s\n", GetErrorString());
            return false;
        }
        else
        {
            return true;
        }
    }
}



bool ProtoSocket::RecvFrom(char* buffer, unsigned int& numBytes, ProtoAddress& sourceAddr)
{
    if(!IsBound())
    {
        PLOG(PL_ERROR, "ProtoSocket::RecvFrom() error: socket not bound\n");
        numBytes = 0;
    }

    struct sockaddr sockAddr;

    socklen_t addrLen = sizeof(sockAddr);

    // Just do a regular recvfrom()  (TBD - for Win32, should we be using WSARecvFrom()???)
    int result = recvfrom(handle, buffer, (size_t) numBytes, 0, (struct sockaddr*) &sockAddr, &addrLen);

    if(result < 0)
    {
        numBytes = 0;

        switch(errno)
        {
            case EINTR:
            case EAGAIN:
                //PLOG(PL_WARN, "ProtoSocket::Recv() recv() error: %s\n", GetErrorString());
                return true;
                break;

            default:
                PLOG(PL_ERROR, "ProtoSocket::Recv() recv() error: %s\n", GetErrorString());
                break;
        }

        return false;
    }
    else
    {
        numBytes = result;
        sourceAddr.SetSockAddr(* ((struct sockaddr*) &sockAddr));

        if(!sourceAddr.IsValid())
        {
            PLOG(PL_ERROR, "ProtoSocket::RecvFrom() Unsupported address type!\n");
            return false;
        }

        return true;
    }
}





void ProtoSocket::EnableRecvDstAddr()
{
    if(!ip_recvdstaddr)
    {
        int enable = 1;
#ifdef IP_RECVDSTADDR

        if(setsockopt(handle, IPPROTO_IP, IP_RECVDSTADDR, (char*) &enable, sizeof(enable)) < 0)
        {
            PLOG(PL_WARN, "ProtoSocket::EnableRecvDstAddr() setsocktopt(IP_RECVDSTADDR) error: %s\n", GetErrorString());
        }

#else

        if(setsockopt(handle, IPPROTO_IP, IP_PKTINFO, (char*) &enable, sizeof(enable)) < 0)
        {
            PLOG(PL_WARN, "ProtoSocket::EnableRecvDstAddr() setsocktopt(IP_PKTINFO) error: %s\n", GetErrorString());
        }

#endif

        ip_recvdstaddr = true;
    }
}






// Variant RecvFrom() that uses recvmsg() to get destAddr information
bool ProtoSocket::RecvFrom(char* buffer, unsigned int& numBytes, ProtoAddress& sourceAddr, ProtoAddress& destAddr)
{
    if(!IsBound())
    {
        PLOG(PL_ERROR, "ProtoSocket::RecvFrom() error: socket not bound\n");
        numBytes = 0;
    }

    if(!ip_recvdstaddr)
    {
        EnableRecvDstAddr();  // should enable ahead of time to make sure you don't miss any
    }


    struct sockaddr sockAddr;

    socklen_t addrLen = sizeof(sockAddr);

    char cdata[64];

    struct msghdr msg;  // TBD - should we bzero() our "cdata" and "msg" here???

    struct iovec iov[1];

    iov[0].iov_base = buffer;

    iov[0].iov_len = numBytes;

    msg.msg_name = &sockAddr;

    msg.msg_namelen = addrLen;

    msg.msg_iov = iov;

    msg.msg_iovlen = 1;

    msg.msg_control = cdata;

    msg.msg_controllen = 64;//sizeof(cdata);

    msg.msg_flags = 0;

    destAddr.Invalidate();

    int result = recvmsg(handle, &msg, 0);

    if(result < 0)
    {
        numBytes = 0;

        switch(errno)
        {
            case EINTR:
            case EAGAIN:
                //PLOG(PL_WARN, "ProtoSocket::Recv() recv() error: %s\n", GetErrorString());
                return true;
                break;

            default:
                PLOG(PL_ERROR, "ProtoSocket::Recv() recv() error: %s\n", GetErrorString());
                break;
        }

        return false;
    }
    else
    {
        numBytes = result;
        sourceAddr.SetSockAddr(* ((struct sockaddr*) &sockAddr));

        if(!sourceAddr.IsValid())
        {
            PLOG(PL_ERROR, "ProtoSocket::RecvFrom() Unsupported address type!\n");
            return false;
        }

        // Get destAddr info
        for(struct cmsghdr* cmptr = CMSG_FIRSTHDR(&msg); cmptr != NULL; cmptr = CMSG_NXTHDR(&msg, cmptr))
        {
            if(cmptr->cmsg_level == IPPROTO_IP)
            {
#ifdef IP_RECVDSTADDR

                if((cmptr->cmsg_level == IPPROTO_IP) && (cmptr->cmsg_type == IP_RECVDSTADDR))
                {
                    destAddr.SetRawHostAddress(ProtoAddress::IPv4, (char*) CMSG_DATA(cmptr), 4);
                }

#else

                if(cmptr->cmsg_type == IP_PKTINFO)
                {
                    struct in_pktinfo* pktInfo = (struct in_pktinfo*)((void*) CMSG_DATA(cmptr));
                    destAddr.SetRawHostAddress(ProtoAddress::IPv4, (char*)(&pktInfo->ipi_addr), 4);
                }

#endif // if/else IP_RECVDSTADDR
            }
        }

        return true;
    }
}





/**
 * @note On WinNT 4.0 (or earlier?), we seem to need WSAJoinLeaf() for multicast to work
 * Thus NT 4.0 probably doesn't support IPv6 multicast???
 * So, here we use WSAJoinLeaf() iff the OS is NT and version 4.0 or earlier.
 */
// Full SSM support is still work in progress (only supported on Linux and Mac OSX for moment)
//Parameters:
// optional interface name for group join
// optional source address for SSM support
bool ProtoSocket::JoinGroup(const ProtoAddress& groupAddress, const char* interfaceName, const ProtoAddress* sourceAddress)
{
    if(!IsOpen() && !Open(0, groupAddress.GetType(), false))
    {
        PLOG(PL_ERROR, "ProtoSocket::JoinGroup() error: unable to open socket\n");
        return false;
    }

    int result;

    if(NULL == sourceAddress)
    {
        // non-SSM (non, Source Specific Multicast, Join)
        struct ip_mreq mreq;
        mreq.imr_multiaddr = ((struct sockaddr_in*) &groupAddress.GetSockAddr())->sin_addr;

        if(NULL != interfaceName)
        {
            ProtoAddress interfaceAddress;

            if(GetInterfaceAddress(interfaceName, ProtoAddress::IPv4, interfaceAddress))
            {
                mreq.imr_interface.s_addr = htonl(interfaceAddress.IPv4GetAddress());
            }
            else
            {
                PLOG(PL_ERROR, "ProtoSocket::JoinGroup() error: invalid interface name\n");
                return false;
            }
        }
        else
        {
            mreq.imr_interface.s_addr = INADDR_ANY;
        }

        result = setsockopt(handle, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char*) &mreq, sizeof(mreq));
    }
    else
    {
        // SSM join  (Source Specific Multicast, Join)
        struct ip_mreq_source mreq;
        mreq.imr_multiaddr = ((struct sockaddr_in*) &groupAddress.GetSockAddr())->sin_addr;
        mreq.imr_sourceaddr = ((struct sockaddr_in*) &sourceAddress->GetSockAddr())->sin_addr;

        if(NULL != interfaceName)
        {
            ProtoAddress interfaceAddress;

            if(GetInterfaceAddress(interfaceName, ProtoAddress::IPv4, interfaceAddress))
            {
                mreq.imr_interface.s_addr = htonl(interfaceAddress.IPv4GetAddress());
            }
            else
            {
                PLOG(PL_ERROR, "ProtoSocket::JoinGroup() invalid interface name\n");
                return false;
            }
        }
        else
        {
            mreq.imr_interface.s_addr = INADDR_ANY;
        }

        //
        result = setsockopt(handle, IPPROTO_IP, IP_ADD_SOURCE_MEMBERSHIP, (char*) &mreq, sizeof(mreq));

        if(result  < 0)
        {
            PLOG(PL_ERROR, "ProtoSocket::JoinGroup() setsockopt(IP_ADD_SOURCE_MEMBERSHIP) error: %s\n", strerror(errno));
            return false;
        }

        return true;
    }


    if(result < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket:JoinGroup() setsockopt(add membership) error: %s\n", GetErrorString());
        return false;
    }

    return true;
}  // end ProtoSocket::JoinGroup()



bool ProtoSocket::LeaveGroup(const ProtoAddress& groupAddress, const char* interfaceName, const ProtoAddress* sourceAddress)
{
    if(!IsOpen())
    {
        return true;
    }

    int result;

    if(NULL == sourceAddress)
    {
        // non-SSM
        struct ip_mreq mreq;
        mreq.imr_multiaddr = ((struct sockaddr_in*) &groupAddress.GetSockAddr())->sin_addr;

        if(NULL != interfaceName)
        {
            ProtoAddress interfaceAddress;

            if(GetInterfaceAddress(interfaceName, ProtoAddress::IPv4, interfaceAddress))
            {
                mreq.imr_interface.s_addr = htonl(interfaceAddress.IPv4GetAddress());
            }
            else
            {
                PLOG(PL_ERROR, "ProtoSocket::LeaveGroup() invalid interface name\n");
                return false;
            }
        }
        else
        {
            mreq.imr_interface.s_addr = INADDR_ANY;
        }

        //
        result = setsockopt(handle, IPPROTO_IP, IP_DROP_MEMBERSHIP, (char*) &mreq, sizeof(mreq));
    }
    else
    {
        // SSM
        struct ip_mreq_source   mreq;
        mreq.imr_multiaddr = ((struct sockaddr_in*) &groupAddress.GetSockAddr())->sin_addr;
        mreq.imr_sourceaddr = ((struct sockaddr_in*) &sourceAddress->GetSockAddr())->sin_addr;

        if(interfaceName)
        {
            ProtoAddress interfaceAddress;

            if(GetInterfaceAddress(interfaceName, ProtoAddress::IPv4, interfaceAddress))
            {
                mreq.imr_interface.s_addr = htonl(interfaceAddress.IPv4GetAddress());
            }
            else
            {
                PLOG(PL_ERROR, "ProtoSocket::LeaveGroup() invalid interface name\n");
                return false;
            }
        }
        else
        {
            mreq.imr_interface.s_addr = INADDR_ANY;
        }

        //
        result = setsockopt(handle, IPPROTO_IP, IP_DROP_SOURCE_MEMBERSHIP, (char*) &mreq, sizeof(mreq));
    }


    if(result < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket::LeaveGroup() error leaving multicast group: %s\n", GetErrorString());
        return false;
    }
    else
    {
        return true;
    }
}





bool ProtoSocket::SetTTL(unsigned char ttl)
{

    int result = 0;
    socklen_t hops = (socklen_t) ttl;

    if(protocol != ProtoSocket::TCP)
    {
        result = setsockopt(handle, IPPROTO_IP, IP_MULTICAST_TTL, (char*) &hops, sizeof(hops));
    }

    if(result == 0)
    {
        result = setsockopt(handle, IPPROTO_IP, IP_TTL, (char*) &hops, sizeof(hops));
    }


    if(result < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket: setsockopt(IP_MULTICAST_TTL) error: %s\n", GetErrorString());
        return false;
    }
    else
    {
        return true;
    }
}



bool ProtoSocket::SetTOS(UINT8 theTOS)
{
    if(!IsOpen())
    {
        tos = theTOS;
        return true;
    }

    if(ecn_capable)
    {
        theTOS |= ((UINT8) ECN_ECT0);  // set ECT0 bit
        theTOS &= ~((UINT8) ECN_ECT1);   // clear ECT1 bit
    }

    int tosBits = theTOS;

    //
    int result;
    result =  setsockopt(handle, IPPROTO_IP, IP_TOS, (char*) &tosBits, sizeof(tosBits));

    if(result < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket: setsockopt(IP_TOS) error\n");
        return false;
    }

    tos = theTOS;
    return true;
}




/**
 * (TBD) add mechanism to dither ECN ECT0/ECT1 1-bit "nonce"
 * of RFC3168 (e.g. RFC3540).  For now we set ECT0 bit only.
 */
bool ProtoSocket::SetEcnCapable(bool state)
{
    if(state)
    {
        if(!ecn_capable)
        {
            ecn_capable = true;
            bool result = SetTOS(tos);  // will update saved "tos" value accordingly

            if(!result)
            {
                ecn_capable = false;
            }

            return result;
        }
    }
    else if(ecn_capable)
    {
        ecn_capable = false;
        bool result = SetTOS(tos);

        if(!result)
        {
            ecn_capable = true;
        }

        return result;
    }

    return true;
}





bool ProtoSocket::SetBroadcast(bool broadcast)
{
#ifdef SO_BROADCAST
    int state = broadcast ? 1 : 0;

    if(setsockopt(handle, SOL_SOCKET, SO_BROADCAST, (char*) &state, sizeof(state)) < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket::SetBroadcast(): setsockopt(SO_BROADCAST) error: %s\n", GetErrorString());
        return false;
    }

#endif

    return true;
}




bool ProtoSocket::SetFragmentation(bool enable)
{

#if defined(IP_MTU_DISCOVER)
    // Note PMTUDISC_DONT clears DF flag while PMTUDISC_DO sets DF flag for MTU discovery
    // (thus, IP_PMTUDISC_DONT allows fragmentation to occur)
    int val = enable ? IP_PMTUDISC_DONT : IP_PMTUDISC_DO;

    if(setsockopt(handle, IPPROTO_IP, IP_MTU_DISCOVER, &val, sizeof(val)) < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket::SetFragmentation() setsockopt(IP_MTU_DISCOVER) error: %s\n", GetErrorString());
        return false;
    }

#elif defined(IP_DONTFRAG)
    int df = enable ? 0 : 1;
    int result;
    result = setsockopt(handle, IPPROTO_IP, IP_DONTFRAG, (char*) &df, sizeof(df));

    if(result < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket::SetFragmentation() setsockopt(IP_DONTFRAG) error: %s\n", GetErrorString());
        return false;
    }

#else
    PLOG(PL_WARN, "ProtoSocket::SetFragmentation() warning: IP_MTU_DISCOVER or IP_DONTFRAG socket option not supported!\n");
    return false;
#endif

    return true;
}





bool ProtoSocket::SetLoopback(bool loopback)
{
    ASSERT(IsOpen());

    int result;
    char loop = loopback ? 1 : 0;

    result = setsockopt(handle, IPPROTO_IP, IP_MULTICAST_LOOP, (char*) &loop, sizeof(loop));

    if(result < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket: setsockopt(IP_MULTICAST_LOOP) error: %s\n", GetErrorString());
        return false;
    }
    else
    {
        return true;
    }
}



bool ProtoSocket::SetBindInterface(const char* ifaceName)
{
#ifdef SO_BINDTODEVICE
    size_t nameSize = strlen(ifaceName) + 1;  // includes NULL termination

    if(setsockopt(handle, SOL_SOCKET, SO_BINDTODEVICE, ifaceName, nameSize) < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket::SetBindInterface() error: %s\n", GetErrorString());
        return false;
    }

    return true;
#else
    // TBD - For MacOS/BSD, we can use the IP_RECVIF socket options and recvmsg() calls
    //       (under the hood) and filter incoming datagrams for a specific interface
    //       to _simulate_ the behavior of SO_BINDTODEVICE.  Not yet sure what to do
    //       here for WIN32 systems.

    PLOG(PL_ERROR, "ProtoSocket::SetBindInterface() error: SO_BINDTODEVICE socket option not supported!\n", GetErrorString());
    return false;
#endif
}



bool ProtoSocket::SetMulticastInterface(const char* interfaceName)
{
    if(interfaceName)
    {
        int result;
        struct in_addr localAddr;
        ProtoAddress interfaceAddress;

        if(GetInterfaceAddress(interfaceName, ProtoAddress::IPv4, interfaceAddress))
        {
            localAddr.s_addr = htonl(interfaceAddress.IPv4GetAddress());
        }
        else
        {
            PLOG(PL_ERROR, "ProtoSocket::SetMulticastInterface() invalid interface name: %s\n", interfaceName);
            return false;
        }

        result = setsockopt(handle, IPPROTO_IP, IP_MULTICAST_IF, (char*) &localAddr, sizeof(localAddr));

        if(result < 0)
        {
            PLOG(PL_ERROR, "ProtoSocket: setsockopt(IP_MULTICAST_IF) error: %s\n", GetErrorString());
            return false;
        }
    }

    return true;
}





bool ProtoSocket::SetReuse(bool state)
{
#if defined(SO_REUSEADDR) || defined(SO_REUSEPORT)
    bool success = true;
#else
    return false;
#endif


    int reuse = state ? 1 : 0;

#ifdef SO_REUSEADDR

    if(setsockopt(handle, SOL_SOCKET, SO_REUSEADDR, (char*) &reuse, sizeof(reuse)) < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket: setsockopt(REUSE_ADDR) error: %s\n", GetErrorString());
        success = false;
    }

#endif // SO_REUSEADDR            


#ifdef SO_REUSEPORT  // not defined on Linux for some reason?

    if(setsockopt(handle, SOL_SOCKET, SO_REUSEPORT, (char*) &reuse, sizeof(reuse)) < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket: setsockopt(SO_REUSEPORT) error: %s\n", GetErrorString());
        success = false;
    }

#endif // SO_REUSEPORT
    return success;
}






//====================================================================================================

bool ProtoSocket::SetTxBufferSize(unsigned int bufferSize)
{
    if(!IsOpen())
    {
        PLOG(PL_ERROR, "ProtoSocket::SetTxBufferSize() error: socket closed\n");
        return false;
    }

    unsigned int oldBufferSize = GetTxBufferSize();

    if(setsockopt(handle, SOL_SOCKET, SO_SNDBUF, (char*) &bufferSize, sizeof(bufferSize)) < 0)
    {
        setsockopt(handle, SOL_SOCKET, SO_SNDBUF, (char*) &oldBufferSize, sizeof(oldBufferSize));
        PLOG(PL_ERROR, "ProtoSocket::SetTxBufferSize() setsockopt(SO_SNDBUF) error: %s\n", GetErrorString());
        return false;
    }

    return true;
}




unsigned int ProtoSocket::GetTxBufferSize()
{
    if(!IsOpen())
    {
        return 0;
    }

    unsigned int txBufferSize = 0;
    socklen_t len = sizeof(txBufferSize);

    if(getsockopt(handle, SOL_SOCKET, SO_SNDBUF, (char*) &txBufferSize, &len) < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket::GetTxBufferSize() getsockopt(SO_SNDBUF) error: %s\n", GetErrorString());
        return 0;
    }

    return ((unsigned int) txBufferSize);
}



bool ProtoSocket::SetRxBufferSize(unsigned int bufferSize)
{
    if(!IsOpen())
    {
        PLOG(PL_ERROR, "ProtoSocket::SetRxBufferSize() error: socket closed\n");
        return false;
    }

    unsigned int oldBufferSize = GetTxBufferSize();

    if(setsockopt(handle, SOL_SOCKET, SO_RCVBUF, (char*) &bufferSize, sizeof(bufferSize)) < 0)
    {
        setsockopt(handle, SOL_SOCKET, SO_RCVBUF, (char*) &oldBufferSize, sizeof(oldBufferSize));
        PLOG(PL_ERROR, "ProtoSocket::SetRxBufferSize() setsockopt(SO_RCVBUF) error: %s\n", GetErrorString());
        return false;
    }

    return true;
}



unsigned int ProtoSocket::GetRxBufferSize()
{
    if(!IsOpen())
    {
        return 0;
    }

    unsigned int rxBufferSize = 0;
    socklen_t len = sizeof(rxBufferSize);

    if(getsockopt(handle, SOL_SOCKET, SO_RCVBUF, (char*) &rxBufferSize, &len) < 0)
    {
        PLOG(PL_ERROR, "ProtoSocket::GetRxBufferSize() getsockopt(SO_RCVBUF) error: %s\n",
             GetErrorString());
        return 0;
    }

    return ((unsigned int) rxBufferSize);
}  // end ProtoSocket::GetRxBufferSize()





//====================================================================================================
ProtoSocket::List::List() : head(NULL)
{

}

ProtoSocket::List::~List()
{
    Destroy();
}


void ProtoSocket::List::Destroy()
{
    Item* next = head;

    while(next)
    {
        Item* current = next;
        next = next->GetNext();
        delete current->GetSocket();
        delete current;
    }

    head = NULL;
}



bool ProtoSocket::List::AddSocket(ProtoSocket& theSocket)
{
    Item* item = new Item(&theSocket);

    if(item)
    {
        item->SetPrev(NULL);
        item->SetNext(head);
        head = item;
        return true;
    }
    else
    {
        PLOG(PL_ERROR, "ProtoSocket::List::AddSocket() new Item error: %s\n", GetErrorString());
        return false;
    }
}



void ProtoSocket::List::RemoveSocket(ProtoSocket& theSocket)
{
    Item* item = head;

    while(item)
    {
        if(&theSocket == item->GetSocket())
        {
            Item* prev = item->GetPrev();
            Item* next = item->GetNext();

            if(prev)
            {
                prev->SetNext(next);
            }
            else
            {
                head = next;
            }

            if(next)
            {
                next->SetPrev(prev);
            }

            delete item;
            break;
        }

        item = item->GetNext();
    }
}




ProtoSocket::List::Item* ProtoSocket::List::FindItem(const ProtoSocket& theSocket) const
{
    Item* item = head;

    while(item)
    {
        if(&theSocket == item->GetSocket())
        {
            return item;
        }
        else
        {
            item = item->GetNext();
        }
    }

    return NULL;
}


ProtoSocket::List::Item::Item(ProtoSocket* theSocket) : socket(theSocket), prev(NULL), next(NULL)
{

}

ProtoSocket::List::Iterator::Iterator(const ProtoSocket::List& theList) : next(theList.head)
{

}







//====================================================================================================

////////////////////////////////////////////////////////////////////
// These are some network "helper" functions that get information
// about the system network devices (interfaces), addresses, etc
//
// Note that the "ProtoSocket" implementation of this is being replaced
// by implementation in the "ProtoNet" namespace (see "protoNet.h") and
// the implementations here will eventually be removed _and_ the ProtoSocket
// static method declarations themselves will be eventually deprecated

#include "protoNet.h"

bool ProtoSocket::GetHostAddressList(ProtoAddress::Type  addrType, ProtoAddressList&   addrList)
{
    return ProtoNet::GetHostAddressList(addrType, addrList);
}


bool ProtoSocket::GetInterfaceAddress(const char* ifName, ProtoAddress::Type addrType, ProtoAddress& theAddress, unsigned int* ifIndex)
{
    return ProtoNet::GetInterfaceAddress(ifName, addrType, theAddress, ifIndex);
}


bool ProtoSocket::GetInterfaceAddressList(const char* interfaceName, ProtoAddress::Type addressType, ProtoAddressList& addrList, unsigned int* interfaceIndex)

{
    return ProtoNet::GetInterfaceAddressList(interfaceName, addressType, addrList, interfaceIndex);
}




bool ProtoSocket::FindLocalAddress(ProtoAddress::Type addrType, ProtoAddress& theAddress)
{
    return ProtoNet::FindLocalAddress(addrType, theAddress);
}


unsigned int ProtoSocket::GetInterfaceIndex(const char* interfaceName)
{
    return ProtoNet::GetInterfaceIndex(interfaceName);
}


unsigned int ProtoSocket::GetInterfaceIndices(unsigned int* indexArray, unsigned int indexArraySize)
{
    return ProtoNet::GetInterfaceIndices(indexArray, indexArraySize);
}


bool ProtoSocket::GetInterfaceName(unsigned int index, char* buffer, unsigned int buflen)
{
    return (0 != ProtoNet::GetInterfaceName(index, buffer, buflen));
}


bool ProtoSocket::GetInterfaceName(const ProtoAddress& ifAddr, char* buffer, unsigned int buflen)
{
    return (0 != ProtoNet::GetInterfaceName(ifAddr, buffer, buflen));
}





