

/**
* @file protoPipe.cpp
*
* @brief Provides a cross-platform interprocess communication mechanism for
*  Protolib using Unix-domain sockets (UNIX) or similar locally bound sockets mechanisms (WIN32).
*  This class extends the "ProtoSocket" class to support "LOCAL" domain interprocess communications
*/

#include "protoPipe.h"
#include "protoDebug.h"


#include <unistd.h>  // for unlink(), close()
#include <sys/un.h>  // for unix domain sockets
#include <sys/stat.h>
#include <stdlib.h>  // for mkstemp()


#ifdef NO_SCM_RIGHTS
#undef SCM_RIGHTS
#endif


#define CLI_PERM    S_IRWXU


ProtoPipe::ProtoPipe(Type theType) : ProtoSocket((MESSAGE == theType) ? UDP : TCP), unlink_tried(false)

{
    domain = LOCAL;
    path[0] = '\0';
}


ProtoPipe::~ProtoPipe()
{
    Close();
}




/**
 * This method opens a Unix-domain socket to serve as the ProtoPipe
 */
bool ProtoPipe::Open(const char* theName)
{
    // (TBD) use a semaphore to avoid issue of stale
    // Unix domain socket paths causing Open() to fail ???
    if(IsOpen())
    {
        Close();
    }

    char pipeName[PATH_MAX];

    if(*theName != '/')
    {
        strcpy(pipeName, "/tmp/");
    }

    strncat(pipeName, theName, PATH_MAX - strlen(pipeName));

    //
    struct sockaddr_un sockAddr;
    memset(&sockAddr, 0, sizeof(sockAddr));
    sockAddr.sun_family = AF_UNIX;
    strcpy(sockAddr.sun_path, pipeName);

    //int len = sizeof(sockAddr.sun_family) + strlen(sockAddr.sun_path) + sizeof(sockAddr.sun_len)+ 1; //zb: SCM_RIGHTS 4.3BSD Reno and later
    int len = sizeof(sockAddr.sun_family) + strlen(sockAddr.sun_path);


    int socketType = (UDP == protocol) ? SOCK_DGRAM : SOCK_STREAM;

    if((handle = socket(AF_UNIX, socketType, 0)) < 0)
    {
        PLOG(PL_ERROR, "ProtoPipe::Open() socket() error: %s\n", GetErrorString());
        Close();
        return false;
    }

    if(bind(handle, (struct sockaddr*) &sockAddr,  len) < 0)
    {
        PLOG(PL_WARN, "ProtoPipe::Open() bind(%s) error: %s\n", pipeName, GetErrorString());
        Close();
        return false;
    }

    state = IDLE;
    port = 0;

    if(!UpdateNotification())
    {
        PLOG(PL_ERROR, "ProtoPipe::Open() error updating notification\n");
        Close();
        return false;
    }

    strncpy(path, theName, PATH_MAX);
    return true;
}



void ProtoPipe::Close()
{
    if('\0' != path[0])
    {
        Unlink(path);
        path[0] = '\0';
    }

    ProtoSocket::Close();
}




void ProtoPipe::Unlink(const char* theName)
{
    char pipeName[PATH_MAX];

    if(*theName != '/')
    {
        strcpy(pipeName, "/tmp/");
    }

    strncat(pipeName, theName, PATH_MAX - strlen(pipeName));
    unlink(pipeName);
}



bool ProtoPipe::Listen(const char* theName)
{
    if(IsOpen())
    {
        Close();
    }

    if(Open(theName))
    {
        if(TCP == protocol)
        {
            state = LISTENING;

            if(!UpdateNotification())
            {
                PLOG(PL_ERROR, "ProtoSocket::Listen() error updating notification\n");
                Close();
                return false;
            }

            if(listen(handle, 5) < 0)
            {
                PLOG(PL_ERROR, "ProtoSocket:Listen() listen() error: %s\n", GetErrorString());
                Close();
                return false;
            }
        }

        return true;
    }
    else
    {
        if(Connect(theName))
        {
            Close();
            PLOG(PL_WARN, "ProtoPipe::Listen() error: name already in use\n");
            return false;
        }
        else
        {


            if(unlink_tried)
            {
                unlink_tried = false;
            }
            else
            {
                Unlink(theName);
                unlink_tried = true;

                if(Listen(theName))
                {
                    unlink_tried = false;
                    return true;
                }

                unlink_tried = false;
            }

            PLOG(PL_ERROR, "ProtoPipe::Listen() error opening pipe\n");
        }

        return false;
    }
}



bool ProtoPipe::Accept(ProtoPipe* thePipe)
{
    return ProtoSocket::Accept(static_cast<ProtoSocket*>(thePipe));
}



bool ProtoPipe::Connect(const char* theName)
{
    // (TBD) Don't "bind()" connecting sockets???
    // Open a socket as needed
    if(!IsOpen())
    {
        char pipeName[PATH_MAX];
        strcpy(pipeName, "/tmp/protoSocketXXXXXX");

        int fd = mkstemp(pipeName);

        if(fd < 0)
        {
            PLOG(PL_ERROR, "ProtoPipe::Connect() mkstemp() error: %s\n", GetErrorString());
            return false;
        }
        else
        {
            close(fd);
            unlink(pipeName);
        }

        if(!Open(pipeName + 5))
        {
            PLOG(PL_ERROR, "ProtoPipe::Connect() error opening local domain socket\n");
            return false;
        }

        // Try to make socket flush before closing
        if(TCP == protocol)
        {
            struct linger so_linger;
            so_linger.l_onoff = 1;
            so_linger.l_linger = 5000;

            if(setsockopt(handle, SOL_SOCKET, SO_LINGER, &so_linger, sizeof(so_linger)) < 0)
            {
                PLOG(PL_ERROR, "ProtoPipe::Connect() setsockopt(SO_LINGER) error: %s\n", GetErrorString());
            }
        }

        // I can't remember why we do this step ...
        if(chmod(pipeName, CLI_PERM) < 0)
        {
            PLOG(PL_ERROR, "ProtoPipe::Connect(): chmod() error: %s\n", GetErrorString());
            Close();
            return false;
        }
    }

    // Now try to connect to server
    struct sockaddr_un serverAddr;
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sun_family = AF_UNIX;

    if(*theName != '/')
    {
        strcpy(serverAddr.sun_path, "/tmp/");
    }

    strncat(serverAddr.sun_path, theName, PATH_MAX - strlen(serverAddr.sun_path));


    //int addrLen = sizeof(serverAddr.sun_family) + strlen(serverAddr.sun_path) + sizeof(serverAddr.sun_len) + 1; //zb: SCM_RIGHTS, 4.3BSD Reno and later
    int addrLen = sizeof(serverAddr.sun_family) + strlen(serverAddr.sun_path);


    // Make sure socket is "blocking" before connect attempt for "local socket
    ProtoPipe::Notifier* savedNotifier = notifier;

    if(NULL != savedNotifier)
    {
        SetNotifier((ProtoPipe::Notifier*) NULL);
    }

    if(connect(handle, (struct sockaddr*) &serverAddr, addrLen) < 0)
    {
        PLOG(PL_DEBUG, "ProtoPipe::Connect(): connect() error: %s\n", GetErrorString());
        Close();

        // Restore socket notification if applicable
        if(NULL != savedNotifier)
        {
            SetNotifier(savedNotifier);
        }

        return false;
    }

    // Restore socket notification if applicable
    if(NULL != savedNotifier)
    {
        SetNotifier(savedNotifier);
    }

    state = CONNECTED;

    if(!UpdateNotification())
    {
        PLOG(PL_ERROR, "ProtoPipe::Connect() error updating notification\n");
        Close();
        return false;
    }

    return true;
}



