

#ifndef _PROTO_SOCKET
#define _PROTO_SOCKET


#include "protoAddress.h"
#include "protoDebug.h"


#include <errno.h> // for errno
#include <net/if.h>  // for struct ifconf
#include <unistd.h>  // for read()
#include <stdio.h>




/**
 * @class ProtoSocket
 *
 * @brief Network socket container class that provides
 * consistent interface for use of operating
 * system (or simulation environment) transport
 * sockets. Provides support for asynchronous
 * notification to ProtoSocket::Listeners.
 * The ProtoSocket class may be used stand-alone, or
 * with other classes described below.  A
 * ProtoSocket may be instantiated as either a
 * UDP or TCP socket.
 */
class ProtoSocket
{
public:
    // Type definitions
    enum Domain
    {
        LOCAL,
        IPv4,
        IPv6
    };

    enum Protocol
    {
        INVALID_PROTOCOL,
        UDP,
        TCP,
        RAW
    };

    enum State
    {
        CLOSED,
        IDLE,
        CONNECTING,
        LISTENING,
        CONNECTED
    };

    enum EcnStatus
    {
        ECN_NONE = 0x00,  // not ECN-Capable
        ECN_ECT1 = 0x01,  // ECN-Capable Transport 1
        ECN_ECT0 = 0x02,  // ECN-Capable Transport 0      (old ECT)
        ECN_CE   = 0x03   // ECN "Congestion Experienced" (old CE)
    };


    typedef int Handle;
    static const Handle INVALID_HANDLE;

    ProtoSocket(Protocol theProtocol);
    virtual ~ProtoSocket();

    bool Open(UINT16 thePort = 0, ProtoAddress::Type addrType = ProtoAddress::IPv4, bool bindOnOpen = true);
    bool Bind(UINT16 thePort = 0, const ProtoAddress* localAddr = NULL);

    bool Connect(const ProtoAddress& theAddress);
    void Disconnect();

    bool Listen(UINT16 thePort = 0);
    void Ignore();
    bool Accept(ProtoSocket* theSocket = NULL);
    bool Shutdown();
    void Close();


// First cut at IGMPv3 SSM support (TBD - refine this and expand platform support)
// On Mac OSX, only version 10.7 and later support IGMPv3
// and the "MCAST_JOIN_GROUP" macro definition is a "tell" for this
// (we _reallly_ need to go to a more sophisticated build system!)

    bool JoinGroup(const ProtoAddress& groupAddress, const char* interfaceName = NULL, const ProtoAddress* sourceAddress = NULL);
    bool LeaveGroup(const ProtoAddress& groupAddress, const char* interfaceName = NULL, const ProtoAddress*  sourceAddress = NULL);

    bool SetRawProtocol(Protocol theProtocol);
    void SetState(State st)
    {
        state = st;
    }

    Domain GetDomain() const
    {
        return domain;
    }
    ProtoAddress::Type  GetAddressType();
    Protocol GetProtocol() const
    {
        return protocol;
    }
    State GetState() const
    {
        return state;
    }
    Handle GetHandle() const
    {
        return handle;
    }
    UINT16 GetPort() const
    {
        return port < 0 ? 0 : port;
    }

    bool IsOpen() const
    {
        return (CLOSED != state);
    }
    bool IsBound() const
    {
        return (IsOpen() ? (port >= 0) : false);
    }

    bool IsConnected() const
    {
        return (CONNECTED == state);
    }
    bool IsConnecting() const
    {
        return (CONNECTING == state);
    }
    bool IsIdle() const
    {
        return (IDLE == state);
    }
    bool IsClosed() const
    {
        return (CLOSED == state);
    }
    bool IsListening() const
    {
        return (LISTENING == state);
    }

    // These are valid for connected sockets only
    const ProtoAddress& GetSourceAddr() const
    {
        return source_addr;
    }
    const ProtoAddress& GetDestination() const
    {
        return destination;
    }

    // I.T. to set the destination on a socket after an ACCEPT.
    void SetDestination(const ProtoAddress& destin)
    {
        destination = destin;
    }

    static const char* GetErrorString()
    {
        return strerror(errno);
    }

    // Read/Write methods
    bool SendTo(const char* buffer, unsigned int buflen, const ProtoAddress& dstAddr);
    bool RecvFrom(char* buffer, unsigned int& numBytes, ProtoAddress& srcAddr);
    bool RecvFrom(char* buffer, unsigned int& numBytes, ProtoAddress& srcAddr, ProtoAddress& dstAddr);
    bool Send(const char* buffer, unsigned int& numBytes);
    bool Recv(char* buffer, unsigned int& numBytes);


    // This was for debugging?? Remove??
    bool Read(char* buffer, unsigned int &numBytes)
    {
        int result = read(handle, buffer, numBytes);

        if(result < 0)
        {
            perror("read() error");
            numBytes = 0;

            switch(errno)
            {
                case EAGAIN:
                    return true;

                default:
                    return false;
            }
        }
        else
        {
            numBytes = result;
            return true;
        }
    }

    // Attributes
    bool SetTTL(unsigned char ttl);
    bool SetLoopback(bool loopback);
    bool SetBroadcast(bool broadcast);
    bool SetFragmentation(bool enable);

    bool SetReuse(bool reuse);
    bool SetBindInterface(const char* interfaceName);
    bool SetMulticastInterface(const char* interfaceName);
    bool SetTOS(unsigned char tos);
    bool SetEcnCapable(bool status);

    bool SetTxBufferSize(unsigned int bufferSize);
    unsigned int GetTxBufferSize();
    bool SetRxBufferSize(unsigned int bufferSize);
    unsigned int GetRxBufferSize();

    void EnableRecvDstAddr();



    // These are some static network "helper" functions that get information
    // about the system network devices (interfaces), addresses, etc
    //
    // Note that the "ProtoSocket" implementation of this is being replaced
    // by implementation in the "ProtoNet" namespace (see "protoNet.h") and
    // the implementations here will eventually be removed _and_ the ProtoSocket
    // static method declarations themselves will be eventually deprecated
    //
    // This appends addresses of type "addrType" to the "addrList"
    static bool GetHostAddressList(ProtoAddress::Type addrType, ProtoAddressList& addrList);
    static bool GetInterfaceAddressList(const char* ifName, ProtoAddress::Type addrType, ProtoAddressList& addrList, unsigned int* ifIndex = NULL);

    static bool GetInterfaceAddress(const char* ifName, ProtoAddress::Type addrType, ProtoAddress& theAddress, unsigned int* ifIndex = NULL);
    static unsigned int GetInterfaceIndices(unsigned int* indexArray, unsigned int indexArraySize);
    static unsigned int GetInterfaceIndex(const char* interfaceName);

    static bool FindLocalAddress(ProtoAddress::Type addrType, ProtoAddress& theAddress);
    static bool GetInterfaceName(unsigned int index, char* buffer, unsigned int buflen);
    static bool GetInterfaceName(const ProtoAddress& ifAddr, char* buffer, unsigned int buflen);


    // Asynchronous I/O notification stuff
    enum Flag
    {
        NOTIFY_NONE      =   0x00,
        NOTIFY_INPUT     =   0x01,
        NOTIFY_OUTPUT    =   0x02,
        NOTIFY_EXCEPTION =  0x04,
        NOTIFY_ERROR     =   0x08
    };

    class Notifier
    {
    public:
        virtual ~Notifier()
        {

        }
        virtual bool UpdateSocketNotification(ProtoSocket& theSocket, int notifyFlags)
        {
            return true;
        }
    };

    Notifier* GetNotifier() const
    {
        return notifier;
    }

    bool SetNotifier(ProtoSocket::Notifier* theNotifier);

    bool StartOutputNotification()
    {
        notify_output = true;
        notify_output = UpdateNotification();
        return notify_output;
    }
    void StopOutputNotification()
    {
        notify_output = false;
        UpdateNotification();
    }
    bool NotifyOutput()
    {
        return notify_output;
    }

    bool StartInputNotification()
    {
        notify_input = true;
        notify_input = UpdateNotification();
        return notify_input;
    }
    void StopInputNotification()
    {
        notify_input = false;
        UpdateNotification();
    }
    bool NotifyInput()
    {
        return notify_input;
    }

    bool StartExceptionNotification()
    {
        notify_exception = true;
        notify_exception = UpdateNotification();
        return notify_exception;
    }
    void StopExceptionNotification()
    {
        notify_exception = false;
        UpdateNotification();
    }

    void OnNotify(ProtoSocket::Flag theFlag);


    enum Event
    {
        INVALID_EVENT,
        CONNECT,
        ACCEPT,
        SEND,
        RECV,
        DISCONNECT,
        ERROR_,
        EXCEPTION
    };



    // NOTE: For VC++ 6.0 Debug builds, you _cannot_ use pre-compiled
    // headers with this template code.  Also, "/ZI" or "/Z7" compile options
    // must NOT be specified.  (or else VC++ 6.0 experiences an "internal compiler error")
    // (Later Visual Studio versions have fixed this error)
    template <class listenerType> bool SetListener(listenerType* theListener, void (listenerType::*eventHandler)(ProtoSocket&, Event))
    {
        bool doUpdate = ((NULL == listener) && (NULL != theListener)) || ((NULL == theListener) && (NULL != listener));

        if(listener)
        {
            delete listener;
        }

        listener = theListener ? new LISTENER_TYPE<listenerType> (theListener, eventHandler) : NULL;
        bool result = theListener ? (NULL != theListener) : true;
        return result ? (doUpdate ? UpdateNotification() : true) : false;
    }

    bool HasListener()
    {
        return (NULL != listener);
    }

    void SetUserData(const void* userData)
    {
        user_data = userData;
    }
    const void* GetUserData()
    {
        return user_data;
    }



    /**
    * @class List
    *
    * @brief A helper linked list class
    */
    class List
    {
    public:
        List();
        ~List();
        void Destroy();  // deletes list Items _and_ their socket

        bool AddSocket(ProtoSocket& theSocket);
        void RemoveSocket(ProtoSocket& theSocket);

        class Item;
        Item* FindItem(const ProtoSocket& theSocket) const;

    public:
        /**
        * @class Iterator
        *
        * @brief List Iterator
        */
        class Iterator
        {
        public:
            Iterator(const List& theList);
            const Item* GetNextItem()
            {
                const Item* current = next;
                next = current ? current->GetNext() : current;
                return current;
            }

            ProtoSocket* GetNextSocket()
            {
                const Item* nextItem = GetNextItem();
                return nextItem ? nextItem->GetSocket() : NULL;
            }


        private:
            const class Item*   next;

        };


        friend class List::Iterator;
        /**
        * @class Item
        *
        * @brief List Item
        */
        class Item
        {
            friend class List;
            friend class Iterator;
        public:
            Item(ProtoSocket* theSocket);

            ProtoSocket* GetSocket() const
            {
                return socket;
            }
            const void* GetUserData()
            {
                return user_data;
            }
            void SetUserData(const void* userData)
            {
                user_data = userData;
            }

        private:
            Item* GetPrev() const
            {
                return prev;
            }
            void SetPrev(Item* item)
            {
                prev = item;
            }

            Item* GetNext() const
            {
                return next;
            }
            void SetNext(Item* item)
            {
                next = item;
            }

            ProtoSocket*    socket;
            const void*     user_data;
            Item*           prev;
            Item*           next;
        };

        Item*   head;
    };  // end class ProtoSocketList


protected:
    /**
    * @class Listener
    *
    * @brief Listens for socket activity and invokes socket event handler.
    */
    class Listener
    {
    public:
        virtual ~Listener()
        {

        }
        virtual void on_event(ProtoSocket& theSocket, Event theEvent) = 0;
        virtual Listener* duplicate() = 0;
    };


    /**
    * @class LISTENER_TYPE
    *
    * @brief Listener template
    */
    template <class listenerType> class LISTENER_TYPE : public Listener
    {
    public:
        LISTENER_TYPE(listenerType* theListener, void (listenerType::*eventHandler)(ProtoSocket&, Event)) : listener(theListener), event_handler(eventHandler)
        {

        }
        void on_event(ProtoSocket& theSocket, Event theEvent)
        {
            (listener->*event_handler)(theSocket, theEvent);
        }

        Listener* duplicate()
        {
            return (static_cast<Listener*>(new LISTENER_TYPE<listenerType>(listener, event_handler)));
        }

    private:
        listenerType* listener;
        void (listenerType::*event_handler)(ProtoSocket&, Event);
    };

    virtual bool SetBlocking(bool blocking);
    bool UpdateNotification();

    Domain                  domain;
    Protocol                protocol;
    Protocol                raw_protocol;  // only applies to raw sockets
    State                   state;
    Handle                  handle;  //zb2: socket
    int                     port;

    UINT8                   tos;           // IPv4 TOS or IPv6 traffic class
    bool                    ecn_capable;
    bool                    ip_recvdstaddr;  // set "true" if RecvFrom() with destAddr is invoked


    // These cache the "getsockname()" source/dest for connected/accepted sockets
    // TBD - perhaps should have "GetLocalAddress()" and "GetRemoteAddress()" methods instead?
    //       althought the cached information is useful for post-mortem (closure) purposes
    ProtoAddress            source_addr;  // connected/accepted local address/port
    ProtoAddress            destination;  // connected/accepted destination address/port


    Notifier*               notifier; //zb100: NotificationProcessFunction for socket_event(send notification if needed)!
    bool                    notify_output;
    bool                    notify_input;
    bool                    notify_exception;

    Listener*               listener; //zb100: TaskProcessFunction for socket_event!
    const void*             user_data;


private:
    static const int IFBUFSIZ = 256;  // for GetHostAddressList
    static const int IFIDXSIZ = 256;  //   "
    static int GetInterfaceList(struct ifconf& conf);  // helper fn
};



#endif



