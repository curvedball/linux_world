

#ifndef _PROTO_PIPE
#define _PROTO_PIPE


#include "protoSocket.h"




/**
 * @class ProtoPipe
 *
 * @brief Provides a cross-platform interprocess communication
 * mechanism for Protolib using Unix-domain sockets (UNIX) or
 * named pipe/mailslot mechanisms (WIN32).  This class
 * extends the "ProtoSocket" class to support "LOCAL"
 * domain interprocess communications.
 */
//zb: use Aggregation is better than inherit!!!
class ProtoPipe : public ProtoSocket
{
public:
    enum Type
    {
        MESSAGE,
        STREAM
    };

    ProtoPipe();
    ProtoPipe(Type theType);
    ~ProtoPipe();

    Type GetType()
    {
        return ((UDP == GetProtocol()) ? MESSAGE : STREAM);
    }

    const char* GetName()
    {
        return path;
    }

    bool Connect(const char* serverName);
    bool Listen(const char* theName);
    bool Accept(ProtoPipe* thePipe = NULL);
    void Close();

    bool Send(const char* buffer, unsigned int& numBytes)
    {
        return ProtoSocket::Send(buffer, numBytes);
    }

    bool Recv(char* buffer, unsigned int& numBytes)
    {
        return ProtoSocket::Recv(buffer, numBytes);
    }



private:
    bool Open(const char* theName);
    void Unlink(const char* theName);



    bool unlink_tried; //zb: flags to delete a file
    //
    char        path[PATH_MAX];
};



#endif



