

#ifndef _PROTO_NET
#define _PROTO_NET



// The ProtoNet classes provide APIs for getting information
// on the computer host's network interfaces, configured
// addresses, etc.
// It includes a class for actively monitoring changes in
// in the status of network interfaces and configuration
//
// Common code for these functions and classes is implemented in
// "src/common/protoNet.cpp" and system-specific code is implemented
// in other files (e.g. src/unix/unixNet.cpp, src/win32/win32Net.cpp, etc)

// For classes defined here, general a "factory" design pattern is used where
// a static "Create()" method is called to create system-specific instantiations
// of a given class and any virtual interface methods defined here are invoked
// using system-specific code as needed.


#include "protoAddress.h"
#include "protoChannel.h"



namespace ProtoNet
{
    /**
     * @class ProtoNet::Monitor
     *
     * @brief This class provides a means
     * to receive notifications of changes
     * in the computer's network status or
     * configuration.
     *
     */

    enum InterfaceStatus
    {
        IFACE_UNKNOWN,
        IFACE_UP,
        IFACE_DOWN
    };



    // These are the base ProtoNet methods that must be implemented in
    // with specific operating system calls (i.e. in unixNet.cpp, win32Net.cpp, etc)
    unsigned int GetInterfaceIndices(unsigned int* indexArray, unsigned int indexArraySize);

    // get iface name by index
    unsigned int GetInterfaceName(unsigned int index, char* buffer, unsigned int buflen);

    // get iface index by name
    unsigned int GetInterfaceIndex(const char* interfaceName);

    // get all addrs of "addrType" for given given "ifName"
    bool GetInterfaceAddressList(const char* ifName, ProtoAddress::Type addrType, ProtoAddressList& addrList, unsigned int* ifIndex = NULL);

    // get name that matches given ifAddr (may be an alias name)
    // (returns name length so you can verify buflen was sufficient)
    unsigned int GetInterfaceName(const ProtoAddress& ifAddr, char* buffer, unsigned int buflen);

    unsigned int GetInterfaceAddressMask(const char* ifName, const ProtoAddress& ifAddr);



    bool AddInterfaceAddress(const char* ifaceName, const ProtoAddress& addr, unsigned int maskLen);
    bool RemoveInterfaceAddress(const char* ifaceName, const ProtoAddress& addr, unsigned int maskLen = 0);





    /////////////////////////////////////////////////////////
    // These are implemented in "protoNet.cpp" using the above
    // 'base' functions.
    unsigned int GetInterfaceCount();
    unsigned int GetInterfaceIndex(const ProtoAddress& ifAddr);

    bool GetInterfaceAddress(const char* ifName, ProtoAddress::Type addrType, ProtoAddress& theAddress, unsigned int* ifIndex = NULL);
    bool GetHostAddressList(ProtoAddress::Type  addrType, ProtoAddressList& addrList);
    bool GetInterfaceAddressList(unsigned int ifIndex, ProtoAddress::Type addrType, ProtoAddressList& addrList);
    bool FindLocalAddress(ProtoAddress::Type addrType, ProtoAddress& theAddress);

    InterfaceStatus GetInterfaceStatus(const char* ifaceName);
    InterfaceStatus GetInterfaceStatus(unsigned int ifaceIndex);
    unsigned int GetInterfaceAddressMask(unsigned int ifIndex, const ProtoAddress& ifAddr);


    bool AddInterfaceAddress(unsigned int ifaceIndex, const ProtoAddress& addr, unsigned int maskLen);
    bool RemoveInterfaceAddress(unsigned int ifaceIndex, const ProtoAddress& addr, unsigned int maskLen = 0);
}


#endif





