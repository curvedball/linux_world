

#ifndef _PROTO_DEFS
#define _PROTO_DEFS


#include <sys/types.h> // must include this first to make SGI's compiler happy
#include <sys/time.h>  // for UNIX gettimeofday(), etc
#include <stdint.h>    // for proper uint32_t, etc definitions
#include <limits.h>    // for PATH_MAX



const char PROTO_PATH_DELIMITER = '/';


inline void ProtoSystemTime(struct timeval& theTime)
{
    struct timezone tz;
    gettimeofday(&theTime, &tz);
}



#ifndef PATH_MAX
#define PATH_MAX _POSIX_PATH_MAX
#endif


#ifndef NULL
#define NULL 0
#endif


typedef int8_t INT8;
typedef int16_t INT16;
typedef int32_t INT32;


typedef uint8_t UINT8;
typedef uint16_t UINT16;
typedef uint32_t UINT32;


#ifndef MAX
#define MAX(X,Y) ((X>Y)?(X):(Y))
#endif

#ifndef MIN
#define MIN(X,Y) ((X<Y)?(X):(Y))
#endif




#endif



