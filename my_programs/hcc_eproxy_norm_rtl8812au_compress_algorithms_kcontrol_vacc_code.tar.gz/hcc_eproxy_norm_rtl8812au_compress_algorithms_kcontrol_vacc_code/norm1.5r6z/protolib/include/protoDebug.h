
/**
* @class ProtoDebug
*
* @brief Debugging routines
*
* PROTOLIB DEBUG LEVELS:
 *
 * @li PL_FATAL=0   // The FATAL level designates very severe error events that will presumably lead the application to abort.
 * @li PL_ERROR=1;  // The ERROR level designates error events that might still allow the application to continue running.
 * @li PL_WARN=2;   // The WARN level designates potentially harmful situations.
 * @li PL_INFO=3;   // The INFO level designates informational messages that highlight the progress of the application at coarse-grained level.
 * @li PL_DEBUG=4;  // The DEBUG level designates fine-grained informational events that are most useful to debug an application.
 * @li PL_TRACE=5;  // The TRACE level designates finer-grained informational events than the DEBUG
 * @li PL_DETAIL=6; // The TRACE level designates even finer-grained informational events than the DEBUG
 * @li PL_MAX=7;    // Turn all comments on
 * @li PL_ALWAYS    // Messages at this level are always printed regardless of debug level
*/

#ifndef _PROTO_DEBUG
#define _PROTO_DEBUG


#include <string.h>  // for strerror()
#include <errno.h>   // for errno


enum ProtoDebugLevel
{
    PL_FATAL,
    PL_ERROR,
    PL_WARN,
    PL_INFO,
    PL_DEBUG,
    PL_TRACE,
    PL_DETAIL,
    PL_MAX,
    PL_ALWAYS
};


//=======================================================================================================
#if defined(PROTO_DEBUG)

void SetDebugLevel(unsigned int level);
unsigned int GetDebugLevel();

bool OpenDebugLog(const char *path);       // log debug messages to the file named "path"
void CloseDebugLog();

bool OpenDebugPipe(const char* pipeName);  // log debug messages to a datagram ProtoPipe (PLOG only)
void CloseDebugPipe();

void DMSG(unsigned int level, const char *format, ...);  //zb: Debug messages output to a file
void PLOG(ProtoDebugLevel level, const char *format, ...);  //zb: pipe log using UDP messages




typedef void (ProtoAssertFunction)(bool condition, const char* conditionText, const char* fileName, int lineNumber, void* userData);
void SetAssertFunction(ProtoAssertFunction* assertFunction, void* userData = NULL);
void ClearAssertFunction();
bool HasAssertFunction();
void ProtoAssertHandler(bool condition, const char* conditionText, const char* fileName, int lineNumber);
void PROTO_ABORT(const char *format, ...);




#ifdef HAVE_ASSERT
#include <assert.h>
#define PROTO_ASSERT(X) {if (HasAssertFunction()) ProtoAssertHandler(X, #X, __FILE__, __LINE__); else assert(X);}
#else
#define PROTO_ASSERT(X) \
{\
    if (HasAssertFunction())\
        ProtoAssertHandler(X, #X, __FILE__, __LINE__); \
    else if (!((bool)(X)))\
        PROTO_ABORT("ASSERT(%s) failed at line %d in source file \"%s\"\n", #X, __LINE__, __FILE__);\
}
#endif


#ifdef TRACE
#undef TRACE
#endif

void TRACE(const char *format, ...);




#else
inline void SetDebugLevel(unsigned int level)
{

}

inline unsigned int GetDebugLevel()
{
    return PL_FATAL;
}

inline bool OpenDebugLog(const char *path)
{
    return true;
}

inline void CloseDebugLog()
{

}

inline bool OpenDebugPipe(const char* pipeName)
{
    return true;
}

inline void CloseDebugPipe()
{

}

inline void DMSG(unsigned int level, const char *format, ...)
{

}

inline void PLOG(ProtoDebugLevel level, const char *format, ...)
{

}


#define PROTO_ASSERT(X)

#ifndef ABORT
#define ABORT(X)
#endif


#ifndef TRACE
inline void TRACE(const char *format, ...)
{

}
#endif



#endif





//=======================================================================================================
// Historically, "protolib" has used an "ASSERT()" macro for assertions.  It now makes sense to
// transition to a more explicit "PROTO_ASSERT()" - we should/will probably deprecate this
// "ASSERT()" macro definition but for now it is in many projects that use Protolib
#undef ASSERT
#define ASSERT(X) PROTO_ASSERT(X)

inline const char* GetErrorString()
{
    return strerror(errno);
}



typedef int ProtoErrorCode;
inline const char* GetErrorString(ProtoErrorCode errorCode)
{
    return strerror(errorCode);
}


#endif




