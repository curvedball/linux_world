


#ifndef _PROTOKIT
#define _PROTOKIT


#include "protoVersion.h"
#include "protoDefs.h"
#include "protoSocket.h"
#include "protoDebug.h"
#include "protoTimer.h"
#include "protoTree.h"


#include "protoPipe.h"
#include "protoFile.h"
#include "protoDispatcher.h"
#include "protoApp.h"


#endif



