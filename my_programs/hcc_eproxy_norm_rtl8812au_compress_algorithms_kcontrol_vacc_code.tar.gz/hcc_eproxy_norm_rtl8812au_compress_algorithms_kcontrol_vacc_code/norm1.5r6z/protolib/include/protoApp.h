


#ifndef _PROTO_APP
#define _PROTO_APP


#include "protoDispatcher.h"



/**
 * @class ProtoApp
 *
 * @brief Base class for implementing protolib-based
 * command-line applications.
 *
 * Note that "ProtoApp" and "ProtoSimAgent" are
 * designed such that subclasses can be derived
 * from either to reuse the same code in either a
 * real-world applications or as an "agent"
 * (entity) within a network simulation
 * environment (e.g. ns-2, OPNET).  A "background"
 * command is included for Win32 to launch the
 * app without a terminal window.
 */

class ProtoApp
{
public:
    virtual ~ProtoApp();

    virtual bool OnStartup(int argc, const char*const* argv) = 0;
    virtual bool ProcessCommands(int argc, const char*const* argv) = 0;
    virtual void OnShutdown() = 0;

    bool ProcessCommandString(const char* cmd);

    int Run()
    {
        return dispatcher.Run();
    }

    bool IsRunning() const
    {
        return dispatcher.IsRunning();
    }

    void Stop(int exitCode = 0)
    {
        dispatcher.Stop(exitCode);
    }

    // Some helper methods
    void ActivateTimer(ProtoTimer& theTimer)
    {
        dispatcher.ActivateTimer(theTimer);
    }

    void DeactivateTimer(ProtoTimer& theTimer)
    {
        dispatcher.DeactivateTimer(theTimer);
    }

    ProtoSocket::Notifier& GetSocketNotifier()
    {
        return static_cast<ProtoSocket::Notifier&>(dispatcher);
    }

    ProtoChannel::Notifier& GetChannelNotifier() //zb: channel is defined as the message notification
    {
        return static_cast<ProtoChannel::Notifier&>(dispatcher);
    }

    ProtoTimerMgr& GetTimerMgr()
    {
        return static_cast<ProtoTimerMgr&>(dispatcher);
    }

    ProtoDispatcher& GetDispatcher()
    {
        return dispatcher;
    }

    static ProtoApp* GetApp()
    {
        return the_app;
    }

    static void SignalHandler(int sigNum);


protected:
    ProtoApp();

    ProtoDispatcher dispatcher;


private:
    static ProtoApp* the_app;

};



/*
 * The functions and macros below are used to instantiate
 * a derive ProtoApp when needed.
 */
int ProtoMain(int argc, char* argv[], bool pauseForUser = false);



#define PROTO_MAIN() int main(int argc, char* argv[])\
{\
    return ProtoMain(argc, argv);\
}



/**
 * Use this macro to instantiate your derived ProtoApp instance
 */
#define PROTO_INSTANTIATE_APP(X) X protoApp; PROTO_MAIN()



#endif




