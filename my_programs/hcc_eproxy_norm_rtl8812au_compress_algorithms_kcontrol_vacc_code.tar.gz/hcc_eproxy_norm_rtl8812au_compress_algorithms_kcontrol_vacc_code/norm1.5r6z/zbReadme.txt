
https://github.com/glycerine/nack-oriented-reliable-multicast/blob/master/src-norm-1.5r6.tgz


===========================compile==========================================================
./waf clean
./waf --debug configure
./waf



./waf clean
./waf configure
./waf






===========================example code======================================================
NormInstanceHandle instance = NormCreateInstance();  #normInstance->Startup(priorityBoost), create a thread and wait();

-->

#rx_socket.SetNotifier(&sessionMgr.GetSocketNotifier()),  this socket will be one node of socket_stream_list
NormSessionHandle session = NormCreateSession(instance, "224.1.2.3",  6003, NORM_NODE_ANY);  
......
NormStartReceiver(session, 8*1024*1024); #Resume thread to wait event
......

NormSetSilentReceiver(session, true);
......
NormGetNextEvent(instance, &theEvent)
switch (theEvent.type)
{
    ......
    NormStreamRead(stream, msgBuffer+msgIndex, &numBytes)
}


===========================//zb001线程的运行与socket集合的添加======================================================
（1）NormCreateInstance创建出实例时，线程开始运行，并且运行ProtoDispatcher类的Run函数直到Wait函数（注意Wait函数内部目前只是添加了一个管道操作符break_pipe_fd[0]到input_set集合中）；
（2）ProtoDispatcher类的SignalThread函数可以触发break_pipe_fd[1]的写事件导致select函数返回，推动线程继续运行；







==========================//zb100======================================================
ProtoSocket





==========================//zb200======================================================






==========================//zb300======================================================







==========================//zb400======================================================





































