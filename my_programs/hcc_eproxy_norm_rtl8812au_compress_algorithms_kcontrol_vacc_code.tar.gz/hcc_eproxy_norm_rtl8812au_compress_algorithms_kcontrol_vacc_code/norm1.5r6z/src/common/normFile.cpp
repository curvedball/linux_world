
#include "normFile.h"
#include <string.h>  // for strerror()
#include <stdio.h>   // for rename()
#include <unistd.h>


#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>


NormFile::NormFile() : fd(-1)

{
}

NormFile::~NormFile()
{
    if(IsOpen())
    {
        Close();
    }
}


// This should be called with a full path only!
bool NormFile::Open(const char* thePath, int theFlags)
{
    ASSERT(!IsOpen());

    if(theFlags & O_CREAT)
    {
        // Create sub-directories as needed.
        char tempPath[PATH_MAX];
        strncpy(tempPath, thePath, PATH_MAX);
        char* ptr = strrchr(tempPath, PROTO_PATH_DELIMITER);

        if(NULL != ptr)
        {
            *ptr = '\0';
            ptr = NULL;

            while(!NormFile::Exists(tempPath))
            {
                char* ptr2 = ptr;
                ptr = strrchr(tempPath, PROTO_PATH_DELIMITER);

                if(ptr2)
                {
                    *ptr2 = PROTO_PATH_DELIMITER;
                }

                if(ptr)
                {
                    *ptr = '\0';
                }
                else
                {
                    ptr = tempPath;
                    break;
                }
            }
        }

        if(ptr && ('\0' == *ptr))
        {
            *ptr++ = PROTO_PATH_DELIMITER;
        }

        while(ptr)
        {
            ptr = strchr(ptr, PROTO_PATH_DELIMITER);

            if(ptr)
            {
                *ptr = '\0';
            }

            if(mkdir(tempPath, 0755))
            {
                PLOG(PL_FATAL, "NormFile::Open() mkdir(%s) error: %s\n", tempPath, GetErrorString());
                return false;
            }

            if(ptr)
            {
                *ptr++ = PROTO_PATH_DELIMITER;
            }
        }
    }

    if((fd = open(thePath, theFlags, 0640)) >= 0)
    {
        offset = 0;
        return true;  // no error
    }
    else
    {
        PLOG(PL_FATAL, "norm: Error opening file \"%s\": %s\n", thePath, GetErrorString());
        return false;
    }
}



void NormFile::Close()
{
    if(IsOpen())
    {
        close(fd);
        fd = -1;
    }
}


// Routines to try to get an exclusive lock on a file
bool NormFile::Lock()
{
    fchmod(fd, 0640 | S_ISGID);
    if(0 != lockf(fd, F_LOCK, 0))   // assume lockf if not flock
    {
        return false;
    }
    else
    {
        return true;
    }
}


void NormFile::Unlock()
{
    int ret = lockf(fd, F_ULOCK, 0);
    ret = 0;  // done to avoid compiler warning (should optimize out)
    fchmod(fd, 0640);
}


bool NormFile::Rename(const char* oldName, const char* newName)
{
    if(!strcmp(oldName, newName))
    {
        return true;  // no change required
    }

    // Make sure the new file name isn't an existing "busy" file
    // (This also builds sub-directories as needed)
    if(NormFile::IsLocked(newName))
    {
        PLOG(PL_FATAL, "NormFile::Rename() error: file is locked\n");
        return false;
    }

    // Create sub-directories as needed.
    char tempPath[PATH_MAX];
    strncpy(tempPath, newName, PATH_MAX);
    char* ptr = strrchr(tempPath, PROTO_PATH_DELIMITER);

    if(ptr)
    {
        *ptr = '\0';
    }

    ptr = NULL;

    while(!NormFile::Exists(tempPath))
    {
        char* ptr2 = ptr;
        ptr = strrchr(tempPath, PROTO_PATH_DELIMITER);

        if(ptr2)
        {
            *ptr2 = PROTO_PATH_DELIMITER;
        }

        if(ptr)
        {
            *ptr = '\0';
        }
        else
        {
            ptr = tempPath;
            break;
        }
    }

    if(ptr && ('\0' == *ptr))
    {
        *ptr++ = PROTO_PATH_DELIMITER;
    }

    while(ptr)
    {
        ptr = strchr(ptr, PROTO_PATH_DELIMITER);

        if(ptr)
        {
            *ptr = '\0';
        }

        if(mkdir(tempPath, 0755))
        {
            PLOG(PL_FATAL, "NormFile::Rename() mkdir(%s) error: %s\n", tempPath, GetErrorString());
            return false;
        }

        if(ptr)
        {
            *ptr++ = PROTO_PATH_DELIMITER;
        }
    }

    if(rename(oldName, newName))
    {
        PLOG(PL_ERROR, "NormFile::Rename() rename() error: %s\n", GetErrorString());
        return false;
    }
    else
    {
        return true;
    }
}  


size_t NormFile::Read(char* buffer, size_t len)
{
    ASSERT(IsOpen());

    size_t got = 0;

    while(got < len)
    {
        ssize_t result = read(fd, buffer + got, len - got);

        if(result <= 0)
        {
            if(EINTR != errno)
            {
                PLOG(PL_FATAL, "NormFile::Read() read(%d) result:%d error:%s (offset:%d)\n", len, result, GetErrorString(), offset);
                return 0;
            }
        }
        else
        {
            got += result;
            offset += (Offset)result;
        }
    } 

    return got;
}



size_t NormFile::Write(const char* buffer, size_t len)
{
    ASSERT(IsOpen());
    size_t put = 0;

    while(put < len)
    {
        size_t result = write(fd, buffer + put, len - put);

        if(result <= 0)
        {
            if(EINTR != errno)
            {
                PLOG(PL_FATAL, "NormFile::Write() write(%d) result:%d error: %s\n", len, result, GetErrorString());
                return 0;
            }
        }
        else
        {
            offset += (Offset)result;
            put += result;
        }
    }

    return put;
}



bool NormFile::Seek(Offset theOffset)
{
    ASSERT(IsOpen());

    Offset result = lseek(fd, theOffset, SEEK_SET);

    if(result == (Offset) - 1)
    {
        PLOG(PL_FATAL, "NormFile::Seek() lseek() error: %s\n", GetErrorString());
        return false;
    }
    else
    {
        offset = result;
        return true; // no error
    }
}



bool NormFile::Pad(Offset theOffset)
{
    if(theOffset > GetSize())
    {
        if(Seek(theOffset - 1))
        {
            char byte = 0;

            if(1 != Write(&byte, 1))
            {
                PLOG(PL_FATAL, "NormFile::Pad() write error: %s\n", GetErrorString());
                return false;
            }
        }
        else
        {
            PLOG(PL_FATAL, "NormFile::Pad() seek error: %s\n", GetErrorString());
            return false;
        }
    }

    return true;
}



NormFile::Offset NormFile::GetSize() const
{
    ASSERT(IsOpen());

    struct stat info;
    int result = fstat(fd, &info);

    if(result)
    {
        PLOG(PL_FATAL, "Error getting file size: %s\n", GetErrorString());
        return 0;
    }
    else
    {
        return info.st_size;
    }
}




//============================================================================================
/***********************************************
 * The NormDirectoryIterator classes is used to
 * walk directory trees for file transmission
 */
NormDirectoryIterator::NormDirectoryIterator() : current(NULL)
{

}

NormDirectoryIterator::~NormDirectoryIterator()
{
    Close();
}

bool NormDirectoryIterator::Open(const char *thePath)
{
    if(current)
    {
        Close();
    }

    if(thePath && access(thePath, X_OK))
    {
        PLOG(PL_FATAL, "NormDirectoryIterator: can't access directory: %s\n", thePath);
        return false;
    }

    current = new NormDirectory(thePath);

    if(current && current->Open())
    {
        path_len = (int)strlen(current->Path());
        path_len = MIN(PATH_MAX, path_len);
        return true;
    }
    else
    {
        PLOG(PL_FATAL, "NormDirectoryIterator: can't open directory: %s\n", thePath);

        if(current)
        {
            delete current;
        }

        current = NULL;
        return false;
    }
}  // end NormDirectoryIterator::Init()

void NormDirectoryIterator::Close()
{
    NormDirectory* d;

    while((d = current))
    {
        current = d->parent;
        d->Close();
        delete d;
    }
}


bool NormDirectoryIterator::GetPath(char* pathBuffer)
{
    if(current)
    {
        NormDirectory* d = current;

        while(d->parent)
        {
            d = d->parent;
        }

        strncpy(pathBuffer, d->Path(), PATH_MAX);
        return true;
    }
    else
    {
        pathBuffer[0] = '\0';
        return false;
    }
}


bool NormDirectoryIterator::GetNextFile(char* fileName)
{
    if(!current)
    {
        return false;
    }

    struct dirent *dp;

    while((dp = readdir(current->dptr)))
    {
        // Make sure it's not "." or ".."
        if(dp->d_name[0] == '.')
        {
            if((1 == strlen(dp->d_name)) || ((dp->d_name[1] == '.') && (2 == strlen(dp->d_name))))
            {
                continue;  // skip "." and ".." directory names
            }
        }

        current->GetFullName(fileName);
        strcat(fileName, dp->d_name);
        NormFile::Type type = NormFile::GetType(fileName);

        if(NormFile::NORMAL == type)
        {
            int nameLen = strlen(fileName);
            nameLen = MIN(PATH_MAX, nameLen);
            nameLen -= path_len;
            memmove(fileName, fileName + path_len, nameLen);

            if(nameLen < PATH_MAX)
            {
                fileName[nameLen] = '\0';
            }

            return true;
        }
        else if(NormFile::DIRECTORY == type)
        {
            NormDirectory *dir = new NormDirectory(dp->d_name, current);

            if(dir && dir->Open())
            {
                // Push sub-directory onto stack and search it
                current = dir;
                return GetNextFile(fileName);
            }
            else
            {
                // Couldn't open this one, try next one
                if(dir)
                {
                    delete dir;
                }
            }
        }
        else
        {
            // NormFile::INVALID, try next one
        }
    }  // end while(readdir())

    // Pop up a level and recursively continue or finish if done
    if(current->parent)
    {
        char path[PATH_MAX];
        current->parent->GetFullName(path);
        current->Close();
        NormDirectory *dir = current;
        current = current->parent;
        delete dir;
        return GetNextFile(fileName);
    }
    else
    {
        current->Close();
        delete current;
        current = NULL;
        return false;  // no more files remain
    }
}



//===================================================================================================================================

NormDirectoryIterator::NormDirectory::NormDirectory(const char*    thePath,  NormDirectory* theParent) : parent(theParent), dptr(NULL)
{
    strncpy(path, thePath, PATH_MAX);
    size_t len  = MIN(PATH_MAX, strlen(path));

    if((len < PATH_MAX) && (PROTO_PATH_DELIMITER != path[len - 1]))
    {
        path[len++] = PROTO_PATH_DELIMITER; //zb: 'root/ home/ xxx/'

        if(len < PATH_MAX)
        {
            path[len] = '\0';
        }
    }
}

NormDirectoryIterator::NormDirectory::~NormDirectory()
{
    Close();
}



bool NormDirectoryIterator::NormDirectory::Open()
{
    Close();  // in case it's already open
    char fullName[PATH_MAX];
    GetFullName(fullName);

    // Get rid of trailing PROTO_PATH_DELIMITER
    size_t len = MIN(PATH_MAX, strlen(fullName));

    if(PROTO_PATH_DELIMITER == fullName[len - 1])
    {
        fullName[len - 1] = '\0';
    }

    if((dptr = opendir(fullName)))
    {
        return true;
    }
    else
    {
        return false;
    }
}

void NormDirectoryIterator::NormDirectory::Close()
{
    if(dptr)
    {
        closedir(dptr);
        dptr = NULL;
    }
}


void NormDirectoryIterator::NormDirectory::GetFullName(char* ptr)
{
    ptr[0] = '\0';
    RecursiveCatName(ptr);
}

void NormDirectoryIterator::NormDirectory::RecursiveCatName(char* ptr)
{
    if(parent)
    {
        parent->RecursiveCatName(ptr);
    }

    size_t len = MIN(PATH_MAX, strlen(ptr));
    strncat(ptr, path, PATH_MAX - len);
}





//=========================================================================================
// Below are some static routines for getting file/directory information
// Is the named item a valid directory or file (or neither)??
NormFile::Type NormFile::GetType(const char* path)
{
    struct stat file_info;

    if(stat(path, &file_info))
    {
        return INVALID;    // stat() error
    }
    else if((S_ISDIR(file_info.st_mode)))
    {
        return DIRECTORY;
    }
    else
    {
        return NORMAL;
    }
}



NormFile::Offset NormFile::GetSize(const char* path)
{
    struct stat info;
    int result = stat(path, &info);

    if(result)
    {
        //DMSG(0, "Error getting file size: %s\n", GetErrorString());
        return 0;
    }
    else
    {
        return info.st_size;
    }
}


time_t NormFile::GetUpdateTime(const char* path)
{
    struct stat info;
    int result = stat(path, &info);

    if(result)
    {
        return (time_t)0;  // stat() error
    }
    else
    {
        return info.st_ctime;
    }
}



bool NormFile::IsLocked(const char* path)
{
    // If file doesn't exist, it's not locked
    if(!Exists(path))
    {
        return false;
    }

    NormFile testFile;

    if(!testFile.Open(path, O_WRONLY | O_CREAT))
    {
        return true;
    }
    else if(testFile.Lock())
    {
        // We were able to lock the file successfully
        testFile.Unlock();
        testFile.Close();
        return false;
    }
    else
    {
        testFile.Close();
        return true;
    }
}  // end NormFile::IsLocked()


bool NormFile::Unlink(const char* path)
{
    // Don't unlink a file that is open (locked)
    if(NormFile::IsLocked(path))
    {
        return false;
    }

    if(unlink(path))
    {
        PLOG(PL_FATAL, "NormFile::Unlink() unlink error: %s\n", GetErrorString());
        return false;
    }
    else
    {
        return true;
    }

}



//=========================================================================================
NormFileList::NormFileList() : this_time(0), big_time(0), last_time(0), updates_only(false), head(NULL), tail(NULL), next(NULL)
{
}

NormFileList::~NormFileList()
{
    Destroy();
}

void NormFileList::Destroy()
{
    while((next = head))
    {
        head = next->next;
        delete next;
    }

    tail = NULL;
}


bool NormFileList::Append(const char* path)
{
    FileItem* theItem = NULL;

    switch(NormFile::GetType(path))
    {
    case NormFile::NORMAL:
        theItem = new FileItem(path);
        break;

    case NormFile::DIRECTORY:
        theItem = new DirectoryItem(path);
        break;

    default:

        // Allow non-existent files for update_only mode
        // (TBD) allow non-existent directories?
        if(updates_only)
        {
            theItem = new FileItem(path);
        }
        else
        {
            PLOG(PL_FATAL, "NormFileList::Append() Bad file/directory name: %s\n", path);
            return false;
        }

        break;
    }

    if(theItem)
    {
        theItem->next = NULL;

        if((theItem->prev = tail))
        {
            tail->next = theItem;
        }
        else
        {
            head = theItem;
        }

        tail = theItem;
        return true;
    }
    else
    {
        PLOG(PL_FATAL, "NormFileList::Append() Error creating file/directory item: %s\n", GetErrorString());
        return false;
    }
}  


bool NormFileList::Remove(const char* path)
{
    FileItem* nextItem = head;
    size_t pathLen = strlen(path);
    pathLen = MIN(pathLen, PATH_MAX);

    while(nextItem)
    {
        size_t nameLen = strlen(nextItem->Path());
        nameLen = MIN(nameLen, PATH_MAX);
        nameLen = MAX(nameLen, pathLen);

        if(!strncmp(path, nextItem->Path(), nameLen))
        {
            if(nextItem == next)
            {
                next = nextItem->next;
            }

            if(nextItem->prev)
            {
                nextItem->prev = next = nextItem->next;
            }
            else
            {
                head = nextItem->next;
            }

            if(nextItem->next)
            {
                nextItem->next->prev = nextItem->prev;
            }
            else
            {
                tail = nextItem->prev;
            }

            return true;
        }
    }

    return false;
} 


bool NormFileList::GetNextFile(char* pathBuffer)
{
    if(!next)
    {
        next = head;
        reset = true;
    }

    if(next)
    {
        if(next->GetNextFile(pathBuffer, reset, updates_only, last_time, this_time, big_time))
        {
            reset = false;
            return true;
        }
        else
        {
            if(next->next)
            {
                next = next->next;
                reset = true;
                return GetNextFile(pathBuffer);
            }
            else
            {
                reset = false;
                return false;  // end of list
            }
        }
    }
    else
    {
        return false;  // empty list
    }
}



void NormFileList::GetCurrentBasePath(char* pathBuffer)
{
    if(next)
    {
        if(NormFile::DIRECTORY == next->GetType())
        {
            strncpy(pathBuffer, next->Path(), PATH_MAX);
            size_t len = strlen(pathBuffer);
            len = MIN(len, PATH_MAX);

            if(PROTO_PATH_DELIMITER != pathBuffer[len - 1])
            {
                if(len < PATH_MAX)
                {
                    pathBuffer[len++] = PROTO_PATH_DELIMITER;
                }

                if(len < PATH_MAX)
                {
                    pathBuffer[len] = '\0';
                }
            }
        }
        else  // NormFile::NORMAL
        {
            const char* ptr = strrchr(next->Path(), PROTO_PATH_DELIMITER);

            if(ptr++)
            {
                size_t len = ptr - next->Path();
                strncpy(pathBuffer, next->Path(), len);
                pathBuffer[len] = '\0';
            }
            else
            {
                pathBuffer[0] = '\0';
            }
        }
    }
    else
    {
        pathBuffer[0] = '\0';
    }
}




//================================================================================================
NormFileList::FileItem::FileItem(const char* thePath) : prev(NULL), next(NULL)
{
    size_t len = strlen(thePath);
    len = MIN(len, PATH_MAX);
    strncpy(path, thePath, PATH_MAX);
    size = NormFile::GetSize(thePath);
}

NormFileList::FileItem::~FileItem()
{
}

bool NormFileList::FileItem::GetNextFile(char*   thePath,
        bool    reset,
        bool    updatesOnly,
        time_t  lastTime,
        time_t  thisTime,
        time_t& bigTime)
{
    if(reset)
    {
        if(updatesOnly)
        {
            time_t updateTime = NormFile::GetUpdateTime(thePath);

            if(updateTime > bigTime)
            {
                bigTime = updateTime;
            }

            if((updateTime <= lastTime) || (updateTime > thisTime))
            {
                return false;
            }
        }

        strncpy(thePath, path, PATH_MAX);
        return true;
    }
    else
    {
        return false;
    }
}







//================================================================================================
NormFileList::DirectoryItem::DirectoryItem(const char* thePath) : NormFileList::FileItem(thePath)
{

}

NormFileList::DirectoryItem::~DirectoryItem()
{
    diterator.Close();
}

bool NormFileList::DirectoryItem::GetNextFile(char*   thePath,
        bool    reset,
        bool    updatesOnly,
        time_t  lastTime,
        time_t  thisTime,
        time_t& bigTime)
{
    if(reset)
    {
        /* For now we are going to poll all files in a directory individually
          since directory update times aren't always changed when files are
          are replaced within the directory tree ... uncomment this code
          if you only want to check directory nodes that have had their
          change time updated
        if (updates_only)
        {
           // Check to see if directory has been touched
           time_t update_time = MdpFileGetUpdateTime(path);
           if (updateTime > bigTime) *bigTime = updateTime;
           if ((updateTime <= lastTime) || (updateTime > thisTime))
               return false;
        } */
        if(!diterator.Open(path))
        {
            PLOG(PL_FATAL, "NormFileList::DirectoryItem::GetNextFile() Directory iterator init error\n");
            return false;
        }
    }

    strncpy(thePath, path, PATH_MAX);
    size_t len = strlen(thePath);
    len = MIN(len, PATH_MAX);

    if((PROTO_PATH_DELIMITER != thePath[len - 1]) && (len < PATH_MAX))
    {
        thePath[len++] = PROTO_PATH_DELIMITER;

        if(len < PATH_MAX)
        {
            thePath[len] = '\0';
        }
    }

    char tempPath[PATH_MAX];
    while(diterator.GetNextFile(tempPath))
    {
        size_t maxLen = PATH_MAX - len;
        strncat(thePath, tempPath, maxLen);

        if(updatesOnly)
        {
            time_t updateTime = NormFile::GetUpdateTime(thePath);

            if(updateTime > bigTime)
            {
                bigTime = updateTime;
            }

            if((updateTime <= lastTime) || (updateTime > thisTime))
            {
                thePath[len] = '\0';
                continue;
            }
        }

        return true;
    }

    return false;
}



