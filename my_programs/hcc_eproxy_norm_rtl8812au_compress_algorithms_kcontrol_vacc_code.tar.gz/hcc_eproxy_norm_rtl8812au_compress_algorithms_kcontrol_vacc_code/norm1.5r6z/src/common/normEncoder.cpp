

#include <stdlib.h>
#include <string.h>


#include "normEncoder.h"
#include "galois.h"  // for Galois math routines


#include <stdio.h>
#include "protoDefs.h"  // for struct timeval



#define DIFF_T(a,b) (1+ 1000000*(a.tv_sec - b.tv_sec) + (a.tv_usec - b.tv_usec) )



NormEncoder::~NormEncoder()
{

}

NormDecoder::~NormDecoder()
{

}



