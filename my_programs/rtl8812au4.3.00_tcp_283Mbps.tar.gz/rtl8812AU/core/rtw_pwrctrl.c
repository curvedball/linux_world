


#define _RTW_PWRCTRL_C_

#include <drv_types.h>
#include <hal_data.h>
#include <hal_com_h2c.h>




int rtw_fw_ps_state(PADAPTER padapter)
{
    struct dvobj_priv *psdpriv = padapter->dvobj;
    struct debug_priv *pdbgpriv = &psdpriv->drv_dbg;
    int ret=_FAIL, dont_care=0;
    u16 fw_ps_state=0;
    u32 start_time;
    struct pwrctrl_priv *pwrpriv = adapter_to_pwrctl(padapter);
    struct registry_priv  *registry_par = &padapter->registrypriv;

    if(registry_par->check_fw_ps != 1)
        return _SUCCESS;

    _enter_pwrlock(&pwrpriv->check_32k_lock);

    if (RTW_CANNOT_RUN(padapter))
    {
        DBG_871X("%s: bSurpriseRemoved=%s , hw_init_completed=%d, bDriverStopped=%s\n", __func__
                 , rtw_is_surprise_removed(padapter)?"True":"False"
                 , rtw_get_hw_init_completed(padapter)
                 , rtw_is_drv_stopped(padapter)?"True":"False");
        goto exit_fw_ps_state;
    }
    rtw_hal_set_hwreg(padapter, HW_VAR_SET_REQ_FW_PS, (u8 *)&dont_care);
    {
        //4. if 0x88[7]=1, driver set cmd to leave LPS/IPS.
        //Else, hw will keep in active mode.
        //debug info:
        //0x88[7] = 32kpermission,
        //0x88[6:0] = current_ps_state
        //0x89[7:0] = last_rpwm

        rtw_hal_get_hwreg(padapter, HW_VAR_FW_PS_STATE, (u8 *)&fw_ps_state);

        if((fw_ps_state & 0x80) == 0)
            ret=_SUCCESS;
        else
        {
            pdbgpriv->dbg_poll_fail_cnt++;
            DBG_871X("%s: fw_ps_state=%04x \n", __FUNCTION__, fw_ps_state);
        }
    }


exit_fw_ps_state:
    _exit_pwrlock(&pwrpriv->check_32k_lock);
    return ret;
}




bool rtw_pwr_unassociated_idle(_adapter *adapter)
{
    _adapter *buddy = adapter->pbuddy_adapter;
    struct mlme_priv *pmlmepriv = &(adapter->mlmepriv);
    struct xmit_priv *pxmit_priv = &adapter->xmitpriv;

    bool ret = _FALSE;

    if (adapter_to_pwrctl(adapter)->bpower_saving ==_TRUE )
    {
        //DBG_871X("%s: already in LPS or IPS mode\n", __func__);
        goto exit;
    }

    if (adapter_to_pwrctl(adapter)->ips_deny_time >= rtw_get_current_time())
    {
        //DBG_871X("%s ips_deny_time\n", __func__);
        goto exit;
    }

    if (check_fwstate(pmlmepriv, WIFI_ASOC_STATE|WIFI_SITE_MONITOR)
        || check_fwstate(pmlmepriv, WIFI_UNDER_LINKING|WIFI_UNDER_WPS)
        || check_fwstate(pmlmepriv, WIFI_AP_STATE)
        || check_fwstate(pmlmepriv, WIFI_ADHOC_MASTER_STATE|WIFI_ADHOC_STATE)
       )
    {
        goto exit;
    }

    /* consider buddy, if exist */
    if (buddy)
    {
        struct mlme_priv *b_pmlmepriv = &(buddy->mlmepriv);

        if (check_fwstate(b_pmlmepriv, WIFI_ASOC_STATE|WIFI_SITE_MONITOR)
            || check_fwstate(b_pmlmepriv, WIFI_UNDER_LINKING|WIFI_UNDER_WPS)
            || check_fwstate(b_pmlmepriv, WIFI_AP_STATE)
            || check_fwstate(b_pmlmepriv, WIFI_ADHOC_MASTER_STATE|WIFI_ADHOC_STATE)
           )
        {
            goto exit;
        }
    }


    if (pxmit_priv->free_xmitbuf_cnt != NR_XMITBUFF ||
        pxmit_priv->free_xmit_extbuf_cnt != NR_XMIT_EXTBUFF)
    {
        DBG_871X_LEVEL(_drv_always_, "There are some pkts to transmit\n");
        DBG_871X_LEVEL(_drv_always_, "free_xmitbuf_cnt: %d, free_xmit_extbuf_cnt: %d\n",
                       pxmit_priv->free_xmitbuf_cnt, pxmit_priv->free_xmit_extbuf_cnt);
        goto exit;
    }

    ret = _TRUE;

exit:
    return ret;
}





/*
 * ATTENTION:
 *  rtw_ps_processor() doesn't handle LPS.
 */
void rtw_ps_processor(_adapter*padapter)
{
    struct pwrctrl_priv *pwrpriv = adapter_to_pwrctl(padapter);
    struct mlme_priv *pmlmepriv = &(padapter->mlmepriv);
    struct dvobj_priv *psdpriv = padapter->dvobj;
    struct debug_priv *pdbgpriv = &psdpriv->drv_dbg;

    u32 ps_deny = 0;

    _enter_pwrlock(&adapter_to_pwrctl(padapter)->lock);
    ps_deny = rtw_ps_deny_get(padapter);
    _exit_pwrlock(&adapter_to_pwrctl(padapter)->lock);
    if (ps_deny != 0)
    {
        DBG_871X(FUNC_ADPT_FMT ": ps_deny=0x%08X, skip power save!\n",
                 FUNC_ADPT_ARG(padapter), ps_deny);
        goto exit;
    }

    if(pwrpriv->bInSuspend == _TRUE) //system suspend or autosuspend
    {
        pdbgpriv->dbg_ps_insuspend_cnt++;
        DBG_871X("%s, pwrpriv->bInSuspend == _TRUE ignore this process\n",__FUNCTION__);
        return;
    }

    pwrpriv->ps_processing = _TRUE;


    if (pwrpriv->ips_mode_req == IPS_NONE)
        goto exit;

    if (rtw_pwr_unassociated_idle(padapter) == _FALSE)
        goto exit;

    if((pwrpriv->rf_pwrstate == rf_on) && ((pwrpriv->pwr_state_check_cnts%4)==0))
    {
        DBG_871X("==>%s .fw_state(%x)\n",__FUNCTION__,get_fwstate(pmlmepriv));
        pwrpriv->change_rfpwrstate = rf_off;
        {

        }
    }
exit:
    rtw_set_pwr_state_check_timer(pwrpriv);
    pwrpriv->ps_processing = _FALSE;
    return;
}




void pwr_state_check_handler(RTW_TIMER_HDL_ARGS);
void pwr_state_check_handler(RTW_TIMER_HDL_ARGS)
{
    _adapter *padapter = (_adapter *)FunctionContext;
    rtw_ps_cmd(padapter);
}




void LeaveAllPowerSaveModeDirect(PADAPTER Adapter)
{
    PADAPTER pri_padapter = GET_PRIMARY_ADAPTER(Adapter);
    struct mlme_priv    *pmlmepriv = &(Adapter->mlmepriv);
    struct pwrctrl_priv *pwrpriv = adapter_to_pwrctl(Adapter);
    struct dvobj_priv *psdpriv = Adapter->dvobj;
    struct debug_priv *pdbgpriv = &psdpriv->drv_dbg;

    u8 cpwm_orig, cpwm_now;
    u32 start_time;


    _func_enter_;

    DBG_871X("%s.....\n",__FUNCTION__);

    if (rtw_is_surprise_removed(Adapter))
    {
        DBG_871X(FUNC_ADPT_FMT ": bSurpriseRemoved=_TRUE Skip!\n", FUNC_ADPT_ARG(Adapter));
        return;
    }

    if ((check_fwstate(pmlmepriv, _FW_LINKED) == _TRUE)
       )
    {
        //connect

        if(pwrpriv->pwr_mode == PS_MODE_ACTIVE)
        {
            DBG_871X("%s: Driver Already Leave LPS\n",__FUNCTION__);
            return;
        }
    }
    else
    {
        if(pwrpriv->rf_pwrstate== rf_off)
        {
            {
            
            }
        }
    }

    _func_exit_;
}





//
// Description: Leave all power save mode: LPS, FwLPS, IPS if needed.
// Move code to function by tynli. 2010.03.26.
//
void LeaveAllPowerSaveMode(IN PADAPTER Adapter)
{
    struct dvobj_priv *dvobj = adapter_to_dvobj(Adapter);
    struct mlme_priv    *pmlmepriv = &(Adapter->mlmepriv);
    u8  enqueue = 0;
    int n_assoc_iface = 0;
    int i;

    _func_enter_;

    //DBG_871X("%s.....\n",__FUNCTION__);

    if (_FALSE == Adapter->bup)
    {
        DBG_871X(FUNC_ADPT_FMT ": bup=%d Skip!\n",
                 FUNC_ADPT_ARG(Adapter), Adapter->bup);
        return;
    }

    if (rtw_is_surprise_removed(Adapter))
    {
        DBG_871X(FUNC_ADPT_FMT ": bSurpriseRemoved=_TRUE Skip!\n", FUNC_ADPT_ARG(Adapter));
        return;
    }

    for (i = 0; i < dvobj->iface_nums; i++)
    {
        if (check_fwstate(&(dvobj->padapters[i]->mlmepriv), WIFI_ASOC_STATE))
            n_assoc_iface++;
    }

    if (n_assoc_iface)
    {

    }
    else
    {
        if(adapter_to_pwrctl(Adapter)->rf_pwrstate== rf_off)
        {
            {
            
            }
        }
    }

    _func_exit_;
}





void rtw_init_pwrctrl_priv(PADAPTER padapter)
{
    struct pwrctrl_priv *pwrctrlpriv = adapter_to_pwrctl(padapter);
    int i = 0;
    u8 val8 = 0;

    _func_enter_;

    _init_pwrlock(&pwrctrlpriv->lock);
    _init_pwrlock(&pwrctrlpriv->check_32k_lock);
    pwrctrlpriv->rf_pwrstate = rf_on;
    pwrctrlpriv->ips_enter_cnts=0;
    pwrctrlpriv->ips_leave_cnts=0;
    pwrctrlpriv->lps_enter_cnts=0;
    pwrctrlpriv->lps_leave_cnts=0;
    pwrctrlpriv->bips_processing = _FALSE;

    pwrctrlpriv->ips_mode = padapter->registrypriv.ips_mode;
    pwrctrlpriv->ips_mode_req = padapter->registrypriv.ips_mode;

    pwrctrlpriv->pwr_state_check_interval = RTW_PWR_STATE_CHK_INTERVAL;
    pwrctrlpriv->pwr_state_check_cnts = 0;
    pwrctrlpriv->bInternalAutoSuspend = _FALSE;
    pwrctrlpriv->bInSuspend = _FALSE;
    pwrctrlpriv->bkeepfwalive = _FALSE;

    pwrctrlpriv->LpsIdleCount = 0;
    //pwrctrlpriv->FWCtrlPSMode =padapter->registrypriv.power_mgnt;// PS_MODE_MIN;
    if (padapter->registrypriv.mp_mode == 1)
        pwrctrlpriv->power_mgnt =PS_MODE_ACTIVE ;
    else
        pwrctrlpriv->power_mgnt =padapter->registrypriv.power_mgnt;// PS_MODE_MIN;
    pwrctrlpriv->bLeisurePs = (PS_MODE_ACTIVE != pwrctrlpriv->power_mgnt)?_TRUE:_FALSE;

    pwrctrlpriv->bFwCurrentInPSMode = _FALSE;

    pwrctrlpriv->rpwm = 0;
    pwrctrlpriv->cpwm = PS_STATE_S4;

    pwrctrlpriv->pwr_mode = PS_MODE_ACTIVE;
    pwrctrlpriv->smart_ps = padapter->registrypriv.smart_ps;
    pwrctrlpriv->bcn_ant_mode = 0;
    pwrctrlpriv->dtim = 0;

    pwrctrlpriv->tog = 0x80;


    rtw_init_timer(&pwrctrlpriv->pwr_state_check_timer, padapter, pwr_state_check_handler);

    pwrctrlpriv->wowlan_mode = _FALSE;
    pwrctrlpriv->wowlan_ap_mode = _FALSE;
    pwrctrlpriv->wowlan_p2p_mode = _FALSE;


    _func_exit_;

}




void rtw_free_pwrctrl_priv(PADAPTER adapter)
{
    struct pwrctrl_priv *pwrctrlpriv = adapter_to_pwrctl(adapter);

    _func_enter_;

    //_rtw_memset((unsigned char *)pwrctrlpriv, 0, sizeof(struct pwrctrl_priv));

    _free_pwrlock(&pwrctrlpriv->lock);
    _free_pwrlock(&pwrctrlpriv->check_32k_lock);

    _func_exit_;
}





u8 rtw_interface_ps_func(_adapter *padapter,HAL_INTF_PS_FUNC efunc_id,u8* val)
{
    u8 bResult = _TRUE;
    rtw_hal_intf_ps_func(padapter,efunc_id,val);

    return bResult;
}




inline void rtw_set_ips_deny(_adapter *padapter, u32 ms)
{
    struct pwrctrl_priv *pwrpriv = adapter_to_pwrctl(padapter);
    pwrpriv->ips_deny_time = rtw_get_current_time() + rtw_ms_to_systime(ms);
}




/*
* rtw_pwr_wakeup - Wake the NIC up from: 1)IPS. 2)USB autosuspend
* @adapter: pointer to _adapter structure
* @ips_deffer_ms: the ms wiil prevent from falling into IPS after wakeup
* Return _SUCCESS or _FAIL
*/

int _rtw_pwr_wakeup(_adapter *padapter, u32 ips_deffer_ms, const char *caller)
{
    struct dvobj_priv *dvobj = adapter_to_dvobj(padapter);
    struct pwrctrl_priv *pwrpriv = dvobj_to_pwrctl(dvobj);
    struct mlme_priv *pmlmepriv;
    int ret = _SUCCESS;
    int i;
    u32 start = rtw_get_current_time();

    /* for LPS */
    LeaveAllPowerSaveMode(padapter);

    /* IPS still bound with primary adapter */
    padapter = GET_PRIMARY_ADAPTER(padapter);
    pmlmepriv = &padapter->mlmepriv;

    if (pwrpriv->ips_deny_time < rtw_get_current_time() + rtw_ms_to_systime(ips_deffer_ms))
        pwrpriv->ips_deny_time = rtw_get_current_time() + rtw_ms_to_systime(ips_deffer_ms);


    if (pwrpriv->ps_processing)
    {
        DBG_871X("%s wait ps_processing...\n", __func__);
        while (pwrpriv->ps_processing && rtw_get_passing_time_ms(start) <= 3000)
            rtw_msleep_os(10);
        if (pwrpriv->ps_processing)
            DBG_871X("%s wait ps_processing timeout\n", __func__);
        else
            DBG_871X("%s wait ps_processing done\n", __func__);
    }

    if (pwrpriv->bInternalAutoSuspend == _FALSE && pwrpriv->bInSuspend)
    {
        DBG_871X("%s wait bInSuspend...\n", __func__);
        while (pwrpriv->bInSuspend
               && ((rtw_get_passing_time_ms(start) <= 3000 && !rtw_is_do_late_resume(pwrpriv))
                   || (rtw_get_passing_time_ms(start) <= 500 && rtw_is_do_late_resume(pwrpriv)))
              )
        {
            rtw_msleep_os(10);
        }
        if (pwrpriv->bInSuspend)
            DBG_871X("%s wait bInSuspend timeout\n", __func__);
        else
            DBG_871X("%s wait bInSuspend done\n", __func__);
    }

    //System suspend is not allowed to wakeup
    if((pwrpriv->bInternalAutoSuspend == _FALSE) && (_TRUE == pwrpriv->bInSuspend ))
    {
        ret = _FAIL;
        goto exit;
    }

    //block???
    if((pwrpriv->bInternalAutoSuspend == _TRUE)  && (padapter->net_closed == _TRUE))
    {
        ret = _FAIL;
        goto exit;
    }

    //I think this should be check in IPS, LPS, autosuspend functions...
    if (check_fwstate(pmlmepriv, _FW_LINKED) == _TRUE)
    {
        ret = _SUCCESS;
        goto exit;
    }

    if(rf_off == pwrpriv->rf_pwrstate )
    {
        {

        }
    }

    //TODO: the following checking need to be merged...
    if (rtw_is_drv_stopped(padapter)
        || !padapter->bup
        || !rtw_is_hw_init_completed(padapter)
       )
    {
        DBG_8192C("%s: bDriverStopped=%s, bup=%d, hw_init_completed=%u\n"
                  , caller
                  , rtw_is_drv_stopped(padapter)?"True":"False"
                  , padapter->bup
                  , rtw_get_hw_init_completed(padapter));
        ret= _FALSE;
        goto exit;
    }

exit:
    if (pwrpriv->ips_deny_time < rtw_get_current_time() + rtw_ms_to_systime(ips_deffer_ms))
        pwrpriv->ips_deny_time = rtw_get_current_time() + rtw_ms_to_systime(ips_deffer_ms);
    return ret;

}




int rtw_pm_set_lps(_adapter *padapter, u8 mode)
{
    int ret = 0;
    struct pwrctrl_priv *pwrctrlpriv = adapter_to_pwrctl(padapter);

    if ( mode < PS_MODE_NUM )
    {
        if(pwrctrlpriv->power_mgnt !=mode)
        {
            if(PS_MODE_ACTIVE == mode)
            {
                LeaveAllPowerSaveMode(padapter);
            }
            else
            {
                pwrctrlpriv->LpsIdleCount = 2;
            }
            pwrctrlpriv->power_mgnt = mode;
            pwrctrlpriv->bLeisurePs = (PS_MODE_ACTIVE != pwrctrlpriv->power_mgnt)?_TRUE:_FALSE;
        }
    }
    else
    {
        ret = -EINVAL;
    }

    return ret;
}




int rtw_pm_set_ips(_adapter *padapter, u8 mode)
{
    struct pwrctrl_priv *pwrctrlpriv = adapter_to_pwrctl(padapter);

    if( mode == IPS_NORMAL || mode == IPS_LEVEL_2 )
    {
        rtw_ips_mode_req(pwrctrlpriv, mode);
        DBG_871X("%s %s\n", __FUNCTION__, mode == IPS_NORMAL?"IPS_NORMAL":"IPS_LEVEL_2");
        return 0;
    }
    else if(mode ==IPS_NONE)
    {
        rtw_ips_mode_req(pwrctrlpriv, mode);
        DBG_871X("%s %s\n", __FUNCTION__, "IPS_NONE");
        if (!rtw_is_surprise_removed(padapter) && (_FAIL == rtw_pwr_wakeup(padapter)))
            return -EFAULT;
    }
    else
    {
        return -EINVAL;
    }
    return 0;
}




/*
 * ATTENTION:
 *  This function will request pwrctrl LOCK!
 */
void rtw_ps_deny(PADAPTER padapter, PS_DENY_REASON reason)
{
    struct pwrctrl_priv *pwrpriv;
    s32 ret;


//  DBG_871X("+" FUNC_ADPT_FMT ": Request PS deny for %d (0x%08X)\n",
//      FUNC_ADPT_ARG(padapter), reason, BIT(reason));

    pwrpriv = adapter_to_pwrctl(padapter);

    _enter_pwrlock(&pwrpriv->lock);
    if (pwrpriv->ps_deny & BIT(reason))
    {
        DBG_871X(FUNC_ADPT_FMT ": [WARNING] Reason %d had been set before!!\n",
                 FUNC_ADPT_ARG(padapter), reason);
    }
    pwrpriv->ps_deny |= BIT(reason);
    _exit_pwrlock(&pwrpriv->lock);

//  DBG_871X("-" FUNC_ADPT_FMT ": Now PS deny for 0x%08X\n",
//      FUNC_ADPT_ARG(padapter), pwrpriv->ps_deny);
}





/*
 * ATTENTION:
 *  This function will request pwrctrl LOCK!
 */
void rtw_ps_deny_cancel(PADAPTER padapter, PS_DENY_REASON reason)
{
    struct pwrctrl_priv *pwrpriv;


//  DBG_871X("+" FUNC_ADPT_FMT ": Cancel PS deny for %d(0x%08X)\n",
//      FUNC_ADPT_ARG(padapter), reason, BIT(reason));

    pwrpriv = adapter_to_pwrctl(padapter);

    _enter_pwrlock(&pwrpriv->lock);
    if ((pwrpriv->ps_deny & BIT(reason)) == 0)
    {
        DBG_871X(FUNC_ADPT_FMT ": [ERROR] Reason %d had been canceled before!!\n",
                 FUNC_ADPT_ARG(padapter), reason);
    }
    pwrpriv->ps_deny &= ~BIT(reason);
    _exit_pwrlock(&pwrpriv->lock);

//  DBG_871X("-" FUNC_ADPT_FMT ": Now PS deny for 0x%08X\n",
//      FUNC_ADPT_ARG(padapter), pwrpriv->ps_deny);
}




/*
 * ATTENTION:
 *  Before calling this function pwrctrl lock should be occupied already,
 *  otherwise it may return incorrect value.
 */
u32 rtw_ps_deny_get(PADAPTER padapter)
{
    u32 deny;


    deny = adapter_to_pwrctl(padapter)->ps_deny;

    return deny;
}



