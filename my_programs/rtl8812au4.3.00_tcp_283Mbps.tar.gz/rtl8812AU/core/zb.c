                                               

#include "zb.h"




/*

*/


//int gTestXmitPktCnt = 0;
//int gTestRecvPktCnt = 0;
int gPktCnt = 0;
int gCtrlFramePktCnt = 0;
int gTcpAckPktCnt = 0;


int gTransmitOkDataPktCnt = 0;
int gRetransmitOkDataPktCnt = 0;

int gTransmitOkNoNodeCnt = 0;
int gTransmitErrorNoNodeCnt = 0;



#define NUM_PRINT_PKTS 200


#define NUMCHARS 20
void DbgPrintTestXmitPkt(u8* p, uint len)
{
	int i;
	u8 c;
	u16 seg;

	//
	return;

	gPktCnt++;
	if (gPktCnt > 10)
	{
		return;
	}
	//if (len > 12 && IsTargetMac(p, len) && IsIpV4Pkt(p, len))
	{
		printk("\n\n==============DbgPrintTestXmitPkt=====Pkt len: %u===============\n", len);
		seg = len / 20;
		for (i = 0; i < seg; i++)
		{
			printk("%.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X",
				p[NUMCHARS*i], p[NUMCHARS*i+1], p[NUMCHARS*i+2], p[NUMCHARS*i+3], p[NUMCHARS*i+4], p[NUMCHARS*i+5], p[NUMCHARS*i+6], p[NUMCHARS*i+7], p[NUMCHARS*i+8], p[NUMCHARS*i+9],
				p[NUMCHARS*i+10], p[NUMCHARS*i+11], p[NUMCHARS*i+12], p[NUMCHARS*i+13], p[NUMCHARS*i+14], p[NUMCHARS*i+15], p[NUMCHARS*i+16], p[NUMCHARS*i+17], p[NUMCHARS*i+18], p[NUMCHARS*i+19]);
		}
		
		/*
		for (i =0; i < len; i++)
		{
			c = p[i] & 0xFF;
			printk("%.2X ", c);
			if ((i % 40 == 0) && (i != 0))
			{
				//printk("\n");
			}
		}
		*/
		//printk("\n==============DbgPrintTestXmitPkt=====end=============\n");
		printk("\n");
	}
}


void DbgPrintPkt(u8* p, uint len)
{
	int i;
	u8 c;
	u16 seg;

	gPktCnt++;
	if (gPktCnt > NUM_PRINT_PKTS)
	{
		return;
	}
	
	//if (len > 12 && IsTargetMac(p, len) && IsIpV4Pkt(p, len))
	{
		//printk("\n\n==============DbgPrintTestXmitPkt=====Pkt len: %u===============\n", len);
		seg = len / 20;
		for (i = 0; i < seg; i++)
		{
			printk("%.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X",
				p[NUMCHARS*i], p[NUMCHARS*i+1], p[NUMCHARS*i+2], p[NUMCHARS*i+3], p[NUMCHARS*i+4], p[NUMCHARS*i+5], p[NUMCHARS*i+6], p[NUMCHARS*i+7], p[NUMCHARS*i+8], p[NUMCHARS*i+9],
				p[NUMCHARS*i+10], p[NUMCHARS*i+11], p[NUMCHARS*i+12], p[NUMCHARS*i+13], p[NUMCHARS*i+14], p[NUMCHARS*i+15], p[NUMCHARS*i+16], p[NUMCHARS*i+17], p[NUMCHARS*i+18], p[NUMCHARS*i+19]);
		}
		
		/*
		for (i =0; i < len; i++)
		{
			c = p[i] & 0xFF;
			printk("%.2X ", c);
			if ((i % 40 == 0) && (i != 0))
			{
				//printk("\n");
			}
		}
		*/
		//printk("\n==============DbgPrintTestXmitPkt=====end=============\n");
		printk("\n");
	}
}


void DbgPrintPktNoRestriction(u8* p, uint len)
{
	int i;
	u8 c;
	u16 seg;

	//if (len > 12 && IsTargetMac(p, len) && IsIpV4Pkt(p, len))
	{
		//printk("\n\n==============DbgPrintTestXmitPkt=====Pkt len: %u===============\n", len);
		seg = len / 20;
		for (i = 0; i < seg; i++)
		{
			printk("%.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X",
				p[NUMCHARS*i], p[NUMCHARS*i+1], p[NUMCHARS*i+2], p[NUMCHARS*i+3], p[NUMCHARS*i+4], p[NUMCHARS*i+5], p[NUMCHARS*i+6], p[NUMCHARS*i+7], p[NUMCHARS*i+8], p[NUMCHARS*i+9],
				p[NUMCHARS*i+10], p[NUMCHARS*i+11], p[NUMCHARS*i+12], p[NUMCHARS*i+13], p[NUMCHARS*i+14], p[NUMCHARS*i+15], p[NUMCHARS*i+16], p[NUMCHARS*i+17], p[NUMCHARS*i+18], p[NUMCHARS*i+19]);
		}
		
		/*
		for (i =0; i < len; i++)
		{
			c = p[i] & 0xFF;
			printk("%.2X ", c);
			if ((i % 40 == 0) && (i != 0))
			{
				//printk("\n");
			}
		}
		*/
		//printk("\n==============DbgPrintTestXmitPkt=====end=============\n");
		printk("\n");
	}
}




/*
bool IsTargetMac(u8* p, uint len)
{
	int i;

	for (i =0; i < len - 12; i++)
	{
		if (p[i] == 0x88 && p[i+1] == 0x25 && p[i+2] == 0x93 && p[i+3] == 0xb0 && p[i+4]==0x3f && p[i+5]==0x0b)
		{
			return TRUE;
		}
	}
	
	for (i =0; i < len - 12; i++)
	{
		if (p[i+6] == 0x88 && p[i+7] == 0x25 && p[i+8] == 0x93 && p[i+9] == 0xb0 && p[i+10]==0x3f && p[i+11]==0x0b)
		{
			return TRUE;
		}
	}

	return FALSE;	
}


bool IsIpV4Pkt(u8* p, uint len)
{
	int i;
	for (i =0; i < len - 2; i++)
	{
		if (p[i] == 0x45 && p[i+1] == 0x00)
		{
			return TRUE;
		}
	}
	return FALSE;
}
*/



void DbgPrintCtrlFrame(u8* p, int len)
{
//#if ZB_DBG_PRINT
	u16 startMacSeqNumber;
	if (len == 28)
	{
		startMacSeqNumber = GetMyMacSequence(p);

#if ZB2_PRINT
		printk("\n\n==============Ctrl Frame len: %u==========startMacSeqNumber:%u=====\n", len, startMacSeqNumber);
#endif
		/*
		printk("%.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X",
				p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9],
				p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19]);
		
		printk("%.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X",
				p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27]);

		printk("\n");
		*/
	}
//#endif
}

void DbgPrintC2H_Frame(u8* p, int len)
{
	/*
	int i;
	u8 c;
	//if (len > 12 && IsTargetMac(p, len) && IsIpV4Pkt(p, len))
	{
		printk("\n\n==============C2H Frame len: %u===============\n", len);
		for (i =0; i < len; i++)
		{
			c = p[i] & 0xFF;
			printk("%.2X ", c);
			if (i % 40 == 0 && i != 0)
			{
				printk("\n");
			}
		}
		printk("\n\n");
	}	
	*/
}



/*
bool FindBlockAckTargetData(u8* p, uint len)
{
	int i;
	for (i = 0; i < len - 4; i++)
	{
		if ((p[i] == 0x94) && (p[i+1] == 0x00) && (p[i+2] == 0x40) && (p[i+3] == 0x00))
		{
			return TRUE;
		}
	}
	return FALSE;
}
*/


u8* gApMacAddress = "88:25:93:b0:64:26";
u8* gStaMacAddress = "88:25:93:b0:3f:0b";


//============================================================
u8 getHexValue(u8* p)
{
	//'88' --> 0x88
	u8 v0, v1, v;
	if (p[0] >= '0'  && p[0] < 'a')
	{
		v0 = p[0] - '0';
	}
	else if (p[0] >= 'a'  && p[0] <= 'f')
	{
		v0 = p[0] - 'a';		
	}
	else
	{
		v0 = 0;
	}

	if (p[1] >= '0'  && p[1] < 'a')
	{
		v1 = p[1] - '0';
	}
	else if (p[1] >= 'a'  && p[1] <= 'f')
	{
		v1 = p[1] - 'a';		
	}
	else
	{
		v1 = 0;
	}

	v = (v0 << 4) | v1;
	return v;
	
}

bool IsSameMacAddress(u8* p1, u8* p2)
{
	int i;
	u8 v;

/*
	if ((p1[0] == getHexValue(p2))
		 && (p1[1] == getHexValue(p2 + 3))
		 && (p1[2] == getHexValue(p2 + 6))
		 && (p1[3] == getHexValue(p2 + 9))
		 && (p1[4] == getHexValue(p2 + 12))
		 && (p1[5] == getHexValue(p2 + 15)))
	{
	}
*/


	for (i =0; i < 6; i++)
	{
		if (p1[i] == getHexValue(p2 + i * 3))
		{
			return TRUE;
		}
	}
	
	return FALSE;	
}


bool Is80211ApToStaPkt(_pkt* pkt)
{
	u8* p = pkt->data;
	int len = pkt->len;
	if (len < 74)
	{
		return FALSE;
	}

	if (IsSameMacAddress(p+10, gApMacAddress) && IsSameMacAddress(p+4, gStaMacAddress))
	{
		return TRUE;
	}
	return FALSE;
}

bool Is80211StaToApPkt(_pkt* pkt)
{
	u8* p = pkt->data;
	int len = pkt->len;
	if (len < 74)
	{
		return FALSE;
	}

	if (IsSameMacAddress(p+10, gStaMacAddress) && IsSameMacAddress(p+4, gApMacAddress))
	{
		return TRUE;
	}
	return FALSE;
}


bool Is80203ApToStaPkt(_pkt* pkt)
{
	u8* p = pkt->data;
	int len = pkt->len;
	if (len < 54)
	{
		return FALSE;
	}

	if (IsSameMacAddress(p+6, gApMacAddress) && IsSameMacAddress(p, gStaMacAddress))
	{
		return TRUE;
	}
	return FALSE;
}

bool Is80203StaToApPkt(_pkt* pkt)
{
	u8* p = pkt->data;
	int len = pkt->len;
	if (len < 54)
	{
		return FALSE;
	}

	//p+10=TransmitterAddress, p+4=ReceiverAddress, 
	if (IsSameMacAddress(p+6, gStaMacAddress) && IsSameMacAddress(p, gApMacAddress))
	{
		return TRUE;
	}
	return FALSE;
}



//===============================================================================================
bool IsTcpHandshakeSynPkt(_pkt* pkt)
{
	u8* p = pkt->data;
	int len = pkt->len;

	if (len < 200)
	{
		DbgPrintTestXmitPkt(p, len);
	}
	
	if (Is80203ApToStaPkt(pkt) && p[47]==0x02)
	//if (Is80211ApToStaPkt(pkt) && p[67]==0x02)
	{
#if ZB_DBG_PRINT		
		printk("==============================================================\n");
		printk("==============================================================\n");
		printk("================IsTcpHandshakeSynPkt==========tcp syn pkt=====\n\n\n\n");
#endif
		return TRUE;
	}
	return FALSE;
}

bool IsTcpHandshakeSynAckPkt(_pkt* pkt)
{
	u8* p = pkt->data;
	int len = pkt->len;

	//================
	//DbgPrintPkt(p, len);
	
	//if (Is80211StaToApPkt(pkt) && p[67]==0x12) //
	if (Is80203StaToApPkt(pkt) && p[47]==0x12) //
	{
#if ZB_DBG_PRINT		
		printk("================IsTcpHandshakeSynAckPkt==========tcp synack pkt=====\n\n\n\n");
#endif

		return TRUE;
	}
	
	return FALSE;
}


bool IsTcpHandshakeAckPkt(_pkt* pkt)
{
	u8* p = pkt->data;
	int len = pkt->len;
	
	if (Is80203ApToStaPkt(pkt) && p[47]==0x10)
	//if (Is80211ApToStaPkt(pkt) && p[67]==0x10)
	{
#if ZB_DBG_PRINT		
		gPktCnt++;
		if (gPktCnt < NUM_PRINT_PKTS)
		{
			printk("================IsTcpHandshakeAckPkt==========tcp ack pkt=====\n\n\n\n");
			return TRUE;
		}	
#endif
		return TRUE;
	}
	
	return FALSE;
}



//
bool IsTcpDataPushAckPkt(_pkt* pkt)
{
	u8* p = pkt->data;
	int len = pkt->len;
	
	if (Is80203ApToStaPkt(pkt) && p[47]==0x18 /*&& len == 102*/)
	{
#if ZB_DBG_PRINT		
		gPktCnt++;
		if (gPktCnt < NUM_PRINT_PKTS)
		{
			printk("================IsTcpDataPushAckPkt==========data push pkt=====\n\n\n\n");
			return TRUE;
		}
#endif
		return TRUE;
	}
	
	return FALSE;
}


bool IsTcpDataAckPkt(_pkt* pkt)
{
	u8* p = pkt->data;
	int len = pkt->len;
	
	if (Is80203ApToStaPkt(pkt) && p[47]==0x10)
	{
#if ZB_DBG_PRINT
		gPktCnt++;
		if (gPktCnt < NUM_PRINT_PKTS)
		{
			//printk("================IsTcpDataPushAckPkt==========data pkt=====\n\n\n\n");
			return TRUE;
		}
#endif	
		return TRUE;
	}
	return FALSE;

}



void SaveTcpInfoAndMacSeqNumber(_adapter *padapter, _pkt* pkt, u16 macSeqNumber)
{
	int i;
	u8* p = pkt->data;
	int len = pkt->len;
	u32 ipLen;
	u32 tcpLen;
	u32 dataLen;

	TCP_FLOW_TRACE* pApTcpFlowTrace = &padapter->apTcpFlowTrace;

	//Ethernet 802.3 packet!
	u32 tcpSeqNumber = ntohl(*((u32*)(p + 38)));
	u32 timestampValue = ntohl(*((u32*)(p + 58)));
	u32 timestampEchoReply = ntohl(*((u32*)(p + 62)));

	//DbgPrintPkt(p, len);
	
	//
	//u16 macSeqNumber = GetSequence(p);
	//u16 macSeqNumber = pTcpFlowTrace->tmpMacSeq;
	//u16 macSeqNumber = pxmitframe->attrib.seqnum;

	/*
	if (pTcpFlowTrace.startMacSeqFlag == 0)
	{
		pTcpFlowTrace.startMacSeqFlag = 1;
		pTcpFlowTrace.startMacSeqNumber = macSeqNumber;
	}
	*/

	//_enter_critical_mutex(&pTcpFlowTrace->seQBufMutex, NULL);

	//
	ipLen = ntohs(*(u16*)(p + 16));
	tcpLen = (p[46] >> 4) * 4;
	dataLen = ipLen - tcpLen - 20;

#if ZB_DBG_PRINT	
	if (gPktCnt < NUM_PRINT_PKTS)
	{
		printk("=============ipLen:%u    tcpLen:%u    dataLen: %u ==================", ipLen, tcpLen, dataLen);
		printk("=============SaveTcpInfoAndMacSeqNumber=========tcpSeq:0x%.8X macSeq:%u====DataLen:%d\n\n\n\n\n", tcpSeqNumber, macSeqNumber, dataLen);
		//return;
	}
#endif

	for (i = 0; i < TCP_FLOW_TRACE_SEQ_BUF_LEN; i++)
	{
		if (pApTcpFlowTrace->busyFlag[i] == 0)
		{
			pApTcpFlowTrace->tcpSeqBuf[i] = tcpSeqNumber;
			pApTcpFlowTrace->dataLen[i] = dataLen;
			pApTcpFlowTrace->macSeqBuf[i] = macSeqNumber;

			pApTcpFlowTrace->transmitFlag[i] = MAC_TRANSMIT_UNKNOW;
			pApTcpFlowTrace->busyFlag[i] = 1;

			//
			pApTcpFlowTrace->timestampValue[i] = timestampValue;
			pApTcpFlowTrace->timestampEchoReply[i] = timestampEchoReply;
			
			break;
		}
	}
	//_exit_critical_mutex(&pTcpFlowTrace->seQBufMutex, NULL);

	

	if (i == TCP_FLOW_TRACE_SEQ_BUF_LEN)
	{
		printk("==================================================================================================\n");
		printk("====ERROR!!!!!=======SaveTcpInfoAndMacSeqNumber==========No free node in TCP_FLOW_TRACE===========\n");
		printk("==================================================================================================\n\n\n\n\n");
	}
}







void SaveTcpWndSize(_adapter *padapter, u32 wndSize)
{
	TCP_FLOW_TRACE* pApTcpFlowTrace = &padapter->apTcpFlowTrace;
	gPktCnt++;
	if (gPktCnt > NUM_PRINT_PKTS)
	{
		return;
	}
	//printk("=============SaveTcpWndSize=========wndSize:%u \n\n", wndSize);
	
	//_enter_critical_mutex(&pTcpFlowTrace->seQBufMutex, NULL);
	
	pApTcpFlowTrace->wndSize = wndSize; //wndSize should be multiplied by 128
	
	//_exit_critical_mutex(&pTcpFlowTrace->seQBufMutex, NULL);
}






	




bool ApFindTcpFlowTraceByMacSeq(_adapter *padapter, u16 macSeqNumber, u32* pIndex)
{
	TCP_FLOW_TRACE* pApTcpFlowTrace = &padapter->apTcpFlowTrace;
	int i;

	for (i = 0; i < TCP_FLOW_TRACE_SEQ_BUF_LEN; i++)
	{
		if ((pApTcpFlowTrace->busyFlag[i] == 1) && (pApTcpFlowTrace->macSeqBuf[i] == macSeqNumber) )
		{
			//pApTcpFlowTrace->busyFlag[i] = 0;
			*pIndex = i;
			return TRUE;
		}
	}
	return FALSE;
}


bool ApFindTcpFlowTraceByTcpSeq(_adapter *padapter, u32 tcpSeqNumber, u32* pIndex)
{
	TCP_FLOW_TRACE* pApTcpFlowTrace = &padapter->apTcpFlowTrace;
	int i;

	for (i = 0; i < TCP_FLOW_TRACE_SEQ_BUF_LEN; i++)
	{
		if ((pApTcpFlowTrace->busyFlag[i] == 1) && (pApTcpFlowTrace->tcpSeqBuf[i] == tcpSeqNumber) )
		{
			*pIndex = i;
			return TRUE;
		}
	}
	return FALSE;	
}






//=========================================================================================
bool ApIsBlockAckPkt(u8* p, int len)
{
	if (len == 28 && (p[0] == 0x94) && (p[1] == 0x00) && IsSameMacAddress(p + 4, gApMacAddress) && IsSameMacAddress(p+4+6, gStaMacAddress) )
	{
		//DbgPrintCtrlFrame(p, len);
		return TRUE;
	}
	return FALSE;
}


bool StaIsBlockAckPkt(u8* p, int len)
{
	if (len == 28 && (p[0] == 0x94) && (p[1] == 0x00) && IsSameMacAddress(p + 4, gStaMacAddress) && IsSameMacAddress(p+4+6, gApMacAddress) )
	{
#if ZB_DBG_PRINT		
		DbgPrintCtrlFrame(p, len);
#endif
		return TRUE;
	}
	return FALSE;
}




//Block Ack Pkt Format
//
//94 00 40 00 88 25 93 b0 64 26 88 25 93 b0 3f 0b 05 00 c0 b8 ff ff ff ff ff ff ff ff
//



int gBlockAckPrintCnt;






//=========================================================================================
/*
Ip Head Reference: 45 00 00 34 56 74 40 00 40 06 9a b7 c0 a8 64 46 c0 a8 64 01

0x34=52=20(ipHead)+32(tcpHead)



Tcp HeadReference: 13 89 df 0a 56 03 03 26 a0 59 7f 56 80 10 00 e3 b2 c3 00 00
*/

#define ETH_HEAD_LEN 14
//#define IP_HEAD_LEN  20
//#define TCP_HEAD_LEN 20



//SrcPort, Save_STA_SeqNumber(from SYNACK handshake), PktLen(TcpAckNumber), 
u8 gEthernetIpTcpBuf[66] = {
	0x88, 0x25, 0x93, 0xb0, 0x64, 0x26, 
	0x88, 0x25, 0x93, 0xb0, 0x3f, 0x0b,  
	0x08, 0x00,
	
	0x45, 0x00, 0x00, 0x34, 0xff, 0xff, 0x40, 0x00, 0x40, 0x06, 0xff, 0xff, 0xc0, 0xa8, 0x64, 0x46, 0xc0, 0xa8, 0x64, 0x01, 
	0x13, 0x89, 0xff, 0xff, 0x11, 0x22, 0x33, 0x44, 0x11, 0x22, 0x33, 0x44, 0x80, 0x10, 0x00, 0xe3, 0xff, 0xff, 0x00, 0x00, //WndSize=0x00 e5, Dynamic Set

	0x01, 0x01, 0x08, 0x0a, 0x11, 0x22, 0x33, 0x44, 0x11, 0x22, 0x33, 0x44, 
};


u16 gIpIdentificationValue = 0;
void ApGenerateTcpAckPkt(_adapter *padapter, u32 index, u32 newAckNumber)
{

}




void ApProcessFirstTransmitOkPkt(_adapter *padapter, u32 index)
{
	//
	TCP_FLOW_TRACE* pApTcpFlowTrace = &padapter->apTcpFlowTrace;
	u32 tcpSeqNumber = pApTcpFlowTrace->tcpSeqBuf[index];
	u32 dataLen = pApTcpFlowTrace->dataLen[index];
	u32 ackNumber = tcpSeqNumber + dataLen;
	u16 macSeqNumber = pApTcpFlowTrace->macSeqBuf[index];

	gTransmitOkDataPktCnt++;
	if (gTransmitOkDataPktCnt < 100)
	{
		printk("=====ApProcessFirstTransmitOkPkt====macSeqNumber: %u tcpSeqNumber:%.8X dataLen:%u\n\n\n", macSeqNumber, tcpSeqNumber, dataLen);
	}

	//
	//
	ApGenerateTcpAckPkt(padapter, index, ackNumber);

	//
	pApTcpFlowTrace->busyFlag[index] = 0;
	pApTcpFlowTrace->apTcpSeqNumber = pApTcpFlowTrace->apTcpSeqNumber + dataLen; //Move to new postion!!!
}





void ApProcessRetransmitOkPkt(_adapter *padapter, u32 index)
{

	TCP_FLOW_TRACE* pApTcpFlowTrace = &padapter->apTcpFlowTrace;
	//
	u32 staTcpSeqNumber = ntohl(*(u32*)(pApTcpFlowTrace->staTcpSeqNumber)) + 1;
	//u16 dstPort = pApTcpFlowTrace->dstPort;
	u32 tcpSeqNumber = pApTcpFlowTrace->tcpSeqBuf[index];
	u16 macSeqNumber = pApTcpFlowTrace->macSeqBuf[index];
	u32 dataLen = pApTcpFlowTrace->dataLen[index];
	u32 ackNumber = tcpSeqNumber + dataLen;

	//
	u32 tempSeqNumber;
	u32 tempIndex;
	u32 newAckNumber;


	gRetransmitOkDataPktCnt++;
	if (gRetransmitOkDataPktCnt < 100)
	{
		printk("=====ApProcessRetransmitOkPkt!!!====macSeqNumber: %u tcpSeqNumber:%.8X dataLen:%u\n\n", macSeqNumber, tcpSeqNumber, dataLen);
	}
	

	//
	pApTcpFlowTrace->busyFlag[index] = 0;

	//
	//Find right border for ACK pkt!!!
	//
	newAckNumber = ackNumber;

	do
	{
		tempSeqNumber = newAckNumber;
		if (ApFindTcpFlowTraceByTcpSeq(padapter, tempSeqNumber, &tempIndex) && (pApTcpFlowTrace->transmitFlag[tempIndex] == MAC_TRANSMIT_OK))
		{	
			pApTcpFlowTrace->busyFlag[tempIndex] = 0;
			newAckNumber = newAckNumber + pApTcpFlowTrace->dataLen[tempIndex];
		}
		else
		{
			break;
		}	
	}while(1);

	//
	ApGenerateTcpAckPkt(padapter, index, newAckNumber);

	//
	pApTcpFlowTrace->apTcpSeqNumber = newAckNumber; //Move to new postion!!!	
}



//==========================================================================================================
//=========================================== PROCESS ENTRY ================================================
//==========================================================================================================

void ApProcessDataTransmitOkPkt(_adapter *padapter, u32 index)
{
	//
	TCP_FLOW_TRACE* pApTcpFlowTrace = &padapter->apTcpFlowTrace;

	//
	u32 tcpSeqNumber = pApTcpFlowTrace->tcpSeqBuf[index];
	u16 macSeqNumber = pApTcpFlowTrace->macSeqBuf[index];
	u32 dataLen = pApTcpFlowTrace->dataLen[index];
	u32 ackNumber = tcpSeqNumber + dataLen;
	u8 transmitFlag =  pApTcpFlowTrace->transmitFlag[index];


	if (tcpSeqNumber == pApTcpFlowTrace->apTcpSeqNumber)
	{
		if (transmitFlag == MAC_TRANSMIT_UNKNOW)
		{
			ApProcessFirstTransmitOkPkt(padapter, index); //MAC first transmit OK!	
		}
		else if (transmitFlag == MAC_TRANSMIT_ERROR)
		{
			ApProcessRetransmitOkPkt(padapter, index);  //MAC retransmit OK!
		}
		else if (transmitFlag == MAC_TRANSMIT_OK)
		{
			printk("======== Error!!! Should never emerge!!!!================================\n\n\n\n");
		}	
	}
	else if (tcpSeqNumber > pApTcpFlowTrace->apTcpSeqNumber)
	{
		if (transmitFlag == MAC_TRANSMIT_UNKNOW)
		{
			//Update the state of the node!!!
			pApTcpFlowTrace->transmitFlag[index] = MAC_TRANSMIT_OK;
		}
		else if (transmitFlag == MAC_TRANSMIT_ERROR)
		{
			//Update the state of the node!!!
			pApTcpFlowTrace->transmitFlag[index] = MAC_TRANSMIT_OK;
		}
		else if (transmitFlag == MAC_TRANSMIT_OK)
		{
			
		}	
	}
}






//================================================================================================
void SaveTcpInfoToList(_adapter *padapter, _pkt* pkt, u16 macSeqNumber)
{

}




int ggTcpAckCnt;
void ApSimpleGenerateTcpAckPkt(_adapter *padapter, u32 curReadPosition)
{

}

void SimpleProcess(_adapter *padapter, u32 num)
{

}




//===========================================STA========================================================
int gStaTcpAckPktCnt = 0;


void StaPrintTcpAckPkt(u8* p, uint len)
{
	int i;
	u8 c;

	/*
	u16 seg;
	printk("\n\n==============StaPrintTcpAckPkt=====Pkt len: %u===============\n", len);
	seg = len / 20;
	for (i = 0; i < seg; i++)
	{
		printk("%.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X",
			p[NUMCHARS*i], p[NUMCHARS*i+1], p[NUMCHARS*i+2], p[NUMCHARS*i+3], p[NUMCHARS*i+4], p[NUMCHARS*i+5], p[NUMCHARS*i+6], p[NUMCHARS*i+7], p[NUMCHARS*i+8], p[NUMCHARS*i+9],
			p[NUMCHARS*i+10], p[NUMCHARS*i+11], p[NUMCHARS*i+12], p[NUMCHARS*i+13], p[NUMCHARS*i+14], p[NUMCHARS*i+15], p[NUMCHARS*i+16], p[NUMCHARS*i+17], p[NUMCHARS*i+18], p[NUMCHARS*i+19]);
	}
	*/

	for (i =0; i < len; i++)
	{
		c = p[i] & 0xFF;
		printk("%.2X ", c);
	}
	printk("\n");

}


bool ApIsTcpAckPkt(_pkt* pkt)
{
	u8* p = pkt->data;
	//ethernet+ip+tcp(--ACK--)
	//if ((pkt->len >= 54) && (p[12] == 0x08) && (p[13] == 0x00) && (p[23]==0x06) && (p[47]==0x10))
	if (Is80203StaToApPkt(pkt) && p[47]==0x10)
	{
		//printk("==============TcpAckPkt   len: %d=================\n", pkt->len);
		//DbgPrintTestXmitPkt(pkt->data, pkt->len);

		gStaTcpAckPktCnt++;
		if (gStaTcpAckPktCnt < 2)
		{
			//StaPrintTcpAckPkt(pkt->data, pkt->len);
		}

		return TRUE;
		//return FALSE;
	}

	return FALSE;
	//return TRUE;
}


bool StaIsTcpAckPkt(_pkt* pkt)
{
	u8* p = pkt->data;
	//ethernet+ip+tcp(--ACK--)
	//if ((pkt->len >= 54) && (p[12] == 0x08) && (p[13] == 0x00) && (p[23]==0x06) && (p[47]==0x10))
	if (Is80203StaToApPkt(pkt) && p[47]==0x10)
	{
		//printk("==============TcpAckPkt   len: %d=================\n", pkt->len);
		//DbgPrintTestXmitPkt(pkt->data, pkt->len);

		gStaTcpAckPktCnt++;
		if (gStaTcpAckPktCnt < 2)
		{
			//StaPrintTcpAckPkt(pkt->data, pkt->len);
		}

		return TRUE;
		//return FALSE;
	}

	return FALSE;
	//return TRUE;
}


//

u8 gmac_buf[ETH_ALEN];
u8* gMyPtr;

void PutWndSizeToStaMacAddressField(_adapter *padapter, u16 wndSize)
{

}





int gApBlockAckSystemFlag;
int gApDataPushFlag;
int gApRecvFirstBlockAck; //
void ApDoRecvBlockAck(_adapter *padapter, u8* pframe, uint len)
{

}


int gStaBlockAckSystemFlag;
void StaDoRecvBlockAck(_adapter *padapter, u8* pframe, uint len)
{
	if (gStaBlockAckSystemFlag == 0)
	{
		gStaBlockAckSystemFlag = 1;
		return;
	}
}



int gApTestFlag;



bool ApModifyTcpAckPkt(_adapter *padapter, _pkt* pkt)
{
	return TRUE;
}

//=================================================================================


void ApResetTcpInfoArray(_adapter *padapter)
{
		TCP_PKT_INFO* pApTcpPktInfo = padapter->apTcpPktInfo;
		int i;
		for (i = 0; i < TCP_PKT_INFO_ELEM_NUM; i++)
		{
			pApTcpPktInfo[i].flag = FLAG_UNUSED;
		}
		padapter->startPosition = 0;
		padapter->endPosition = 0;	
}



void SaveBitmap(u8* p, u8* bitmap)
{
	//ff ff ff ff ff ff ff ff
	int i, j;
	u8 v;
	for (i = 0; i < 8; i++)
	{
		v = p[i];
		for (j = 0; j < 8; j++)
		{
			if (v & 0x01)
			{
				bitmap[i * 8 + j] = 1;
			}
			else
			{
				bitmap[i * 8 + j] = 0;
			}
			v = v >> 1;
		}
	}	
}


int gProcessDataPktCnt;
void ApProcessOnePkt(_adapter *padapter, u32 curPos)
{
	//
	TCP_FLOW_TRACE* pApTcpFlowTrace = &padapter->apTcpFlowTrace;
	TCP_PKT_INFO* pApTcpPktInfo = padapter->apTcpPktInfo;

	//
	u32 staTcpSeqNumber = ntohl(*(u32*)(pApTcpFlowTrace->staTcpSeqNumber)) + 1;
	u32 tcpSeqNumber = pApTcpPktInfo[curPos].tcpSeqNumber;
	u32 dataLen =pApTcpPktInfo[curPos].dataLen;
	u32 ackNumber = tcpSeqNumber + dataLen;


	//
	u32 timestampValue = pApTcpPktInfo[curPos].timestampValue;
	u32 timeDelta = (u32)(jiffies - padapter->apTcpFlowTrace.jiffiesSynAckPkt);


	//
	//u32 timestampEchoReply = pApTcpPktInfo[curReadPosition].timestampEchoReply + 1;
	//u32 timestampEchoReply = pApTcpPktInfo[curReadPosition].timestampEchoReply;
	//u32 timestampEchoReply = pApTcpPktInfo[curReadPosition].timestampEchoReply;
	
	u32 timestampEchoReply = timeDelta + padapter->apTcpFlowTrace.timeStampSynAckPkt;
	//printk("==============curTime: %u   SynAckTime: %u========Delta: %u======timestampEchoReply: %u ============\n\n\n\n",  jiffies,  padapter->apTcpFlowTrace.jiffiesSynAckPkt, timeDelta, timestampEchoReply);

	
	u8* p;
	int i;

	struct sk_buff *skb;
    skb = dev_alloc_skb(2+14+20+32+4); //two bytes align + ethernet + ipHeader + tcpHeader
    if (!skb) 
	{
        printk("=========Error!!!========ApGenerateTcpAckPkt========allocate memory error!======\n\n\n");
		return;
    }

	//
    skb_reserve(skb, 2); //Two Bytes Align

	//
	gProcessDataPktCnt = gProcessDataPktCnt + 1;



	//
	//-------Modify---Ip Identification---------
	//
	gIpIdentificationValue++;
	p = (u8*)&gIpIdentificationValue;
	gEthernetIpTcpBuf[ETH_HEAD_LEN + 4] = p[1];
	gEthernetIpTcpBuf[ETH_HEAD_LEN + 5] = p[0];


	//
	//-------Modify---srcPort---------
	//
	//p = (u8*)&srcPort;
	gEthernetIpTcpBuf[ETH_HEAD_LEN + 20] = pApTcpPktInfo[curPos].srcPort[0];
	gEthernetIpTcpBuf[ETH_HEAD_LEN + 21] = pApTcpPktInfo[curPos].srcPort[1];

	

	//
	//-------Modify---dstPort---------
	//
	//p = (u8*)&dstPort;
	gEthernetIpTcpBuf[ETH_HEAD_LEN + 22] = pApTcpPktInfo[curPos].dstPort[0];
	gEthernetIpTcpBuf[ETH_HEAD_LEN + 23] = pApTcpPktInfo[curPos].dstPort[1];


	//
	//-------Modify---tcpSeqNumber---------
	//
	p = (u8*)&staTcpSeqNumber;
	gEthernetIpTcpBuf[ETH_HEAD_LEN + 24] = p[3];
	gEthernetIpTcpBuf[ETH_HEAD_LEN + 25] = p[2];
	gEthernetIpTcpBuf[ETH_HEAD_LEN + 26] = p[1];
	gEthernetIpTcpBuf[ETH_HEAD_LEN + 27] = p[0];

   //
   //-------Modify---tcpAckNumber---------
   //  
   p = (u8*)&ackNumber;
   gEthernetIpTcpBuf[ETH_HEAD_LEN + 28] = p[3];
   gEthernetIpTcpBuf[ETH_HEAD_LEN + 29] = p[2];
   gEthernetIpTcpBuf[ETH_HEAD_LEN + 30] = p[1];
   gEthernetIpTcpBuf[ETH_HEAD_LEN + 31] = p[0];


   //
   //-------Modify---WndSize---------
   //
   if (gProcessDataPktCnt % 100 == 0)
   {
   		padapter->apTcpFlowTrace.wndSize += 22; //
   }
   p = (u8*)&(padapter->apTcpFlowTrace.wndSize);
   gEthernetIpTcpBuf[ETH_HEAD_LEN + 34] = p[1];
   gEthernetIpTcpBuf[ETH_HEAD_LEN + 35] = p[0];

   
   //
   //-------Modify---timestampValue---------
   //     
   p = (u8*)&timestampEchoReply;
   gEthernetIpTcpBuf[58] = p[3];
   gEthernetIpTcpBuf[59] = p[2];
   gEthernetIpTcpBuf[60] = p[1];
   gEthernetIpTcpBuf[61] = p[0];


   //
   //-------Modify---timestampEchoReply---------
   //     
   p = (u8*)&timestampValue;
   gEthernetIpTcpBuf[62] = p[3];
   gEthernetIpTcpBuf[63] = p[2];
   gEthernetIpTcpBuf[64] = p[1];
   gEthernetIpTcpBuf[65] = p[0];

/*
   ggTcpAckCnt++;
   
   if (ggTcpAckCnt < 3)
   {
   		printk("======================Construct TCP ack pkt=====================\n");
		for (i = 0; i < 66; i++)
		{
			printk("%.2X", gEthernetIpTcpBuf[i]);
		}
		printk("\n\n\n\n");
   	
   }
*/

	//
    _rtw_memcpy(skb_put(skb, 66), gEthernetIpTcpBuf, 66);


   //
    skb->dev = padapter->pnetdev;
    skb->protocol = eth_type_trans(skb, skb->dev);
    skb->ip_summed = CHECKSUM_UNNECESSARY;

    netif_rx(skb);

	//
	
}




void ApSaveTcpInfoToArray(_adapter *padapter, _pkt* pkt, u16 macSeqNumber)
{
	int i;
	u8* p = pkt->data;
	int len = pkt->len;
	u32 ipLen;
	u32 tcpLen;
	u32 dataLen;
	u32 relativeTcpSeq;

	TCP_FLOW_TRACE* pApTcpFlowTrace = &(padapter->apTcpFlowTrace);
	TCP_PKT_INFO* pApTcpPktInfo = padapter->apTcpPktInfo;

	u32 startPosition = padapter->startPosition;
	u32 endPosition = padapter->endPosition;


	//
	//Ethernet 802.3 packet!
	//
	u32 tcpSeqNumber = ntohl(*((u32*)(p + 38)));
	u32 timestampValue = ntohl(*((u32*)(p + 58)));
	u32 timestampEchoReply = ntohl(*((u32*)(p + 62)));


	//
	relativeTcpSeq = tcpSeqNumber - pApTcpFlowTrace->apSynPktTcpSeqNumber;

	//
	ipLen = ntohs(*(u16*)(p + 16));
	tcpLen = (p[46] >> 4) * 4;
	dataLen = ipLen - tcpLen - 20;


	if (dataLen == 0)
	{
		printk("===========================================================================\n");
		printk("============= WARNING!!! NO DATA === in tcp pkt!!==========================\n");
		printk("===========================================================================\n\n\n");	
		return;
	}


	if (pApTcpPktInfo[endPosition].flag == FLAG_USED)
	{
		printk("=================================================================\n");
		printk("============= ERROR!!! No free node to save TcpInfo=======startPos: %u====endPos:%u===\n", startPosition, endPosition);
		printk("=================================================================\n\n\n");
		return;
	}

	//
	pApTcpPktInfo[endPosition].flag = FLAG_USED;
	
#if ZB2_PROCESS_PKT_PRINT
	printk("================[curPos: %u]  ---set---TRUE--\n", endPosition);
#endif
	//
	pApTcpPktInfo[endPosition].srcPort[0] = pApTcpFlowTrace->srcPort[0];
	pApTcpPktInfo[endPosition].srcPort[1] = pApTcpFlowTrace->srcPort[1];
	
	pApTcpPktInfo[endPosition].dstPort[0] = pApTcpFlowTrace->dstPort[0];
	pApTcpPktInfo[endPosition].dstPort[1] = pApTcpFlowTrace->dstPort[1];
	//
	pApTcpPktInfo[endPosition].tcpSeqNumber = tcpSeqNumber;
	pApTcpPktInfo[endPosition].dataLen = dataLen;
	pApTcpPktInfo[endPosition].ackNumber = tcpSeqNumber + dataLen;

	//
	pApTcpPktInfo[endPosition].macSeq = macSeqNumber;

	//
	pApTcpPktInfo[endPosition].timestampValue = timestampValue;
	pApTcpPktInfo[endPosition].timestampEchoReply = timestampEchoReply;

	//
	padapter->endPosition++; //
	if (padapter->endPosition == TCP_PKT_INFO_ELEM_NUM)
	{
		padapter->endPosition = 0;
	}
#if ZB2_PROCESS_PKT_PRINT
	printk("========ApSaveTcpInfoToArray====macSeqNumber: %u======ArrayCursor: [%u, %u)===relativeTcpSeq: %u===\n\n", macSeqNumber, padapter->startPosition, padapter->endPosition, relativeTcpSeq);
#endif

}



void ApProcessBlockAckPkt(_adapter *padapter, u8* pframe, uint len)
{
	TCP_PKT_INFO* pApTcpPktInfo = padapter->apTcpPktInfo;
	//
	u16 startMacSeqNumber = GetMyMacSequence(pframe);
	u16 endMacSeqNumber;
	u8 bitmap[64];
	u32 startBitmapPos;
	u32 curBitmapPos;

	//
	u32 startPosition = padapter->startPosition;
	u32 endPosition = padapter->endPosition;
	u32 borderPosition;	
	u32 lenPosition;
	u32 curPos;	


	//
	endMacSeqNumber = startMacSeqNumber + 63;
	if (endMacSeqNumber > 4095)
	{
		endMacSeqNumber =  endMacSeqNumber - 4096;
	}

	//
	SaveBitmap(pframe+20, bitmap);


#if ZB2_PROCESS_PKT_PRINT
	printk("=======================BlockAck============MacSeq [%u, %u)=========\n", startMacSeqNumber, endMacSeqNumber);
#endif


/*
	if (lenPosition >= TCP_PKT_INFO_ELEM_NUM - 1)
	{
		printk("=============================================================\n");
		printk("============= ERROR!!! TcpInfoArray is Full!=================\n");
		printk("=============================================================\n\n\n");
		return;
	}
*/
	//Find the border
	curPos = padapter->startPosition;
	while (1)
	{
		if (curPos == endPosition)
		{
			printk("=========================================================================================\n");
			printk("============= ERROR!!! Can not find the border position! Maybe earlier BlockAckFrame!==[%u, %u]===\n", startMacSeqNumber, endMacSeqNumber);
			printk("=================================================================================\n\n\n");		
			return;
		}

		if (padapter->apTcpPktInfo[curPos].flag == TRUE && padapter->apTcpPktInfo[curPos].macSeq == endMacSeqNumber)
		{
			borderPosition = curPos;
			break;
		}
		
		curPos++;
		if (curPos == TCP_PKT_INFO_ELEM_NUM)
		{
			curPos = 0;
		}	
	}


	//
	lenPosition = (startPosition <= borderPosition) ? (borderPosition - startPosition + 1) : (TCP_PKT_INFO_ELEM_NUM - startPosition + borderPosition + 1);

	//
	startBitmapPos = 64 - lenPosition;
	curBitmapPos = startBitmapPos;


	//
	while (curBitmapPos < 64)
	{
		if (bitmap[curBitmapPos] == 0)
		{
			break;
		}

		//
		curPos = startPosition + (curBitmapPos - startBitmapPos);
		if (curPos >= TCP_PKT_INFO_ELEM_NUM)
		{
			curPos = curPos - TCP_PKT_INFO_ELEM_NUM; //Switch Border!!!
		}

		//
		ApProcessOnePkt(padapter, curPos);
		pApTcpPktInfo[curPos].flag = FLAG_UNUSED;
		

		//
#if ZB2_PROCESS_PKT_PRINT		
		printk("================[curPos: %u]  ---set---FALSE--\n", curPos);
		printk("========ApProcessOnePkt=======ArrayCursor: [%u, %u)====DoCurPos: %u ======\n\n", startPosition, endPosition, curPos);
#endif

		//
		padapter->startPosition++;
		if (padapter->startPosition == TCP_PKT_INFO_ELEM_NUM)
		{
			padapter->startPosition = 0;
		}
		
		//
		curBitmapPos++;	
	}
}








