

===================================================================================================================================================
===========================================================================  ABBREVIATION   =======================================================
===================================================================================================================================================
LPS:  leisure power save
BT: Blue tooth







===================================================================================================================================================
===========================================================================  UBUNTU16.10  =========================================================
===================================================================================================================================================
ubuntu16.10 (KERNEL 4.8)
#
sudo passwd root   #123456

#
gedit /usr/share/lightdm/50-ubuntu.conf    #Add the following line, then reboot the machine!
greeter-show-manual-login=true   


#---------------------SSH---------------------------
apt install ssh 

#       
gedit /etc/ssh/sshd_config
PermitRootLogin yes
#comment out "strictMode", 
PasswordAuthentication yes

#
service ssh restart

#
rm /root/.ssh/known_hosts   #When use scp in clients, you should remove the "known_hosts" file!!!




#---------------------wine---------------------------
Software Center --> wine --> install

#
wine souceinsight.exe   #The default directory is: /root/.wine/driver_c/xxx



#---------------------SHOW ALL FILES---------------------------
file_browser-->icons-->Show Hide Files-->slect it!



#---------------------wireshark---------------------------
apt install wireshark    #



#---------------------update to a new kernel---------------------------
apt-get source linux-image-`uname -r`     ###






===================================================================================================================================================
===========================================================================  SOURCE INSIGHT 3.5  ==================================================
===================================================================================================================================================

wine


"astyle.exe" --style=ansi -f -p -P -U -v -n -N %f   #Format current File,  [ansi, allman]

"C:\Astyle.exe" C:\rtl8812AU/*.c C:\rtl8812AU/*.h --style=ansi -s4 -S -N -L -m0 -M40 --recursive --convert-tabs --suffix=.pre %f   #Format the directory


Ctrl+Shift+W   #Close All windows in source insight

Shift + F8     #highlight the words

Written Code Stye: Document Options --> Auto Indent --> Remove the slection



#-------------------------------------------------Linux的wine中的SourceInsight支持中文注释---------------------------------------------------
#
copy font file "simsun.ttc"(宋体文件) from windows_fonts directory and put it to the simulated_windows_fonts directory.

#
wine regedit zh.reg   #write a regedit file with the following content and import it to windows systemt(导入到系统中)!
[HKEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion\FontLink\SystemLink]
"Lucida Sans Unicode"="simsun.ttc"
"Microsoft Sans Serif"="simsun.ttc"
"MS Sans Serif"="simsun.ttc"
"Tahoma"="simsun.ttc"
"Tahoma Bold"="simsun.ttc"
"SimSun"="simsun.ttc"
"Arial"="simsun.ttc"
"Arial Black"="simsun.ttc"


#
gedit xxx.c    #在文件中添加注释后，另存为GBK格式，然后在SourceInsight中打开


http://blog.sina.com.cn/s/blog_628bebe4010137il.html   #可以一次删除一个中文字符







===================================================================================================================================================
===========================================================================  WLAN0  ===============================================================
===================================================================================================================================================
service systemd-udevd stop      ##### wlx00000000 -> wlan0
service systemd-udevd status
service NetworkManager stop
service systemd-resolved stop



--------------------------------------------
gedit /etc/init.d/hostapd
DAEMON_CONF=/root/.wine/drive_c/rtl8812AU/hostapd.conf      ###zb Modify



--------------------------------------------
gedit /etc/init.d/dnsmasq
USER_CONFIG_FILE=/root/.wine/drive_c/rtl8812AU/dnsmasq.conf
........
........
..........
exec $DAEMON -x /run/dnsmasq/$NAME.pid -C $USER_CONFIG_FILE \   ####### zb Add
	    ${MAILHOSTNAME:+ -m $MAILHOSTNAME} \
	    ${MAILTARGET:+ -t $MAILTARGET} \
	    ${DNSMASQ_USER:+ -u $DNSMASQ_USER} \
	    ${DNSMASQ_INTERFACES:+ $DNSMASQ_INTERFACES} \
	    ${DHCP_LEASE:+ -l $DHCP_LEASE} \
	    ${DOMAIN_SUFFIX:+ -s $DOMAIN_SUFFIX} \
	    ${RESOLV_CONF:+ -r $RESOLV_CONF} \
	    ${CACHESIZE:+ -c $CACHESIZE} \
	    ${CONFIG_DIR:+ -7 $CONFIG_DIR} \
	    ${DNSMASQ_OPTS:+ $DNSMASQ_OPTS} 



===================================================================================================================================================
===========================================================================  INIT ANALYSIS  =======================================================
===================================================================================================================================================

//zbDebug: 

tasklet_init



//---------------INIT XMIT-------------
rtw_dev_probe
-->
rtw_usb_if1_init
-->
rtw_init_drv_sw
-->
_rtw_init_xmit_priv    ######
-->
rtw_hal_init_xmit_priv
-->
padapter->HalFunc.init_xmit_priv(padapter);
-->
rtl8812au_init_xmit_priv
-->
tasklet_init(&pxmitpriv->xmit_tasklet, (void(*)(unsigned long))rtl8812au_xmit_tasklet, (unsigned long)padapter);






//---------------INIT RECV-------------
rtw_dev_probe
-->
rtw_usb_if1_init
-->
rtw_init_drv_sw
-->
_rtw_init_recv_priv     ######
-->
rtw_hal_init_recv_priv
-->
padapter->HalFunc.init_recv_priv(padapter);
-->
rtl8812au_init_recv_priv 
-->
usb_init_recv_priv 
--> 
tasklet_init(&precvpriv->recv_tasklet, (void(*)(unsigned long))usb_recv_tasklet, (unsigned long)padapter);

netdev_open --> _netdev_open --> intf_start --> usb_intf_start --> rtw_hal_inirp_init --> rtl8812au_inirp_init   #####   _read_port:  call <<usb_read_port>> initially!!!






===================================================================================================================================================
===========================================================================  XMIT ANALYSIS  =======================================================
===================================================================================================================================================
.ndo_start_xmit = rtw_xmit_entry
-->
rtw_xmit_entry
-->
_rtw_xmit_entry
-->
rtw_xmit
-->
rtw_hal_xmit
-->
rtw_dump_xframe    #####
-->
_rtw_write_port
-->
pintfhdl->io_ops._write_port;
-->
pops->_write_port = &usb_write_port;
-->
usb_write_port
-->
usb_fill_bulk_urb(..., usb_write_port_complete, )   #####
-->
usb_write_port_complete
-->
tasklet_hi_schedule(&pxmitpriv->xmit_tasklet);
-->
rtl8812au_xmit_tasklet


rtl8812au_xmitframe_complete ---> ( rtw_dequeue_xframe )  #search "zb1" 


rtw_make_wlanhdr: txseq_tid[]




===================================================================================================================================================
===========================================================================  RECV ANALYSIS  =======================================================
===================================================================================================================================================
usb_read_port            ### <<usb_read_port_complete>> is called when there are some packets. We must call usb_submit_urb even if there is no packet!
-->
usb_read_port_complete             ####
-->
tasklet_schedule(&precvpriv->recv_tasklet);
-->
usb_recv_tasklet
-->
rtw_read_port
-->
_rtw_read_port
-->
_read_port = pintfhdl->io_ops._read_port;
_read_port(pintfhdl, addr, cnt, pmem);

Note:
PktArriveToUSB-->Interrupt-->KernelCallOur_<<usb_read_port_complete>>  --> ScheduleANewTask -->InformKernelDoTheNextReceiveAction

Queue1:  Operated by Kernel!
Queue2:  Operated by our driver!



//-------------tcp timeStampValue------------
tcp_time_stamp


===================================================================================================================================================
===========================================================================  BLOCK ACK MECHANISM ==================================================
===================================================================================================================================================
SYN:  whenever receives SYN, send our BlockACKNumber and continues to send SYN+ACK
SYN+ACK: whenever receives SYN+ACK, send our BlockAckNumber and continues to send ACK(Note: this can be considered a data packet in BlockAckMechanism)
ACK: send
send
send
send
send
send
send
BlockAckNumber: OriginalBlockAckNumber+7



hw_var_set_monitor:
rcr_bits = RCR_AAP | RCR_APM | RCR_AM | RCR_AB | RCR_APWRMGT | RCR_ADF | RCR_ACF | RCR_AMF | RCR_APP_PHYST_RXFF;

_InitWMACSetting_8812A:
pHalData->ReceiveConfig = RCR_APM | RCR_AM | RCR_AB |RCR_CBSSID_DATA| RCR_CBSSID_BCN| RCR_APP_ICV | RCR_AMF| RCR_ACF | RCR_ADF | RCR_HTC_LOC_CTRL | RCR_APP_MIC | RCR_APP_PHYST_RXFF;


//
REG_BAR_MODE_CTRL
REG_TX_RPT_CTRL
REG_TX_PTCL_CTRL


//
issue_addba_req
issue_addba_rsp
issue_del_ba
issue_del_ba_ex
send_delba


//
rtw_make_wlanhdr
BA_starting_seqctrl

//
struct  wlan_network
{
    _list   list;
    int network_type;   //refer to ieee80211.h for WIRELESS_11A/B/G
    int fixed;          // set to fixed when not to be removed as site-surveying
    unsigned long   last_scanned; //timestamp for the network
    int aid;            //will only be valid when a BSS is joinned.
    int join_res;
    WLAN_BSSID_EX   network; //must be the last item
    WLAN_BCN_INFO   BcnInfo;
};

rtw_init_listhead(&(pnetwork->list));
rtw_list_insert_tail(&pnetwork->list);
rtw_list_delete(&pnetwork->list);


//===================
INIT_LIST_HEAD
list_add_tail
list_del


===================================================================================================================================================
===========================================================================  LOAD BALANCE (2 APs)   ===============================================
===================================================================================================================================================

insmod 8812au.ko

hostapd /root/.wine/drive_c/rtl8812AU/hostapd.conf
hostapd /root/.wine/drive_c/rtl8812AU/hostapd2.conf

ifconfig wlx882593b06426 192.168.100.1
ifconfig wlx30b49e59cbb3 192.168.200.1

service dnsmasq restart
------------------------Mobiphone connect 2 APs, test OK!----------------------








===================================================================================================================================================
===========================================================================  SOLUTION   ===========================================================
===================================================================================================================================================
STA: Put Window Size in Block ACK packet, So that AP can construct new ACK packets and send them to the video server!
 


#---------------------------new KERNEL----------------------------
###compile linux-4.10.4.tar.xz kernel!####
apt-get install ncurses-dev
apt-get install libssl-dev         #If needed!


make menuconfig   		###generate .config file
make -j4
make modules_install
make install


####Not enought space in /boot disk!

dpkg --get-selections|grep linux-image
apt-get purge  linux-image-4.9.0-040900-generic  #xxxx


#---------------------------remove checksum----------------------------
Need to modify 6 items: search "csum_error"
ip_rcv
tcp_v4_rcv
...




===================================================================================================================================================
===========================================================================  DEBUG   ==============================================================
===================================================================================================================================================

#define IDEA_CONDITION 1    // check all packets before enqueue


CONFIG_TCP_CSUM_OFFLOAD_TX
CONFIG_USE_USB_BUFFER_ALLOC_TX
CONFIG_FCS_MODE

CONFIG_DM_RESP_TXAGC






============ WIRELESS_EXT > 20 ====================


#if WIRELESS_EXT <= 17
	DBG_871X_LEVEL(_drv_always_, "======== WIRELESS_EXT <= 17 ============\n");
#elif WIRELESS_EXT <= 20
	DBG_871X_LEVEL(_drv_always_, "======== WIRELESS_EXT <= 20 ============\n");
#else
	DBG_871X_LEVEL(_drv_always_, "======== WIRELESS_EXT > 20 ============\n");
#endif

==================================================



===============================NIC name===========================
rtw_os_ndevs_register
-->
rtw_init_netdev_name


rtw_rereg_nd_name

//dev_alloc_name && register_netdev

dev->name
rtw_wx_get_name
wrqu->name


rtw_usb_if1_init
-->
loadparam
-->


rtw_ndev_notifier_call

_rtw_ioctl_wext_private         


_netdev_if2_open     ##!!!!!


rtw_indicate_wx_assoc_event




DBG_871X_LEVEL(_drv_always_, "zbzb============rtw_os_ndevs_register===========1.0====\n");
DBG_871X_LEVEL(_drv_always_, "module exit success\n");


rtw_ndev_notifier_call     #!!!!!!!!!!!!  NETDEV_CHANGENAME


	_nic_hdl pnetdev;
	char old_ifname[IFNAMSIZ];

	// used by rtw_rereg_nd_name related function
	struct rereg_nd_name_data {
		_nic_hdl old_pnetdev;
		char old_ifname[IFNAMSIZ];
		u8 old_ips_mode;
		u8 old_bRegUseLed;
	} rereg_nd_name_priv;


u8 ifname[16];
u8 if2name[16];








