
#!/bin/sh
#Created by Zhangbo


print_help()
{
	echo "Usage: $0 mode"
	echo "Parameter: mode = [ap sta]"
	echo "Example: $0 ap"
	echo "Example: $0 sta"
	echo ""
}


write_dnsmasq_conf()
{
	echo ""
	#interface=wlx882593b06426                                   
	#dhcp-range=192.168.100.2,192.168.100.250,48h
	#dhcp-lease-max=150
	#dhcp-leasefile=/var/lib/dnsmasq/dnsmasq.leases
	#dhcp-option=3,192.168.100.1
	#dhcp-option=option:router,192.168.100.1
	#dhcp-option=option:netmask,255.255.255.0
}


launch_ap()
{
	rmmod 8812au

	modprobe cfg80211
	insmod 8812au.ko

	sleep 0.2
	rfkill unblock wlan
	nmcli radio wifi on
	service systemd-resolved stop
	service NetworkManager stop

	sleep 0.3
	echo "Waiting to restart hostapd..."
	#hostapd /etc/hostapd/hostapd.conf
	service hostapd restart


	sleep 0.5
	ifconfig wlx882593b06426 192.168.100.1  #A
	#ifconfig wlx30b49e59cbb3 192.168.100.1  #C

	#ifconfig wlan0 192.168.100.1

	service dnsmasq restart
	



	echo "AP launched!"
	echo "If Wireless NIC client cannot connect to this AP, you can check route and firewall!"
	echo "Example: ifconfig wlx882593b06426 192.168.100.1"
	echo "Example: route add -net 192.168.100.0 netmask 255.255.255.0 gw 192.168.100.1 dev wlx882593b06426"
	echo "Example: service iptables stop"
	echo "......"
	echo "If Wireless NIC client cannot get IP address, you can check /etc/dnsmasq.conf related content in this script!"
	echo "write_dnsmasq_conf function gives the example!"
	echo "Example: service dnsmasq status"
	echo "......"	
	echo "......"
	echo "......"
	echo "."
	echo "service hostapd restart"
	echo "."
	echo "ping 192.168.100.112"
	echo "."
}


launch_sta()
{
	rmmod 8812au

	service systemd-resolved start
	service NetworkManager start



	sleep 0.2

	modprobe cfg80211
	insmod 8812au.ko

	sleep 0.2

	rfkill unblock wlan
	nmcli radio wifi on

	echo "Now you can connect to an AP with GUI on Ubuntu16.10 (Enable/Disable WiFi)"
}





#-----------------------------------------------------
if [ $# != 1 ] ; then
	print_help;
	exit 1;
fi


if [ $1 = "ap" ] || [ $1 = "sta" ]; then
	echo "ok" > /dev/null
else
	print_help;
	exit 1;
fi

#-----------------------------------------------------
if [ $1 = "ap" ]; then
	launch_ap;
elif [ $1 = "sta" ]; then
	launch_sta;
else
	echo "Error: unknown mode!"
	exit 1;
fi








































