

#define _HCI_OPS_OS_C_


#include <rtl8812a_hal.h>
#include <zb.h>


#ifdef CONFIG_SUPPORT_USB_INT
void interrupt_handler_8812au(_adapter *padapter,u16 pkt_len,u8 *pbuf)
{
    HAL_DATA_TYPE   *pHalData=GET_HAL_DATA(padapter);
    struct reportpwrstate_parm pwr_rpt;

    if ( pkt_len != INTERRUPT_MSG_FORMAT_LEN )
    {
        DBG_8192C("%s Invalid interrupt content length (%d)!\n", __FUNCTION__, pkt_len);
        return ;
    }

    // HISR
    _rtw_memcpy(&(pHalData->IntArray[0]), &(pbuf[USB_INTR_CONTENT_HISR_OFFSET]), 4);
    _rtw_memcpy(&(pHalData->IntArray[1]), &(pbuf[USB_INTR_CONTENT_HISRE_OFFSET]), 4);


#ifdef CONFIG_INTERRUPT_BASED_TXBCN

#ifdef  CONFIG_INTERRUPT_BASED_TXBCN_EARLY_INT
    if (pHalData->IntArray[0] & IMR_BCNDMAINT0_88E)
#endif
#ifdef  CONFIG_INTERRUPT_BASED_TXBCN_BCN_OK_ERR
        if (pHalData->IntArray[0] & (IMR_TBDER_88E|IMR_TBDOK_88E))
#endif
        {
            struct mlme_priv *pmlmepriv = &padapter->mlmepriv;
#if 0
            if(pHalData->IntArray[0] & IMR_BCNDMAINT0_88E)
                DBG_8192C("%s: HISR_BCNERLY_INT\n", __func__);
            if(pHalData->IntArray[0] & IMR_TBDOK_88E)
                DBG_8192C("%s: HISR_TXBCNOK\n", __func__);
            if(pHalData->IntArray[0] & IMR_TBDER_88E)
                DBG_8192C("%s: HISR_TXBCNERR\n", __func__);
#endif


            if(check_fwstate(pmlmepriv, WIFI_AP_STATE))
            {
                //send_beacon(padapter);
                if(pmlmepriv->update_bcn == _TRUE)
                {
                    //tx_beacon_hdl(padapter, NULL);
                    set_tx_beacon_cmd(padapter);
                }
            }

        }
#endif //CONFIG_INTERRUPT_BASED_TXBCN


    // C2H Event
    if(pbuf[0]!= 0)
    {
        _rtw_memcpy(&(pHalData->C2hArray[0]), &(pbuf[USB_INTR_CONTENT_C2H_OFFSET]), 16);
        //rtw_c2h_wk_cmd(padapter); to do..
    }

}
#endif //CONFIG_SUPPORT_USB_INT




static s32 pre_recv_entry(union recv_frame *precvframe, u8 *pphy_status)
{
    s32 ret=_SUCCESS;
    return ret;
}








int recvbuf2recvframe(PADAPTER padapter, void *ptr)
{
    u8  *pbuf;
    u8  pkt_cnt = 0;
    u32 pkt_offset;
    s32 transfer_len;
    u8              *pphy_status = NULL;
    union recv_frame    *precvframe = NULL;
    struct rx_pkt_attrib    *pattrib = NULL;
    HAL_DATA_TYPE   *pHalData = GET_HAL_DATA(padapter);
    struct recv_priv    *precvpriv = &padapter->recvpriv;
    _queue          *pfree_recv_queue = &precvpriv->free_recv_queue;
    _pkt *pskb;


    pskb = (_pkt*)ptr;
    transfer_len = (s32)pskb->len;
    pbuf = pskb->data;



#ifdef CONFIG_USB_RX_AGGREGATION
    pkt_cnt = GET_RX_STATUS_DESC_USB_AGG_PKTNUM_8812(pbuf);
#endif

    do
    {
        precvframe = rtw_alloc_recvframe(pfree_recv_queue);
        if(precvframe==NULL)
        {
            RT_TRACE(_module_rtl871x_recv_c_,_drv_err_,("recvbuf2recvframe: precvframe==NULL\n"));
            DBG_8192C("%s()-%d: rtw_alloc_recvframe() failed! RX Drop!\n", __FUNCTION__, __LINE__);
            goto _exit_recvbuf2recvframe;
        }

        _rtw_init_listhead(&precvframe->u.hdr.list);
        precvframe->u.hdr.precvbuf = NULL;  //can't access the precvbuf for new arch.
        precvframe->u.hdr.len=0;

        rtl8812_query_rx_desc_status(precvframe, pbuf);

        pattrib = &precvframe->u.hdr.attrib;

        if ((padapter->registrypriv.mp_mode == 0) && ((pattrib->crc_err) || (pattrib->icv_err)))
        {
            DBG_8192C("%s: RX Warning! crc_err=%d icv_err=%d, skip!\n", __FUNCTION__, pattrib->crc_err, pattrib->icv_err);

            rtw_free_recvframe(precvframe, pfree_recv_queue);
            goto _exit_recvbuf2recvframe;
        }

        pkt_offset = RXDESC_SIZE + pattrib->drvinfo_sz + pattrib->shift_sz + pattrib->pkt_len;

        if((pattrib->pkt_len<=0) || (pkt_offset>transfer_len))
        {
            RT_TRACE(_module_rtl871x_recv_c_,_drv_info_,("recvbuf2recvframe: pkt_len<=0\n"));
            DBG_8192C("%s()-%d: RX Warning!,pkt_len<=0 or pkt_offset> transfer_len \n", __FUNCTION__, __LINE__);
            rtw_free_recvframe(precvframe, pfree_recv_queue);
            goto _exit_recvbuf2recvframe;
        }

#ifdef CONFIG_RX_PACKET_APPEND_FCS
        if(pattrib->pkt_rpt_type == NORMAL_RX)
            pattrib->pkt_len -= IEEE80211_FCS_LEN;
#endif
        if(rtw_os_alloc_recvframe(padapter, precvframe, (pbuf + pattrib->shift_sz + pattrib->drvinfo_sz + RXDESC_SIZE), pskb) == _FAIL)
        {
            rtw_free_recvframe(precvframe, pfree_recv_queue);

            goto _exit_recvbuf2recvframe;
        }

        recvframe_put(precvframe, pattrib->pkt_len);
        //recvframe_pull(precvframe, drvinfo_sz + RXDESC_SIZE);

        if(pattrib->pkt_rpt_type == NORMAL_RX)//Normal rx packet
        {
            if(pattrib->physt)
                pphy_status = (pbuf + RXDESC_OFFSET);

            if(pattrib->physt && pphy_status)
                rx_query_phy_status(precvframe, pphy_status);

            if(rtw_recv_entry(precvframe) != _SUCCESS)
            {
                RT_TRACE(_module_rtl871x_recv_c_,_drv_err_, ("recvbuf2recvframe: rtw_recv_entry(precvframe) != _SUCCESS\n"));
            }

        }
        else  // pkt_rpt_type == TX_REPORT1-CCX, TX_REPORT2-TX RTP,HIS_REPORT-USB HISR RTP
        {
			if (pattrib->pkt_len < 100)
			{
					//DbgPrintC2H_Frame(precvframe->u.hdr.rx_data, pattrib->pkt_len);
			}
			
            if (pattrib->pkt_rpt_type == C2H_PACKET)
            {
                //DBG_8192C("rx C2H_PACKET \n");
                
				
				
                C2HPacketHandler_8812(padapter,precvframe->u.hdr.rx_data,pattrib->pkt_len);
            }
            rtw_free_recvframe(precvframe, pfree_recv_queue);
        }

#ifdef CONFIG_USB_RX_AGGREGATION
        // jaguar 8-byte alignment
        pkt_offset = (u16)_RND8(pkt_offset);
        pkt_cnt--;
        pbuf += pkt_offset;
#endif
        transfer_len -= pkt_offset;
        precvframe = NULL;

    }
    while(transfer_len>0);

_exit_recvbuf2recvframe:

    return _SUCCESS;
}




void rtl8812au_xmit_tasklet(void *priv)
{
    int ret = _FALSE;
    _adapter *padapter = (_adapter*)priv;
    struct xmit_priv *pxmitpriv = &padapter->xmitpriv;

    while(1)
    {
        if (RTW_CANNOT_TX(padapter))
        {
            DBG_8192C("xmit_tasklet => bDriverStopped or bSurpriseRemoved or bWritePortCancel\n");
            break;
        }

        if (rtw_xmit_ac_blocked(padapter) == _TRUE)
            break;

        ret = rtl8812au_xmitframe_complete(padapter, pxmitpriv, NULL);

        if(ret==_FALSE)
            break;

    }

}




void rtl8812au_set_intf_ops(struct _io_ops  *pops)
{
    _func_enter_;

    _rtw_memset((u8 *)pops, 0, sizeof(struct _io_ops));

    pops->_read8 = &usb_read8;
    pops->_read16 = &usb_read16;
    pops->_read32 = &usb_read32;
    pops->_read_mem = &usb_read_mem;
    pops->_read_port = &usb_read_port;

    pops->_write8 = &usb_write8;
    pops->_write16 = &usb_write16;
    pops->_write32 = &usb_write32;
    pops->_writeN = &usb_writeN;

    pops->_write_mem = &usb_write_mem;
    pops->_write_port = &usb_write_port;

    pops->_read_port_cancel = &usb_read_port_cancel;
    pops->_write_port_cancel = &usb_write_port_cancel;

    _func_exit_;

}



void rtl8812au_set_hw_type(struct dvobj_priv *pdvobj)
{
    if (pdvobj->chip_type == RTL8812)
    {
        pdvobj->HardwareType = HARDWARE_TYPE_RTL8812AU;
        DBG_871X("CHIP TYPE: RTL8812\n");
    }
    else if (pdvobj->chip_type == RTL8821)
    {
        /*pdvobj->HardwareType = HARDWARE_TYPE_RTL8811AU;   */
        pdvobj->HardwareType = HARDWARE_TYPE_RTL8821U;
        DBG_871X("CHIP TYPE: RTL8811AU or RTL8821U\n");
    }
}




