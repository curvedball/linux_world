


#define _RTL8812AU_RECV_C_


#include <rtl8812a_hal.h>



int rtl8812au_init_recv_priv(_adapter *padapter)
{
    return usb_init_recv_priv(padapter, INTERRUPT_MSG_FORMAT_LEN);
}



void rtl8812au_free_recv_priv(_adapter *padapter)
{
    usb_free_recv_priv(padapter, INTERRUPT_MSG_FORMAT_LEN);
}



