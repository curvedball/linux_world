


#include "phydm_precomp.h"




VOID
ODM_C2HRaParaReportHandler(
    IN  PVOID   pDM_VOID,
    IN pu1Byte   CmdBuf,
    IN u1Byte   CmdLen
)
{
}

VOID
odm_RA_debug(
    IN      PVOID       pDM_VOID,
    IN      u4Byte      *const dm_value
)
{
}

VOID
odm_RA_ParaAdjust_init(
    IN      PVOID       pDM_VOID
)

{
}




VOID
phydm_ra_dynamic_retry_count(
    IN  PVOID   pDM_VOID
)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
    pRA_T               pRA_Table = &pDM_Odm->DM_RA_Table;
    PSTA_INFO_T     pEntry;
    u1Byte  i, retry_offset;
    u4Byte  ma_rx_tp;
    /*ODM_RT_TRACE(pDM_Odm, ODM_COMP_RATE_ADAPTIVE, ODM_DBG_LOUD, ("pDM_Odm->pre_b_noisy = %d\n", pDM_Odm->pre_b_noisy ));*/
    if (pDM_Odm->pre_b_noisy != pDM_Odm->NoisyDecision)
    {

        if (pDM_Odm->NoisyDecision)
        {
            ODM_RT_TRACE(pDM_Odm, ODM_COMP_RATE_ADAPTIVE, ODM_DBG_LOUD, ("->Noisy Env. RA fallback value\n"));
            ODM_SetMACReg(pDM_Odm, 0x430, bMaskDWord, 0x0);
            ODM_SetMACReg(pDM_Odm, 0x434, bMaskDWord, 0x04030201);
        }
        else
        {
            ODM_RT_TRACE(pDM_Odm, ODM_COMP_RATE_ADAPTIVE, ODM_DBG_LOUD, ("->Clean Env. RA fallback value\n"));
            ODM_SetMACReg(pDM_Odm, 0x430, bMaskDWord, 0x02010000);
            ODM_SetMACReg(pDM_Odm, 0x434, bMaskDWord, 0x06050403);
        }
        pDM_Odm->pre_b_noisy = pDM_Odm->NoisyDecision;
    }
}




VOID
phydm_ra_dynamic_retry_limit(
    IN  PVOID   pDM_VOID
)
{
}





VOID
phydm_c2h_ra_report_handler(
    IN PVOID    pDM_VOID,
    IN pu1Byte   CmdBuf,
    IN u1Byte   CmdLen
)
{
    PDM_ODM_T   pDM_Odm = (PDM_ODM_T)pDM_VOID;
    pRA_T       pRA_Table = &pDM_Odm->DM_RA_Table;
    u1Byte  legacy_table[12] = {1,2,5,11,6,9,12,18,24,36,48,54};
    u1Byte  macid = CmdBuf[1];

    u1Byte  rate = CmdBuf[0];
    u1Byte  rate_idx = rate & 0x7f; /*remove bit7 SGI*/
    u1Byte  vht_en=(rate_idx >= ODM_RATEVHTSS1MCS0)? 1 :0;
    u1Byte  b_sgi = (rate & 0x80)>>7;

    u1Byte  pre_rate = pRA_Table->link_tx_rate[macid];
    u1Byte  pre_rate_idx = pre_rate & 0x7f; /*remove bit7 SGI*/
    u1Byte  pre_vht_en=(pre_rate_idx >= ODM_RATEVHTSS1MCS0)? 1 :0;
    u1Byte  pre_b_sgi = (pre_rate & 0x80)>>7;



    ODM_UpdateInitRate(pDM_Odm, rate_idx);


    /*ODM_RT_TRACE(pDM_Odm, ODM_COMP_RATE_ADAPTIVE, ODM_DBG_LOUD,("RA: rate_idx=0x%x , sgi = %d\n", rate_idx, b_sgi));*/
    /*if (pDM_Odm->SupportICType & (ODM_RTL8703B))*/
    {
        if (CmdLen >= 4)
        {
            if (CmdBuf[3] == 0)
            {
                ODM_RT_TRACE(pDM_Odm, ODM_FW_DEBUG_TRACE, ODM_DBG_LOUD, ("Init-Rate Update\n"));
                /**/
            }
            else if (CmdBuf[3] == 0xff)
            {
                ODM_RT_TRACE(pDM_Odm, ODM_FW_DEBUG_TRACE, ODM_DBG_LOUD, ("FW Level: Fix rate\n"));
                /**/
            }
            else if (CmdBuf[3] == 1)
            {
                ODM_RT_TRACE(pDM_Odm, ODM_FW_DEBUG_TRACE, ODM_DBG_LOUD, ("Try Success\n"));
                /**/
            }
            else if (CmdBuf[3] == 2)
            {
                ODM_RT_TRACE(pDM_Odm, ODM_FW_DEBUG_TRACE, ODM_DBG_LOUD, ("Try Fail & Try Again\n"));
                /**/
            }
            else if (CmdBuf[3] == 3)
            {
                ODM_RT_TRACE(pDM_Odm, ODM_FW_DEBUG_TRACE, ODM_DBG_LOUD, ("Rate Back\n"));
                /**/
            }
            else if (CmdBuf[3] == 4)
            {
                ODM_RT_TRACE(pDM_Odm, ODM_FW_DEBUG_TRACE, ODM_DBG_LOUD, ("start rate by RSSI\n"));
                /**/
            }
            else if (CmdBuf[3] == 5)
            {
                ODM_RT_TRACE(pDM_Odm, ODM_FW_DEBUG_TRACE, ODM_DBG_LOUD, ("Try rate\n"));
                /**/
            }
        }
    }

    ODM_RT_TRACE(pDM_Odm, ODM_COMP_RATE_ADAPTIVE, ODM_DBG_LOUD, ("Tx Rate Update, MACID[%d] ( %s%s%s%s%d%s%s ) -> ( %s%s%s%s%d%s%s)\n",
                 macid,
                 ((pre_rate_idx >= ODM_RATEVHTSS1MCS0) && (pre_rate_idx <= ODM_RATEVHTSS1MCS9)) ? "VHT 1ss  " : "",
                 ((pre_rate_idx >= ODM_RATEVHTSS2MCS0) && (pre_rate_idx <= ODM_RATEVHTSS2MCS9)) ? "VHT 2ss " : "",
                 ((pre_rate_idx >= ODM_RATEVHTSS3MCS0) && (pre_rate_idx <= ODM_RATEVHTSS3MCS9)) ? "VHT 3ss " : "",
                 (pre_rate_idx >= ODM_RATEMCS0) ? "MCS " : "",
                 (pre_vht_en) ? ((pre_rate_idx - ODM_RATEVHTSS1MCS0)%10) : ((pre_rate_idx >= ODM_RATEMCS0)? (pre_rate_idx - ODM_RATEMCS0) : ((pre_rate_idx <= ODM_RATE54M)?legacy_table[pre_rate_idx]:0)),
                 (pre_b_sgi) ? "-S" : "  ",
                 (pre_rate_idx >= ODM_RATEMCS0) ? "" : "M",
                 ((rate_idx >= ODM_RATEVHTSS1MCS0) && (rate_idx <= ODM_RATEVHTSS1MCS9)) ? "VHT 1ss  " : "",
                 ((rate_idx >= ODM_RATEVHTSS2MCS0) && (rate_idx <= ODM_RATEVHTSS2MCS9)) ? "VHT 2ss " : "",
                 ((rate_idx >= ODM_RATEVHTSS3MCS0) && (rate_idx <= ODM_RATEVHTSS3MCS9)) ? "VHT 3ss " : "",
                 (rate_idx >= ODM_RATEMCS0) ? "MCS " : "",
                 (vht_en) ? ((rate_idx - ODM_RATEVHTSS1MCS0)%10) : ((rate_idx >= ODM_RATEMCS0)? (rate_idx - ODM_RATEMCS0) : ((rate_idx <= ODM_RATE54M)?legacy_table[rate_idx]:0)),
                 (b_sgi) ? "-S" : "  ",
                 (rate_idx >= ODM_RATEMCS0) ? "" : "M" ));

    pRA_Table->link_tx_rate[macid] = rate;




}




VOID
odm_RSSIMonitorInit(
    IN      PVOID       pDM_VOID
)
{

    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
    pRA_T       pRA_Table = &pDM_Odm->DM_RA_Table;
    pRA_Table->firstconnect = FALSE;
}



VOID
ODM_RAPostActionOnAssoc(
    IN  PVOID   pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = (PDM_ODM_T)pDM_VOID;

    pDM_Odm->H2C_RARpt_connect = 1;
    odm_RSSIMonitorCheck(pDM_Odm);
    pDM_Odm->H2C_RARpt_connect = 0;
}




VOID
odm_RSSIMonitorCheck(
    IN      PVOID       pDM_VOID
)
{
    //
    // For AP/ADSL use prtl8192cd_priv
    // For CE/NIC use PADAPTER
    //
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
    if (!(pDM_Odm->SupportAbility & ODM_BB_RSSI_MONITOR))
        return;

    //
    // 2011/09/29 MH In HW integration first stage, we provide 4 different handle to operate
    // at the same time. In the stage2/3, we need to prive universal interface and merge all
    // HW dynamic mechanism.
    //
    switch  (pDM_Odm->SupportPlatform)
    {
        case    ODM_WIN:
            odm_RSSIMonitorCheckMP(pDM_Odm);
            break;

        case    ODM_CE:
            odm_RSSIMonitorCheckCE(pDM_Odm);
            break;

        case    ODM_AP:
            odm_RSSIMonitorCheckAP(pDM_Odm);
            break;

        case    ODM_ADSL:
            //odm_DIGAP(pDM_Odm);
            break;
    }

}   // odm_RSSIMonitorCheck





VOID
odm_RSSIMonitorCheckMP(
    IN  PVOID   pDM_VOID
)
{

}





VOID
odm_RSSIMonitorCheckCE(
    IN      PVOID       pDM_VOID
)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
    PADAPTER    Adapter = pDM_Odm->Adapter;
    HAL_DATA_TYPE   *pHalData = GET_HAL_DATA(Adapter);
    struct dvobj_priv   *pdvobjpriv = adapter_to_dvobj(Adapter);
    int i;
    int tmpEntryMaxPWDB = 0, tmpEntryMinPWDB = 0xff;
    u8  sta_cnt = 0;
    u32 UL_DL_STATE = 0, STBC_TX = 0, TxBF_EN = 0,NoiseState = 0;
    u32 PWDB_rssi[NUM_STA] = {0}; //[0~15]:MACID, [16~31]:PWDB_rssi
    BOOLEAN         FirstConnect = FALSE;
    pRA_T           pRA_Table = &pDM_Odm->DM_RA_Table;

    if (pDM_Odm->bLinked != _TRUE)
        return;


    if ((pDM_Odm->SupportICType == ODM_RTL8812) || (pDM_Odm->SupportICType == ODM_RTL8821))
    {
        u64 curTxOkCnt = pdvobjpriv->traffic_stat.cur_tx_bytes;
        u64 curRxOkCnt = pdvobjpriv->traffic_stat.cur_rx_bytes;

        if (curRxOkCnt > (curTxOkCnt * 6))
            UL_DL_STATE = 1;
        else
            UL_DL_STATE = 0;
    }

    FirstConnect = (pDM_Odm->bLinked) && (pRA_Table->firstconnect == FALSE);
    pRA_Table->firstconnect = pDM_Odm->bLinked;

    if ( pDM_Odm->NoisyDecision )
    {
        NoiseState = 1;             /* BIT2*/
        //ODM_RT_TRACE(pDM_Odm,ODM_COMP_COMMON, ODM_DBG_LOUD,( "[RSSIMonitorCheckMP] Send H2C to FW\n"));
    }
    else
        NoiseState = 0;


    //if(check_fwstate(&Adapter->mlmepriv, WIFI_AP_STATE|WIFI_ADHOC_STATE|WIFI_ADHOC_MASTER_STATE) == _TRUE)
    {
        struct sta_info *psta;

        for (i = 0; i < ODM_ASSOCIATE_ENTRY_NUM; i++)
        {
            if (IS_STA_VALID(psta = pDM_Odm->pODM_StaInfo[i]))
            {
                if (IS_MCAST(psta->hwaddr))  //if(psta->mac_id ==1)
                    continue;

                if (psta->rssi_stat.UndecoratedSmoothedPWDB == (-1))
                    continue;

                if (psta->rssi_stat.UndecoratedSmoothedPWDB < tmpEntryMinPWDB)
                    tmpEntryMinPWDB = psta->rssi_stat.UndecoratedSmoothedPWDB;

                if (psta->rssi_stat.UndecoratedSmoothedPWDB > tmpEntryMaxPWDB)
                    tmpEntryMaxPWDB = psta->rssi_stat.UndecoratedSmoothedPWDB;


                if (psta->rssi_stat.UndecoratedSmoothedPWDB != (-1))
                {

                    /*if (pDM_Odm->SupportICType == ODM_RTL8192E || pDM_Odm->SupportICType == ODM_RTL8812) */
                    {
#ifdef CONFIG_BEAMFORMING

#if (BEAMFORMING_SUPPORT == 1)
                        BEAMFORMING_CAP Beamform_cap = phydm_Beamforming_GetEntryBeamCapByMacId(pDM_Odm, psta->mac_id);
#else/*for drv beamforming*/
                        BEAMFORMING_CAP Beamform_cap = beamforming_get_entry_beam_cap_by_mac_id(&Adapter->mlmepriv, psta->mac_id);
#endif
                        if (Beamform_cap & (BEAMFORMER_CAP_HT_EXPLICIT | BEAMFORMER_CAP_VHT_SU))
                            TxBF_EN = 1;
                        else
                            TxBF_EN = 0;
#endif /*#ifdef CONFIG_BEAMFORMING*/

                        if (TxBF_EN)
                            STBC_TX = 0;
                        else
                        {
#ifdef CONFIG_80211AC_VHT
                            if (IsSupportedVHT(psta->wireless_mode))
                                STBC_TX = TEST_FLAG(psta->vhtpriv.stbc_cap, STBC_VHT_ENABLE_TX);
                            else
#endif
                                STBC_TX = TEST_FLAG(psta->htpriv.stbc_cap, STBC_HT_ENABLE_TX);
                        }
                    }


                    if ((pDM_Odm->SupportICType == ODM_RTL8192E)
                        || (pDM_Odm->SupportICType == ODM_RTL8812) || (pDM_Odm->SupportICType == ODM_RTL8821)
                        || (pDM_Odm->SupportICType == ODM_RTL8814A)
                        || (pDM_Odm->SupportICType == ODM_RTL8822B)

                       )
                    {
                        PWDB_rssi[sta_cnt++] = (((u8)(psta->mac_id & 0xFF)) | ((psta->rssi_stat.UndecoratedSmoothedPWDB & 0x7F) << 16) | (STBC_TX << 25) | (NoiseState<<26) | (FirstConnect << 29) | (TxBF_EN << 30));
                    }
                    else
                        PWDB_rssi[sta_cnt++] = (psta->mac_id | (psta->rssi_stat.UndecoratedSmoothedPWDB << 16) | (NoiseState<<26));

                }
            }
        }

        //printk("%s==> sta_cnt(%d)\n",__FUNCTION__,sta_cnt);

        for (i = 0; i < sta_cnt; i++)
        {
            if (PWDB_rssi[i] != (0))
            {
                if (pHalData->fw_ractrl == _TRUE)   // Report every sta's RSSI to FW
                {
                    if ((pDM_Odm->SupportICType == ODM_RTL8812) || (pDM_Odm->SupportICType == ODM_RTL8821))
                    {
                        PWDB_rssi[i] |= (UL_DL_STATE << 24);
                        rtl8812_set_rssi_cmd(Adapter, (u8 *)(&PWDB_rssi[i]));
                    }
                }
            }
        }
    }



    if (tmpEntryMaxPWDB != 0)   // If associated entry is found
        pHalData->EntryMaxUndecoratedSmoothedPWDB = tmpEntryMaxPWDB;
    else
        pHalData->EntryMaxUndecoratedSmoothedPWDB = 0;

    if (tmpEntryMinPWDB != 0xff) // If associated entry is found
        pHalData->EntryMinUndecoratedSmoothedPWDB = tmpEntryMinPWDB;
    else
        pHalData->EntryMinUndecoratedSmoothedPWDB = 0;

    FindMinimumRSSI(Adapter);//get pdmpriv->MinUndecoratedPWDBForDM

    pDM_Odm->RSSI_Min = pHalData->MinUndecoratedPWDBForDM;
    //ODM_CmnInfoUpdate(&pHalData->odmpriv ,ODM_CMNINFO_RSSI_MIN, pdmpriv->MinUndecoratedPWDBForDM);

}




VOID
odm_RSSIMonitorCheckAP(
    IN      PVOID       pDM_VOID
)
{

}




VOID
odm_RateAdaptiveMaskInit(
    IN  PVOID   pDM_VOID
)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
    PODM_RATE_ADAPTIVE  pOdmRA = &pDM_Odm->RateAdaptive;


    pOdmRA->Type = DM_Type_ByDriver;
    if (pOdmRA->Type == DM_Type_ByDriver)
        pDM_Odm->bUseRAMask = _TRUE;
    else
        pDM_Odm->bUseRAMask = _FALSE;


    pOdmRA->RATRState = DM_RATR_STA_INIT;
    pOdmRA->LdpcThres = 35;
    pOdmRA->bUseLdpc = FALSE;
    pOdmRA->HighRSSIThresh = 50;
    pOdmRA->LowRSSIThresh = 20;

}




/*-----------------------------------------------------------------------------
 * Function:    odm_RefreshRateAdaptiveMask()
 *
 * Overview:    Update rate table mask according to rssi
 *
 * Input:       NONE
 *
 * Output:      NONE
 *
 * Return:      NONE
 *
 * Revised History:
 *  When        Who     Remark
 *  05/27/2009  hpfan   Create Version 0.
 *
 *---------------------------------------------------------------------------*/
VOID
odm_RefreshRateAdaptiveMask(
    IN  PVOID   pDM_VOID
)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
    ODM_RT_TRACE(pDM_Odm, ODM_COMP_RA_MASK, ODM_DBG_TRACE, ("odm_RefreshRateAdaptiveMask()---------->\n"));
    if (!(pDM_Odm->SupportAbility & ODM_BB_RA_MASK))
    {
        ODM_RT_TRACE(pDM_Odm, ODM_COMP_RA_MASK, ODM_DBG_TRACE, ("odm_RefreshRateAdaptiveMask(): Return cos not supported\n"));
        return;
    }
    //
    // 2011/09/29 MH In HW integration first stage, we provide 4 different handle to operate
    // at the same time. In the stage2/3, we need to prive universal interface and merge all
    // HW dynamic mechanism.
    //
    switch  (pDM_Odm->SupportPlatform)
    {
        case    ODM_WIN:
            odm_RefreshRateAdaptiveMaskMP(pDM_Odm);
            break;

        case    ODM_CE:
            odm_RefreshRateAdaptiveMaskCE(pDM_Odm);
            break;

        case    ODM_AP:
        case    ODM_ADSL:
            odm_RefreshRateAdaptiveMaskAPADSL(pDM_Odm);
            break;
    }

}




VOID
odm_RefreshRateAdaptiveMaskMP(
    IN      PVOID       pDM_VOID
)
{

}




VOID
odm_RefreshRateAdaptiveMaskCE(
    IN  PVOID   pDM_VOID
)
{

    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
    u1Byte  i;
    PADAPTER    pAdapter     =  pDM_Odm->Adapter;
    PODM_RATE_ADAPTIVE      pRA = &pDM_Odm->RateAdaptive;

    if (RTW_CANNOT_RUN(pAdapter))
    {
        ODM_RT_TRACE(pDM_Odm, ODM_COMP_RA_MASK, ODM_DBG_TRACE, ("<---- odm_RefreshRateAdaptiveMask(): driver is going to unload\n"));
        return;
    }

    if (!pDM_Odm->bUseRAMask)
    {
        ODM_RT_TRACE(pDM_Odm, ODM_COMP_RA_MASK, ODM_DBG_LOUD, ("<---- odm_RefreshRateAdaptiveMask(): driver does not control rate adaptive mask\n"));
        return;
    }

    //printk("==> %s \n",__FUNCTION__);

    for (i = 0; i < ODM_ASSOCIATE_ENTRY_NUM; i++)
    {
        PSTA_INFO_T pstat = pDM_Odm->pODM_StaInfo[i];
        if (IS_STA_VALID(pstat))
        {
            if (IS_MCAST(pstat->hwaddr))  //if(psta->mac_id ==1)
                continue;
            if (IS_MCAST(pstat->hwaddr))
                continue;


            if ((pDM_Odm->SupportICType == ODM_RTL8812) || (pDM_Odm->SupportICType == ODM_RTL8821))
            {
                if (pstat->rssi_stat.UndecoratedSmoothedPWDB < pRA->LdpcThres)
                {
                    pRA->bUseLdpc = TRUE;
                    pRA->bLowerRtsRate = TRUE;
                    if ((pDM_Odm->SupportICType == ODM_RTL8821) && (pDM_Odm->CutVersion == ODM_CUT_A))
                        Set_RA_LDPC_8812(pstat, TRUE);
                    //DbgPrint("RSSI=%d, bUseLdpc = TRUE\n", pHalData->UndecoratedSmoothedPWDB);
                }
                else if (pstat->rssi_stat.UndecoratedSmoothedPWDB > (pRA->LdpcThres - 5))
                {
                    pRA->bUseLdpc = FALSE;
                    pRA->bLowerRtsRate = FALSE;
                    if ((pDM_Odm->SupportICType == ODM_RTL8821) && (pDM_Odm->CutVersion == ODM_CUT_A))
                        Set_RA_LDPC_8812(pstat, FALSE);
                    //DbgPrint("RSSI=%d, bUseLdpc = FALSE\n", pHalData->UndecoratedSmoothedPWDB);
                }
            }


            if (TRUE == ODM_RAStateCheck(pDM_Odm, pstat->rssi_stat.UndecoratedSmoothedPWDB, FALSE, &pstat->rssi_level))
            {
                ODM_RT_TRACE(pDM_Odm, ODM_COMP_RA_MASK, ODM_DBG_LOUD, ("RSSI:%d, RSSI_LEVEL:%d\n", pstat->rssi_stat.UndecoratedSmoothedPWDB, pstat->rssi_level));
                //printk("RSSI:%d, RSSI_LEVEL:%d\n", pstat->rssi_stat.UndecoratedSmoothedPWDB, pstat->rssi_level);
                rtw_hal_update_ra_mask(pstat, pstat->rssi_level);
            }
            else if (pDM_Odm->bChangeState)
            {
                ODM_RT_TRACE(pDM_Odm, ODM_COMP_RA_MASK, ODM_DBG_LOUD, ("Change Power Training State, bDisablePowerTraining = %d\n", pDM_Odm->bDisablePowerTraining));
                rtw_hal_update_ra_mask(pstat, pstat->rssi_level);
            }

        }
    }

}




VOID
odm_RefreshRateAdaptiveMaskAPADSL(
    IN  PVOID   pDM_VOID
)
{

}





// Return Value: BOOLEAN
// - TRUE: RATRState is changed.
BOOLEAN
ODM_RAStateCheck(
    IN      PVOID           pDM_VOID,
    IN      s4Byte          RSSI,
    IN      BOOLEAN         bForceUpdate,
    OUT     pu1Byte         pRATRState
)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
    PODM_RATE_ADAPTIVE pRA = &pDM_Odm->RateAdaptive;
    const u1Byte GoUpGap = 5;
    u1Byte HighRSSIThreshForRA = pRA->HighRSSIThresh;
    u1Byte LowRSSIThreshForRA = pRA->LowRSSIThresh;
    u1Byte RATRState;
    ODM_RT_TRACE(pDM_Odm, ODM_COMP_RA_MASK, ODM_DBG_LOUD, ("RSSI= (( %d )), Current_RSSI_level = (( %d ))\n", RSSI, *pRATRState));
    ODM_RT_TRACE(pDM_Odm, ODM_COMP_RA_MASK, ODM_DBG_LOUD, ("[Ori RA RSSI Thresh]  High= (( %d )), Low = (( %d ))\n", HighRSSIThreshForRA, LowRSSIThreshForRA));

    switch (*pRATRState)
    {
        case DM_RATR_STA_INIT:
        case DM_RATR_STA_HIGH:
            break;

        case DM_RATR_STA_MIDDLE:
            HighRSSIThreshForRA += GoUpGap;
            break;

        case DM_RATR_STA_LOW:
            HighRSSIThreshForRA += GoUpGap;
            LowRSSIThreshForRA += GoUpGap;
            break;

        default:
            ODM_RT_ASSERT(pDM_Odm, FALSE, ("wrong rssi level setting %d !", *pRATRState));
            break;
    }

    // Decide RATRState by RSSI.
    if (RSSI > HighRSSIThreshForRA)
        RATRState = DM_RATR_STA_HIGH;
    else if (RSSI > LowRSSIThreshForRA)
        RATRState = DM_RATR_STA_MIDDLE;
    else
        RATRState = DM_RATR_STA_LOW;

    ODM_RT_TRACE(pDM_Odm, ODM_COMP_RA_MASK, ODM_DBG_LOUD, ("[Mod RA RSSI Thresh]  High= (( %d )), Low = (( %d ))\n", HighRSSIThreshForRA, LowRSSIThreshForRA));
    /*printk("==>%s,RATRState:0x%02x ,RSSI:%d\n",__FUNCTION__,RATRState,RSSI);*/

    if (*pRATRState != RATRState || bForceUpdate)
    {
        ODM_RT_TRACE(pDM_Odm, ODM_COMP_RA_MASK, ODM_DBG_LOUD, ("[RSSI Level Update] %d -> %d\n", *pRATRState, RATRState));
        *pRATRState = RATRState;
        return TRUE;
    }

    return FALSE;
}




VOID
odm_RefreshBasicRateMask(
    IN  PVOID   pDM_VOID
)
{

}



VOID
phydm_ra_info_init(
    IN  PVOID   pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = (PDM_ODM_T)pDM_VOID;
    /*phydm_fw_trace_en_h2c(pDM_Odm, 1, 0, 0);*/
}




u1Byte
odm_Find_RTS_Rate(
    IN      PVOID           pDM_VOID,
    IN      u1Byte          Tx_Rate,
    IN      BOOLEAN         bErpProtect
)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
    u1Byte  RTS_Ini_Rate = ODM_RATE6M;

    if (bErpProtect) /* use CCK rate as RTS*/
        RTS_Ini_Rate = ODM_RATE1M;
    else
    {
        switch (Tx_Rate)
        {
            case ODM_RATEVHTSS3MCS9:
            case ODM_RATEVHTSS3MCS8:
            case ODM_RATEVHTSS3MCS7:
            case ODM_RATEVHTSS3MCS6:
            case ODM_RATEVHTSS3MCS5:
            case ODM_RATEVHTSS3MCS4:
            case ODM_RATEVHTSS3MCS3:
            case ODM_RATEVHTSS2MCS9:
            case ODM_RATEVHTSS2MCS8:
            case ODM_RATEVHTSS2MCS7:
            case ODM_RATEVHTSS2MCS6:
            case ODM_RATEVHTSS2MCS5:
            case ODM_RATEVHTSS2MCS4:
            case ODM_RATEVHTSS2MCS3:
            case ODM_RATEVHTSS1MCS9:
            case ODM_RATEVHTSS1MCS8:
            case ODM_RATEVHTSS1MCS7:
            case ODM_RATEVHTSS1MCS6:
            case ODM_RATEVHTSS1MCS5:
            case ODM_RATEVHTSS1MCS4:
            case ODM_RATEVHTSS1MCS3:
            case ODM_RATEMCS15:
            case ODM_RATEMCS14:
            case ODM_RATEMCS13:
            case ODM_RATEMCS12:
            case ODM_RATEMCS11:
            case ODM_RATEMCS7:
            case ODM_RATEMCS6:
            case ODM_RATEMCS5:
            case ODM_RATEMCS4:
            case ODM_RATEMCS3:
            case ODM_RATE54M:
            case ODM_RATE48M:
            case ODM_RATE36M:
            case ODM_RATE24M:
                RTS_Ini_Rate = ODM_RATE24M;
                break;
            case ODM_RATEVHTSS3MCS2:
            case ODM_RATEVHTSS3MCS1:
            case ODM_RATEVHTSS2MCS2:
            case ODM_RATEVHTSS2MCS1:
            case ODM_RATEVHTSS1MCS2:
            case ODM_RATEVHTSS1MCS1:
            case ODM_RATEMCS10:
            case ODM_RATEMCS9:
            case ODM_RATEMCS2:
            case ODM_RATEMCS1:
            case ODM_RATE18M:
            case ODM_RATE12M:
                RTS_Ini_Rate = ODM_RATE12M;
                break;
            case ODM_RATEVHTSS3MCS0:
            case ODM_RATEVHTSS2MCS0:
            case ODM_RATEVHTSS1MCS0:
            case ODM_RATEMCS8:
            case ODM_RATEMCS0:
            case ODM_RATE9M:
            case ODM_RATE6M:
                RTS_Ini_Rate = ODM_RATE6M;
                break;
            case ODM_RATE11M:
            case ODM_RATE5_5M:
            case ODM_RATE2M:
            case ODM_RATE1M:
                RTS_Ini_Rate = ODM_RATE1M;
                break;
            default:
                RTS_Ini_Rate = ODM_RATE6M;
                break;
        }
    }

    if (*pDM_Odm->pBandType == 1)
    {
        if (RTS_Ini_Rate < ODM_RATE6M)
            RTS_Ini_Rate = ODM_RATE6M;
    }
    return RTS_Ini_Rate;

}





VOID
odm_Set_RA_DM_ARFB_by_Noisy(
    IN  PDM_ODM_T   pDM_Odm
)
{
    /*DbgPrint("DM_ARFB ====>\n");*/
    if (pDM_Odm->bNoisyState)
    {
        ODM_Write4Byte(pDM_Odm, 0x430, 0x00000000);
        ODM_Write4Byte(pDM_Odm, 0x434, 0x05040200);
        /*DbgPrint("DM_ARFB ====> Noisy State\n");*/
    }
    else
    {
        ODM_Write4Byte(pDM_Odm, 0x430, 0x02010000);
        ODM_Write4Byte(pDM_Odm, 0x434, 0x07050403);
        /*DbgPrint("DM_ARFB ====> Clean State\n");*/
    }

}




VOID
ODM_UpdateNoisyState(
    IN  PVOID       pDM_VOID,
    IN  BOOLEAN     bNoisyStateFromC2H
)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;

    /*DbgPrint("Get C2H Command! NoisyState=0x%x\n ", bNoisyStateFromC2H);*/
    if (pDM_Odm->SupportICType == ODM_RTL8821  || pDM_Odm->SupportICType == ODM_RTL8812  ||
        pDM_Odm->SupportICType == ODM_RTL8723B || pDM_Odm->SupportICType == ODM_RTL8192E || pDM_Odm->SupportICType == ODM_RTL8188E)
        pDM_Odm->bNoisyState = bNoisyStateFromC2H;
    odm_Set_RA_DM_ARFB_by_Noisy(pDM_Odm);
};




u4Byte
Set_RA_DM_Ratrbitmap_by_Noisy(
    IN  PVOID           pDM_VOID,
    IN  WIRELESS_MODE   WirelessMode,
    IN  u4Byte          ratr_bitmap,
    IN  u1Byte          rssi_level
)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
    u4Byte ret_bitmap = ratr_bitmap;

    return ret_bitmap;

    switch (WirelessMode)
    {
        case WIRELESS_MODE_AC_24G:
        case WIRELESS_MODE_AC_5G:
        case WIRELESS_MODE_AC_ONLY:
            if (pDM_Odm->bNoisyState)   /*in Noisy State*/
            {
                if (rssi_level == 1)
                    ret_bitmap &= 0xfc3e0c08;       // Reserve MCS 5-9
                else if (rssi_level == 2)
                    ret_bitmap &= 0xfe3f8e08;       // Reserve MCS 3-9
                else if (rssi_level == 3)
                    ret_bitmap &= 0xffffffff;
                else
                    ret_bitmap &= 0xffffffff;
            }
            else                                    /* in SNR State*/
            {
                if (rssi_level == 1)
                    ret_bitmap &= 0xfe3f0e08;       // Reserve MCS 4-9
                else if (rssi_level == 2)
                    ret_bitmap &= 0xff3fcf8c;       // Reserve MCS 2-9
                else if (rssi_level == 3)
                    ret_bitmap &= 0xffffffff;
                else
                    ret_bitmap &= 0xffffffff;
            }
            break;
        case WIRELESS_MODE_B:
        case WIRELESS_MODE_A:
        case WIRELESS_MODE_G:
        case WIRELESS_MODE_N_24G:
        case WIRELESS_MODE_N_5G:
            if (pDM_Odm->bNoisyState)
            {
                if (rssi_level == 1)
                    ret_bitmap &= 0x0f0e0c08;       // Reserve MCS 4-7; MCS12-15
                else if (rssi_level == 2)
                    ret_bitmap &= 0x0fcfce0c;       // Reserve MCS 2-7; MCS10-15
                else if (rssi_level == 3)
                    ret_bitmap &= 0xffffffff;
                else
                    ret_bitmap &= 0xffffffff;
            }
            else
            {
                if (rssi_level == 1)
                    ret_bitmap &= 0x0f8f8e08;       // Reserve MCS 3-7; MCS11-15
                else if (rssi_level == 2)
                    ret_bitmap &= 0x0fefef8c;       // Reserve MCS 1-7; MCS9-15
                else if (rssi_level == 3)
                    ret_bitmap &= 0xffffffff;
                else
                    ret_bitmap &= 0xffffffff;
            }
            break;
        default:
            break;
    }
    /*DbgPrint("DM_RAMask ====> rssi_LV = %d, BITMAP = %x\n", rssi_level, ret_bitmap);*/
    return ret_bitmap;

}




VOID
ODM_UpdateInitRate(
    IN  PVOID       pDM_VOID,
    IN  u1Byte      Rate
)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
    u1Byte          p = 0;

    ODM_RT_TRACE(pDM_Odm, ODM_COMP_TX_PWR_TRACK, ODM_DBG_LOUD, ("Get C2H Command! Rate=0x%x\n", Rate));

    if (pDM_Odm->SupportICType == ODM_RTL8821  || pDM_Odm->SupportICType == ODM_RTL8812  ||
        pDM_Odm->SupportICType == ODM_RTL8723B || pDM_Odm->SupportICType == ODM_RTL8192E || pDM_Odm->SupportICType == ODM_RTL8188E
        || pDM_Odm->SupportICType == ODM_RTL8703B)
    {
        pDM_Odm->TxRate = Rate;
    }
    else
        return;
}



static void
FindMinimumRSSI(
    IN  PADAPTER    pAdapter
)
{
    HAL_DATA_TYPE   *pHalData = GET_HAL_DATA(pAdapter);
    PDM_ODM_T       pDM_Odm = &(pHalData->odmpriv);

    /*Determine the minimum RSSI*/

    if ((pDM_Odm->bLinked != _TRUE) &&
        (pHalData->EntryMinUndecoratedSmoothedPWDB == 0))
    {
        pHalData->MinUndecoratedPWDBForDM = 0;
        /*ODM_RT_TRACE(pDM_Odm,COMP_BB_POWERSAVING, DBG_LOUD, ("Not connected to any\n"));*/
    }
    else
        pHalData->MinUndecoratedPWDBForDM = pHalData->EntryMinUndecoratedSmoothedPWDB;

    /*DBG_8192C("%s=>MinUndecoratedPWDBForDM(%d)\n",__FUNCTION__,pdmpriv->MinUndecoratedPWDBForDM);*/
    /*ODM_RT_TRACE(pDM_Odm,COMP_DIG, DBG_LOUD, ("MinUndecoratedPWDBForDM =%d\n",pHalData->MinUndecoratedPWDBForDM));*/
}





u8Byte
PhyDM_Get_Rate_Bitmap_Ex(
    IN  PVOID       pDM_VOID,
    IN  u4Byte      macid,
    IN  u8Byte      ra_mask,
    IN  u1Byte      rssi_level,
    OUT     u8Byte  *dm_RA_Mask,
    OUT     u1Byte  *dm_RteID
)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
    PSTA_INFO_T pEntry;
    u8Byte  rate_bitmap = 0;
    u1Byte  WirelessMode;

    pEntry = pDM_Odm->pODM_StaInfo[macid];
    if (!IS_STA_VALID(pEntry))
        return ra_mask;
    WirelessMode = pEntry->wireless_mode;
    switch (WirelessMode)
    {
        case ODM_WM_B:
            if (ra_mask & 0x000000000000000c) /* 11M or 5.5M enable */
                rate_bitmap = 0x000000000000000d;
            else
                rate_bitmap = 0x000000000000000f;
            break;

        case (ODM_WM_G):
        case (ODM_WM_A):
            if (rssi_level == DM_RATR_STA_HIGH)
                rate_bitmap = 0x0000000000000f00;
            else
                rate_bitmap = 0x0000000000000ff0;
            break;

        case (ODM_WM_B|ODM_WM_G):
            if (rssi_level == DM_RATR_STA_HIGH)
                rate_bitmap = 0x0000000000000f00;
            else if (rssi_level == DM_RATR_STA_MIDDLE)
                rate_bitmap = 0x0000000000000ff0;
            else
                rate_bitmap = 0x0000000000000ff5;
            break;

        case (ODM_WM_B|ODM_WM_G|ODM_WM_N24G):
        case (ODM_WM_B|ODM_WM_N24G):
        case (ODM_WM_G|ODM_WM_N24G):
        case (ODM_WM_A|ODM_WM_N5G):
        {
            if (pDM_Odm->RFType == ODM_1T2R || pDM_Odm->RFType == ODM_1T1R)
            {
                if (rssi_level == DM_RATR_STA_HIGH)
                    rate_bitmap = 0x00000000000f0000;
                else if (rssi_level == DM_RATR_STA_MIDDLE)
                    rate_bitmap = 0x00000000000ff000;
                else
                {
                    if (*(pDM_Odm->pBandWidth) == ODM_BW40M)
                        rate_bitmap = 0x00000000000ff015;
                    else
                        rate_bitmap = 0x00000000000ff005;
                }
            }
            else if (pDM_Odm->RFType == ODM_2T2R  || pDM_Odm->RFType == ODM_2T3R  || pDM_Odm->RFType == ODM_2T4R)
            {
                if (rssi_level == DM_RATR_STA_HIGH)
                    rate_bitmap = 0x000000000f8f0000;
                else if (rssi_level == DM_RATR_STA_MIDDLE)
                    rate_bitmap = 0x000000000f8ff000;
                else
                {
                    if (*(pDM_Odm->pBandWidth) == ODM_BW40M)
                        rate_bitmap = 0x000000000f8ff015;
                    else
                        rate_bitmap = 0x000000000f8ff005;
                }
            }
            else
            {
                if (rssi_level == DM_RATR_STA_HIGH)
                    rate_bitmap = 0x0000000f0f0f0000;
                else if (rssi_level == DM_RATR_STA_MIDDLE)
                    rate_bitmap = 0x0000000fcfcfe000;
                else
                {
                    if (*(pDM_Odm->pBandWidth) == ODM_BW40M)
                        rate_bitmap = 0x0000000ffffff015;
                    else
                        rate_bitmap = 0x0000000ffffff005;
                }
            }
        }
        break;

        case (ODM_WM_AC|ODM_WM_G):
            if (rssi_level == 1)
                rate_bitmap = 0x00000000fc3f0000;
            else if (rssi_level == 2)
                rate_bitmap = 0x00000000fffff000;
            else
                rate_bitmap = 0x00000000ffffffff;
            break;

        case (ODM_WM_AC|ODM_WM_A):

            if (pDM_Odm->RFType == ODM_1T2R || pDM_Odm->RFType == ODM_1T1R)
            {
                if (rssi_level == 1)                /* add by Gary for ac-series */
                    rate_bitmap = 0x00000000003f8000;
                else if (rssi_level == 2)
                    rate_bitmap = 0x00000000003fe000;
                else
                    rate_bitmap = 0x00000000003ff010;
            }
            else if (pDM_Odm->RFType == ODM_2T2R  || pDM_Odm->RFType == ODM_2T3R  || pDM_Odm->RFType == ODM_2T4R)
            {
                if (rssi_level == 1)                /* add by Gary for ac-series */
                    rate_bitmap = 0x00000000fe3f8000;       /* VHT 2SS MCS3~9 */
                else if (rssi_level == 2)
                    rate_bitmap = 0x00000000fffff000;       /* VHT 2SS MCS0~9 */
                else
                    rate_bitmap = 0x00000000fffff010;       /* All */
            }
            else
            {
                if (rssi_level == 1)                /* add by Gary for ac-series */
                    rate_bitmap = 0x000003f8fe3f8000ULL;       /* VHT 3SS MCS3~9 */
                else if (rssi_level == 2)
                    rate_bitmap = 0x000003fffffff000ULL;       /* VHT3SS MCS0~9 */
                else
                    rate_bitmap = 0x000003fffffff010ULL;       /* All */
            }
            break;

        default:
            if (pDM_Odm->RFType == ODM_1T2R || pDM_Odm->RFType == ODM_1T1R)
                rate_bitmap = 0x00000000000fffff;
            else if (pDM_Odm->RFType == ODM_2T2R  || pDM_Odm->RFType == ODM_2T3R  || pDM_Odm->RFType == ODM_2T4R)
                rate_bitmap = 0x000000000fffffff;
            else
                rate_bitmap = 0x0000003fffffffffULL;
            break;

    }
    ODM_RT_TRACE(pDM_Odm, ODM_COMP_RA_MASK, ODM_DBG_LOUD, (" ==> rssi_level:0x%02x, WirelessMode:0x%02x, rate_bitmap:0x%016llx\n", rssi_level, WirelessMode, rate_bitmap));

    return (ra_mask & rate_bitmap);
}





u4Byte
ODM_Get_Rate_Bitmap(
    IN  PVOID       pDM_VOID,
    IN  u4Byte      macid,
    IN  u4Byte      ra_mask,
    IN  u1Byte      rssi_level
)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
    PSTA_INFO_T     pEntry;
    u4Byte  rate_bitmap = 0;
    u1Byte  WirelessMode;
    //u1Byte    WirelessMode =*(pDM_Odm->pWirelessMode);


    pEntry = pDM_Odm->pODM_StaInfo[macid];
    if (!IS_STA_VALID(pEntry))
        return ra_mask;

    WirelessMode = pEntry->wireless_mode;

    switch (WirelessMode)
    {
        case ODM_WM_B:
            if (ra_mask & 0x0000000c)       //11M or 5.5M enable
                rate_bitmap = 0x0000000d;
            else
                rate_bitmap = 0x0000000f;
            break;

        case (ODM_WM_G):
        case (ODM_WM_A):
            if (rssi_level == DM_RATR_STA_HIGH)
                rate_bitmap = 0x00000f00;
            else
                rate_bitmap = 0x00000ff0;
            break;

        case (ODM_WM_B|ODM_WM_G):
            if (rssi_level == DM_RATR_STA_HIGH)
                rate_bitmap = 0x00000f00;
            else if (rssi_level == DM_RATR_STA_MIDDLE)
                rate_bitmap = 0x00000ff0;
            else
                rate_bitmap = 0x00000ff5;
            break;

        case (ODM_WM_B|ODM_WM_G|ODM_WM_N24G)    :
        case (ODM_WM_B|ODM_WM_N24G) :
        case (ODM_WM_G|ODM_WM_N24G) :
        case (ODM_WM_A|ODM_WM_N5G)  :
        {
            if (pDM_Odm->RFType == ODM_1T2R || pDM_Odm->RFType == ODM_1T1R)
            {
                if (rssi_level == DM_RATR_STA_HIGH)
                    rate_bitmap = 0x000f0000;
                else if (rssi_level == DM_RATR_STA_MIDDLE)
                    rate_bitmap = 0x000ff000;
                else
                {
                    if (*(pDM_Odm->pBandWidth) == ODM_BW40M)
                        rate_bitmap = 0x000ff015;
                    else
                        rate_bitmap = 0x000ff005;
                }
            }
            else
            {
                if (rssi_level == DM_RATR_STA_HIGH)
                    rate_bitmap = 0x0f8f0000;
                else if (rssi_level == DM_RATR_STA_MIDDLE)
                    rate_bitmap = 0x0f8ff000;
                else
                {
                    if (*(pDM_Odm->pBandWidth) == ODM_BW40M)
                        rate_bitmap = 0x0f8ff015;
                    else
                        rate_bitmap = 0x0f8ff005;
                }
            }
        }
        break;

        case (ODM_WM_AC|ODM_WM_G):
            if (rssi_level == 1)
                rate_bitmap = 0xfc3f0000;
            else if (rssi_level == 2)
                rate_bitmap = 0xfffff000;
            else
                rate_bitmap = 0xffffffff;
            break;

        case (ODM_WM_AC|ODM_WM_A):

            if (pDM_Odm->RFType == RF_1T1R)
            {
                if (rssi_level == 1)                // add by Gary for ac-series
                    rate_bitmap = 0x003f8000;
                else if (rssi_level == 2)
                    rate_bitmap = 0x003ff000;
                else
                    rate_bitmap = 0x003ff010;
            }
            else
            {
                if (rssi_level == 1)                // add by Gary for ac-series
                    rate_bitmap = 0xfe3f8000;       // VHT 2SS MCS3~9
                else if (rssi_level == 2)
                    rate_bitmap = 0xfffff000;       // VHT 2SS MCS0~9
                else
                    rate_bitmap = 0xfffff010;       // All
            }
            break;

        default:
            if (pDM_Odm->RFType == RF_1T2R)
                rate_bitmap = 0x000fffff;
            else
                rate_bitmap = 0x0fffffff;
            break;

    }

    DBG_871X("%s ==> rssi_level:0x%02x, WirelessMode:0x%02x, rate_bitmap:0x%08x\n", __func__, rssi_level, WirelessMode, rate_bitmap);
    ODM_RT_TRACE(pDM_Odm, ODM_COMP_RA_MASK, ODM_DBG_LOUD, (" ==> rssi_level:0x%02x, WirelessMode:0x%02x, rate_bitmap:0x%08x\n", rssi_level, WirelessMode, rate_bitmap));

    return (ra_mask & rate_bitmap);

}




