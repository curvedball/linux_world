


#ifndef __PHYDMADAPTIVITY_H__
#define    __PHYDMADAPTIVITY_H__



#define ADAPTIVITY_VERSION  "9.0"

#define PwdBUpperBound  7
#define DFIRloss    5




typedef enum tag_PhyDM_set_LNA
{
    PhyDM_disable_LNA       = 0,
    PhyDM_enable_LNA        = 1,
} PhyDM_set_LNA;




typedef enum tag_PhyDM_TRx_MUX_Type
{
    PhyDM_SHUTDOWN          = 0,
    PhyDM_STANDBY_MODE      = 1,
    PhyDM_TX_MODE           = 2,
    PhyDM_RX_MODE           = 3
} PhyDM_Trx_MUX_Type;




typedef enum tag_PhyDM_MACEDCCA_Type
{
    PhyDM_IGNORE_EDCCA          = 0,
    PhyDM_DONT_IGNORE_EDCCA = 1
} PhyDM_MACEDCCA_Type;




typedef struct _ADAPTIVITY_STATISTICS
{
    s1Byte          TH_L2H_ini_backup;
    s1Byte          TH_EDCCA_HL_diff_backup;
    s1Byte          IGI_Base;
    u1Byte          IGI_target;
    u1Byte          NHMWait;
    s1Byte          H2L_lb;
    s1Byte          L2H_lb;
    BOOLEAN         bFirstLink;
    BOOLEAN         bCheck;
    BOOLEAN         DynamicLinkAdaptivity;
    u1Byte          APNumTH;
    u1Byte          AdajustIGILevel;
} ADAPTIVITY_STATISTICS, *PADAPTIVITY_STATISTICS;




VOID
Phydm_CheckAdaptivity(
    IN      PVOID           pDM_VOID
);

VOID
Phydm_CheckEnvironment(
    IN      PVOID                   pDM_VOID
);

VOID
Phydm_NHMCounterStatisticsInit(
    IN      PVOID                   pDM_VOID
);

VOID
Phydm_NHMCounterStatistics(
    IN      PVOID                   pDM_VOID
);

VOID
Phydm_NHMCounterStatisticsReset(
    IN      PVOID           pDM_VOID
);

VOID
Phydm_GetNHMCounterStatistics(
    IN      PVOID           pDM_VOID
);

VOID
Phydm_MACEDCCAState(
    IN  PVOID                   pDM_VOID,
    IN  PhyDM_MACEDCCA_Type     State
);

VOID
Phydm_SetEDCCAThreshold(
    IN      PVOID       pDM_VOID,
    IN      s1Byte      H2L,
    IN      s1Byte      L2H
);

VOID
Phydm_SetTRxMux(
    IN      PVOID           pDM_VOID,
    IN      PhyDM_Trx_MUX_Type          txMode,
    IN      PhyDM_Trx_MUX_Type          rxMode
);

BOOLEAN
Phydm_CalNHMcnt(
    IN      PVOID       pDM_VOID
);

VOID
Phydm_SearchPwdBLowerBound(
    IN      PVOID                   pDM_VOID
);

VOID
Phydm_AdaptivityInit(
    IN      PVOID                   pDM_VOID
);

VOID
Phydm_Adaptivity(
    IN      PVOID                   pDM_VOID,
    IN      u1Byte                  IGI
);




#endif



