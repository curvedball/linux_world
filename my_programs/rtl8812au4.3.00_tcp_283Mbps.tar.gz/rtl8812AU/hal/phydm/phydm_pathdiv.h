



#ifndef __PHYDMPATHDIV_H__
#define    __PHYDMPATHDIV_H__


#define PATHDIV_VERSION "3.0" /*2015.01.13 Dino*/



VOID
phydm_c2h_dtp_handler(
    IN PVOID   pDM_VOID,
    IN     pu1Byte   CmdBuf,
    IN     u1Byte  CmdLen
);

VOID
odm_PathDiversityInit(
    IN  PVOID   pDM_VOID
);

VOID
odm_PathDiversity(
    IN  PVOID   pDM_VOID
);

VOID
odm_pathdiv_debug(
    IN      PVOID       pDM_VOID,
    IN      u4Byte      *const dm_value,
    IN      u4Byte      *_used,
    OUT     char        *output,
    IN      u4Byte      *_out_len
);



//1 [OLD IC]--------------------------------------------------------------------------------



#endif



