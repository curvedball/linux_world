


#include "../phydm_precomp.h"



#if (BEAMFORMING_SUPPORT == 1)


/*Beamforming halcomtxbf API create by YuChen 2015/05*/

VOID
halComTxbf_beamformInit (
    IN PVOID            pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;

    if ( pDM_Odm->SupportICType & ODM_RTL8822B )
    {
        //HalTxbf8822B_Init ( pDM_Odm );
    }
}

/*Only used for MU BFer Entry when get GID management frame (self is as MU STA)*/
VOID
halComTxbf_ConfigGtab (
    IN PVOID            pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;

    if ( pDM_Odm->SupportICType & ODM_RTL8822B )
    {
        //HalTxbf8822B_ConfigGtab ( pDM_Odm );
    }
}



VOID
phydm_beamformSetSoundingEnter (
    IN PVOID            pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;

    halComTxbf_EnterWorkItemCallback ( pDM_Odm );
}



VOID
phydm_beamformSetSoundingLeave (
    IN PVOID            pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;
    halComTxbf_LeaveWorkItemCallback ( pDM_Odm );
}




VOID
phydm_beamformSetSoundingRate (
    IN PVOID            pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;
    halComTxbf_RateWorkItemCallback ( pDM_Odm );
}



VOID
phydm_beamformSetSoundingStatus (
    IN PVOID            pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;
    halComTxbf_StatusWorkItemCallback ( pDM_Odm );
}



VOID
phydm_beamformSetSoundingFwNdpa (
    IN PVOID            pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;
    halComTxbf_FwNdpaWorkItemCallback ( pDM_Odm );
}



VOID
phydm_beamformSetSoundingClk (
    IN PVOID            pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;
    halComTxbf_ClkWorkItemCallback ( pDM_Odm );
}



VOID
phydm_beamformSetResetTxPath (
    IN PVOID            pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;
    halComTxbf_ResetTxPathWorkItemCallback ( pDM_Odm );
}



VOID
phydm_beamformSetGetTxRate (
    IN PVOID            pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;
    halComTxbf_GetTxRateWorkItemCallback ( pDM_Odm );
}




VOID
halComTxbf_EnterWorkItemCallback (
    IN PVOID            pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;

    PHAL_TXBF_INFO  pTxbfInfo = &pDM_Odm->BeamformingInfo.TxbfInfo;
    u1Byte          Idx = pTxbfInfo->TXBFIdx;

    ODM_RT_TRACE ( pDM_Odm, PHYDM_COMP_TXBF, ODM_DBG_LOUD, ( "[%s] Start!\n", __func__ ) );

    if ( pDM_Odm->SupportICType & ( ODM_RTL8812 | ODM_RTL8821 ) )
    {
        HalTxbfJaguar_Enter ( pDM_Odm, Idx );
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8192E )
    {
        //
        //HalTxbf8192E_Enter ( pDM_Odm, Idx );
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8814A )
    {
        //HalTxbf8814A_Enter(pDM_Odm, Idx);
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8821B )
    {
        //HalTxbf8821B_Enter(pDM_Odm, Idx);
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8822B )
    {
        //HalTxbf8822B_Enter(pDM_Odm, Idx);
    }
}




VOID
halComTxbf_LeaveWorkItemCallback (
    IN PVOID            pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;
    PHAL_TXBF_INFO  pTxbfInfo = &pDM_Odm->BeamformingInfo.TxbfInfo;

    u1Byte          Idx = pTxbfInfo->TXBFIdx;

    ODM_RT_TRACE ( pDM_Odm, PHYDM_COMP_TXBF, ODM_DBG_LOUD, ( "[%s] Start!\n", __func__ ) );

    if ( pDM_Odm->SupportICType & ( ODM_RTL8812 | ODM_RTL8821 ) )
    {
        HalTxbfJaguar_Leave ( pDM_Odm, Idx );
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8192E )
    {
        //HalTxbf8192E_Leave(pDM_Odm, Idx);
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8814A )
    {
        //HalTxbf8814A_Leave(pDM_Odm, Idx);
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8821B )
    {
        //HalTxbf8821B_Leave(pDM_Odm, Idx);
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8822B )
    {
        //HalTxbf8822B_Leave(pDM_Odm, Idx);
    }
}



VOID
halComTxbf_FwNdpaWorkItemCallback (
    IN PVOID            pDM_VOID
)
{

    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;

    PHAL_TXBF_INFO  pTxbfInfo = &pDM_Odm->BeamformingInfo.TxbfInfo;
    u1Byte  Idx = pTxbfInfo->NdpaIdx;

    ODM_RT_TRACE ( pDM_Odm, PHYDM_COMP_TXBF, ODM_DBG_LOUD, ( "[%s] Start!\n", __func__ ) );

    if ( pDM_Odm->SupportICType & ( ODM_RTL8812 | ODM_RTL8821 ) )
    {
        HalTxbfJaguar_FwTxBF ( pDM_Odm, Idx );
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8192E )
    {
        //HalTxbf8192E_FwTxBF(pDM_Odm, Idx);
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8814A )
    {
        //HalTxbf8814A_FwTxBF(pDM_Odm, Idx);
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8821B )
    {
        //HalTxbf8821B_FwTxBF(pDM_Odm, Idx);
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8822B )
    {
        //HalTxbf8822B_FwTxBF(pDM_Odm, Idx);
    }
}




VOID
halComTxbf_ClkWorkItemCallback (

    IN PVOID            pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;

    ODM_RT_TRACE ( pDM_Odm, PHYDM_COMP_TXBF, ODM_DBG_LOUD, ( "[%s] Start!\n", __func__ ) );

    if ( pDM_Odm->SupportICType & ODM_RTL8812 )
    {
        HalTxbfJaguar_Clk_8812A ( pDM_Odm );
    }
}



VOID
halComTxbf_RateWorkItemCallback (
    IN PVOID            pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;

    PHAL_TXBF_INFO  pTxbfInfo = &pDM_Odm->BeamformingInfo.TxbfInfo;
    u1Byte          BW = pTxbfInfo->BW;
    u1Byte          Rate = pTxbfInfo->Rate;

    ODM_RT_TRACE ( pDM_Odm, PHYDM_COMP_TXBF, ODM_DBG_LOUD, ( "[%s] Start!\n", __func__ ) );

    if ( pDM_Odm->SupportICType & ODM_RTL8812 )
    {
        HalTxbf8812A_setNDPArate ( pDM_Odm, BW, Rate );
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8192E )
    {
        //HalTxbf8192E_setNDPArate(pDM_Odm, BW, Rate);
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8814A )
    {
        //HalTxbf8814A_setNDPArate(pDM_Odm, BW, Rate);
    }

}






VOID
halComTxbf_StatusWorkItemCallback (
    IN PVOID            pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;

    PHAL_TXBF_INFO  pTxbfInfo = &pDM_Odm->BeamformingInfo.TxbfInfo;

    u1Byte          Idx = pTxbfInfo->TXBFIdx;

    ODM_RT_TRACE ( pDM_Odm, PHYDM_COMP_TXBF, ODM_DBG_LOUD, ( "[%s] Start!\n", __func__ ) );

    if ( pDM_Odm->SupportICType & ( ODM_RTL8812 | ODM_RTL8821 ) )
    {
        HalTxbfJaguar_Status ( pDM_Odm, Idx );
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8192E )
    {
        //HalTxbf8192E_Status ( pDM_Odm, Idx );
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8814A )
    {
        //HalTxbf8814A_Status ( pDM_Odm, Idx );
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8821B )
    {
        //HalTxbf8821B_Status ( pDM_Odm, Idx );
    }
    else if ( pDM_Odm->SupportICType & ODM_RTL8822B )
    {
        //HalTxbf8822B_Status ( pDM_Odm, Idx );
    }
}



VOID
halComTxbf_ResetTxPathWorkItemCallback (
    IN PVOID            pDM_VOID
)
{

    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;
    PHAL_TXBF_INFO  pTxbfInfo = &pDM_Odm->BeamformingInfo.TxbfInfo;

    u1Byte          Idx = pTxbfInfo->TXBFIdx;

    if ( pDM_Odm->SupportICType & ODM_RTL8814A )
    {
        //HalTxbf8814A_ResetTxPath ( pDM_Odm, Idx );
    }

}




VOID
halComTxbf_GetTxRateWorkItemCallback (
    IN PVOID            pDM_VOID
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;

    if ( pDM_Odm->SupportICType & ODM_RTL8814A )
    {
        //HalTxbf8814A_GetTxRate ( pDM_Odm );
    }
}


BOOLEAN
HalComTxbf_Set (
    IN PVOID            pDM_VOID,
    IN  u1Byte          setType,
    IN  PVOID           pInBuf
)
{
    PDM_ODM_T   pDM_Odm = ( PDM_ODM_T ) pDM_VOID;
    PBOOLEAN        pBoolean = ( PBOOLEAN ) pInBuf;
    pu1Byte         pU1Tmp = ( pu1Byte ) pInBuf;
    pu4Byte         pU4Tmp = ( pu4Byte ) pInBuf;
    PHAL_TXBF_INFO  pTxbfInfo = &pDM_Odm->BeamformingInfo.TxbfInfo;

    ODM_RT_TRACE ( pDM_Odm, PHYDM_COMP_TXBF, ODM_DBG_LOUD, ( "[%s] setType = 0x%X\n", __func__, setType ) );

    switch ( setType )
    {
        case TXBF_SET_SOUNDING_ENTER:
            pTxbfInfo->TXBFIdx = *pU1Tmp;
            phydm_beamformSetSoundingEnter ( pDM_Odm );
            break;

        case TXBF_SET_SOUNDING_LEAVE:
            pTxbfInfo->TXBFIdx = *pU1Tmp;
            phydm_beamformSetSoundingLeave ( pDM_Odm );
            break;

        case TXBF_SET_SOUNDING_RATE:
            pTxbfInfo->BW = pU1Tmp[0];
            pTxbfInfo->Rate = pU1Tmp[1];
            phydm_beamformSetSoundingRate ( pDM_Odm );
            break;

        case TXBF_SET_SOUNDING_STATUS:
            pTxbfInfo->TXBFIdx = *pU1Tmp;
            phydm_beamformSetSoundingStatus ( pDM_Odm );
            break;

        case TXBF_SET_SOUNDING_FW_NDPA:
            pTxbfInfo->NdpaIdx = *pU1Tmp;
            phydm_beamformSetSoundingFwNdpa ( pDM_Odm );
            break;

        case TXBF_SET_SOUNDING_CLK:
            phydm_beamformSetSoundingClk ( pDM_Odm );
            break;

        case TXBF_SET_TX_PATH_RESET:
            pTxbfInfo->TXBFIdx = *pU1Tmp;
            phydm_beamformSetResetTxPath ( pDM_Odm );
            break;

        case TXBF_SET_GET_TX_RATE:
            phydm_beamformSetGetTxRate ( pDM_Odm );
            break;

    }

    return TRUE;
}

#endif


