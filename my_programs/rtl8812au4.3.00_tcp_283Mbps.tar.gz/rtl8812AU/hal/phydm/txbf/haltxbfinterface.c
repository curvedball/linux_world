


#include "../phydm_precomp.h"



#if (BEAMFORMING_SUPPORT == 1)


u4Byte
Beamforming_GetReportFrame(
    IN  PVOID           pDM_VOID,
    union recv_frame *precv_frame
)
{
    PDM_ODM_T               pDM_Odm = (PDM_ODM_T)pDM_VOID;
    u4Byte                  ret = _SUCCESS;
    PRT_BEAMFORMEE_ENTRY    pBeamformEntry = NULL;
    pu1Byte                 pframe = precv_frame->u.hdr.rx_data;
    u4Byte                  frame_len = precv_frame->u.hdr.len;
    pu1Byte                 TA;
    u1Byte                  Idx, offset;

    /*DBG_871X("beamforming_get_report_frame\n");*/

    /*Memory comparison to see if CSI report is the same with previous one*/
    TA = GetAddr2Ptr(pframe);
    pBeamformEntry = phydm_Beamforming_GetBFeeEntryByAddr(pDM_Odm, TA, &Idx);
    if(pBeamformEntry->BeamformEntryCap & BEAMFORMER_CAP_VHT_SU)
        offset = 31;        /*24+(1+1+3)+2  MAC header+(Category+ActionCode+MIMOControlField)+SNR(Nc=2)*/
    else if(pBeamformEntry->BeamformEntryCap & BEAMFORMER_CAP_HT_EXPLICIT)
        offset = 34;        /*24+(1+1+6)+2  MAC header+(Category+ActionCode+MIMOControlField)+SNR(Nc=2)*/
    else
        return ret;

    /*DBG_871X("%s MacId %d offset=%d\n", __FUNCTION__, pBeamformEntry->mac_id, offset);*/

    return ret;
}




BOOLEAN
SendFWHTNDPAPacket(
    IN  PVOID           pDM_VOID,
    IN  pu1Byte         RA,
    IN  CHANNEL_WIDTH   BW
)
{
    PDM_ODM_T               pDM_Odm = (PDM_ODM_T)pDM_VOID;
    PADAPTER                Adapter = pDM_Odm->Adapter;
    struct xmit_frame       *pmgntframe;
    struct pkt_attrib       *pattrib;
    struct rtw_ieee80211_hdr    *pwlanhdr;
    struct xmit_priv        *pxmitpriv = &(Adapter->xmitpriv);
    struct mlme_ext_priv    *pmlmeext = &Adapter->mlmeextpriv;
    struct mlme_ext_info    *pmlmeinfo = &(pmlmeext->mlmext_info);
    u1Byte  ActionHdr[4] = {ACT_CAT_VENDOR, 0x00, 0xe0, 0x4c};
    u1Byte  *pframe;
    u2Byte  *fctrl;
    u2Byte  duration = 0;
    u1Byte  aSifsTime = 0, NDPTxRate = 0, Idx = 0;
    PRT_BEAMFORMING_INFO    pBeamInfo = &(pDM_Odm->BeamformingInfo);
    PRT_BEAMFORMEE_ENTRY    pBeamformEntry = phydm_Beamforming_GetBFeeEntryByAddr(pDM_Odm, RA, &Idx);

    pmgntframe = alloc_mgtxmitframe(pxmitpriv);

    if (pmgntframe == NULL)
    {
        DBG_871X("%s, alloc mgnt frame fail\n", __func__);
        return _FALSE;
    }

    //update attribute
    pattrib = &pmgntframe->attrib;
    update_mgntframe_attrib(Adapter, pattrib);

    pattrib->qsel = QSLT_BEACON;
    NDPTxRate = Beamforming_GetHTNDPTxRate(pDM_Odm, pBeamformEntry->CompSteeringNumofBFer);
    ODM_RT_TRACE(pDM_Odm, PHYDM_COMP_TXBF, ODM_DBG_LOUD, ("[%s] NDPTxRate =%d\n", __func__, NDPTxRate));
    pattrib->rate = NDPTxRate;
    pattrib->bwmode = BW;
    pattrib->order = 1;
    pattrib->subtype = WIFI_ACTION_NOACK;

    _rtw_memset(pmgntframe->buf_addr, 0, WLANHDR_OFFSET + TXDESC_OFFSET);

    pframe = (u8 *)(pmgntframe->buf_addr) + TXDESC_OFFSET;

    pwlanhdr = (struct rtw_ieee80211_hdr*)pframe;

    fctrl = &pwlanhdr->frame_ctl;
    *(fctrl) = 0;

    SetOrderBit(pframe);
    SetFrameSubType(pframe, WIFI_ACTION_NOACK);

    _rtw_memcpy(pwlanhdr->addr1, RA, ETH_ALEN);
    _rtw_memcpy(pwlanhdr->addr2, pBeamformEntry->MyMacAddr, ETH_ALEN);
    _rtw_memcpy(pwlanhdr->addr3, get_my_bssid(&(pmlmeinfo->network)), ETH_ALEN);

    if( pmlmeext->cur_wireless_mode == WIRELESS_11B)
        aSifsTime = 10;
    else
        aSifsTime = 16;

    duration = 2*aSifsTime + 40;

    if(BW == CHANNEL_WIDTH_40)
        duration+= 87;
    else
        duration+= 180;

    SetDuration(pframe, duration);

    //HT control field
    SET_HT_CTRL_CSI_STEERING(pframe+24, 3);
    SET_HT_CTRL_NDP_ANNOUNCEMENT(pframe+24, 1);

    _rtw_memcpy(pframe+28, ActionHdr, 4);

    pattrib->pktlen = 32;

    pattrib->last_txcmdsz = pattrib->pktlen;

    dump_mgntframe(Adapter, pmgntframe);

    return _TRUE;
}


BOOLEAN
SendSWHTNDPAPacket(
    IN  PVOID           pDM_VOID,
    IN  pu1Byte         RA,
    IN  CHANNEL_WIDTH   BW
)
{
    PDM_ODM_T               pDM_Odm = (PDM_ODM_T)pDM_VOID;
    PADAPTER                Adapter = pDM_Odm->Adapter;
    struct xmit_frame       *pmgntframe;
    struct pkt_attrib       *pattrib;
    struct rtw_ieee80211_hdr    *pwlanhdr;
    struct xmit_priv        *pxmitpriv = &(Adapter->xmitpriv);
    struct mlme_ext_priv    *pmlmeext = &Adapter->mlmeextpriv;
    struct mlme_ext_info    *pmlmeinfo = &(pmlmeext->mlmext_info);
    u1Byte  ActionHdr[4] = {ACT_CAT_VENDOR, 0x00, 0xe0, 0x4c};
    pu1Byte pframe;
    pu2Byte fctrl;
    u2Byte  duration = 0;
    u1Byte  aSifsTime = 0, NDPTxRate = 0, Idx = 0;
    PRT_BEAMFORMING_INFO    pBeamInfo = &(pDM_Odm->BeamformingInfo);
    PRT_BEAMFORMEE_ENTRY    pBeamformEntry = phydm_Beamforming_GetBFeeEntryByAddr(pDM_Odm, RA, &Idx);

    NDPTxRate = Beamforming_GetHTNDPTxRate(pDM_Odm, pBeamformEntry->CompSteeringNumofBFer);

    pmgntframe = alloc_mgtxmitframe(pxmitpriv);

    if (pmgntframe == NULL)
    {
        DBG_871X("%s, alloc mgnt frame fail\n", __func__);
        return _FALSE;
    }

    /*update attribute*/
    pattrib = &pmgntframe->attrib;
    update_mgntframe_attrib(Adapter, pattrib);
    pattrib->qsel = QSLT_MGNT;
    pattrib->rate = NDPTxRate;
    pattrib->bwmode = BW;
    pattrib->order = 1;
    pattrib->subtype = WIFI_ACTION_NOACK;

    _rtw_memset(pmgntframe->buf_addr, 0, WLANHDR_OFFSET + TXDESC_OFFSET);

    pframe = (u8 *)(pmgntframe->buf_addr) + TXDESC_OFFSET;

    pwlanhdr = (struct rtw_ieee80211_hdr *)pframe;

    fctrl = &pwlanhdr->frame_ctl;
    *(fctrl) = 0;

    SetOrderBit(pframe);
    SetFrameSubType(pframe, WIFI_ACTION_NOACK);

    _rtw_memcpy(pwlanhdr->addr1, RA, ETH_ALEN);
    _rtw_memcpy(pwlanhdr->addr2, pBeamformEntry->MyMacAddr, ETH_ALEN);
    _rtw_memcpy(pwlanhdr->addr3, get_my_bssid(&(pmlmeinfo->network)), ETH_ALEN);

    if (pmlmeext->cur_wireless_mode == WIRELESS_11B)
        aSifsTime = 10;
    else
        aSifsTime = 16;

    duration = 2*aSifsTime + 40;

    if (BW == CHANNEL_WIDTH_40)
        duration += 87;
    else
        duration += 180;

    SetDuration(pframe, duration);

    /*HT control field*/
    SET_HT_CTRL_CSI_STEERING(pframe+24, 3);
    SET_HT_CTRL_NDP_ANNOUNCEMENT(pframe+24, 1);

    _rtw_memcpy(pframe+28, ActionHdr, 4);

    pattrib->pktlen = 32;

    pattrib->last_txcmdsz = pattrib->pktlen;

    dump_mgntframe(Adapter, pmgntframe);

    return _TRUE;
}


BOOLEAN
SendFWVHTNDPAPacket(
    IN  PVOID           pDM_VOID,
    IN  pu1Byte         RA,
    IN  u2Byte          AID,
    IN  CHANNEL_WIDTH   BW
)
{
    PDM_ODM_T               pDM_Odm = (PDM_ODM_T)pDM_VOID;
    PADAPTER                Adapter = pDM_Odm->Adapter;
    struct xmit_frame       *pmgntframe;
    struct pkt_attrib       *pattrib;
    struct rtw_ieee80211_hdr    *pwlanhdr;
    struct xmit_priv        *pxmitpriv = &(Adapter->xmitpriv);
    struct mlme_ext_priv    *pmlmeext = &Adapter->mlmeextpriv;
    struct mlme_ext_info    *pmlmeinfo = &(pmlmeext->mlmext_info);
    struct mlme_priv        *pmlmepriv = &(Adapter->mlmepriv);
    pu1Byte pframe;
    pu2Byte fctrl;
    u2Byte  duration = 0;
    u1Byte  sequence = 0, aSifsTime = 0, NDPTxRate= 0, Idx = 0;
    PRT_BEAMFORMING_INFO    pBeamInfo = &(pDM_Odm->BeamformingInfo);
    PRT_BEAMFORMEE_ENTRY    pBeamformEntry = phydm_Beamforming_GetBFeeEntryByAddr(pDM_Odm, RA, &Idx);
    RT_NDPA_STA_INFO    sta_info;

    pmgntframe = alloc_mgtxmitframe(pxmitpriv);

    if (pmgntframe == NULL)
    {
        DBG_871X("%s, alloc mgnt frame fail\n", __func__);
        return _FALSE;
    }

    //update attribute
    pattrib = &pmgntframe->attrib;
    _rtw_memcpy(pattrib->ra, RA, ETH_ALEN);
    update_mgntframe_attrib(Adapter, pattrib);

    pattrib->qsel = QSLT_BEACON;
    NDPTxRate = Beamforming_GetVHTNDPTxRate(pDM_Odm, pBeamformEntry->CompSteeringNumofBFer);
    ODM_RT_TRACE(pDM_Odm, PHYDM_COMP_TXBF, ODM_DBG_LOUD, ("[%s] NDPTxRate =%d\n", __func__, NDPTxRate));
    pattrib->rate = NDPTxRate;
    pattrib->bwmode = BW;
    pattrib->subtype = WIFI_NDPA;

    _rtw_memset(pmgntframe->buf_addr, 0, WLANHDR_OFFSET + TXDESC_OFFSET);

    pframe = (u8 *)(pmgntframe->buf_addr) + TXDESC_OFFSET;

    pwlanhdr = (struct rtw_ieee80211_hdr*)pframe;

    fctrl = &pwlanhdr->frame_ctl;
    *(fctrl) = 0;

    SetFrameSubType(pframe, WIFI_NDPA);

    _rtw_memcpy(pwlanhdr->addr1, RA, ETH_ALEN);
    _rtw_memcpy(pwlanhdr->addr2, pBeamformEntry->MyMacAddr, ETH_ALEN);

    if (IsSupported5G(pmlmeext->cur_wireless_mode) || IsSupportedHT(pmlmeext->cur_wireless_mode))
        aSifsTime = 16;
    else
        aSifsTime = 10;

    duration = 2*aSifsTime + 44;

    if(BW == CHANNEL_WIDTH_80)
        duration += 40;
    else if(BW == CHANNEL_WIDTH_40)
        duration+= 87;
    else
        duration+= 180;

    SetDuration(pframe, duration);

    sequence = pBeamInfo->SoundingSequence<< 2;
    if (pBeamInfo->SoundingSequence >= 0x3f)
        pBeamInfo->SoundingSequence = 0;
    else
        pBeamInfo->SoundingSequence++;

    _rtw_memcpy(pframe+16, &sequence,1);

    if (((pmlmeinfo->state&0x03) == WIFI_FW_ADHOC_STATE) || ((pmlmeinfo->state&0x03) == WIFI_FW_AP_STATE))
        AID = 0;

    sta_info.AID = AID;
    sta_info.FeedbackType = 0;
    sta_info.NcIndex= 0;

    _rtw_memcpy(pframe+17, (u8 *)&sta_info, 2);

    pattrib->pktlen = 19;

    pattrib->last_txcmdsz = pattrib->pktlen;

    dump_mgntframe(Adapter, pmgntframe);

    return _TRUE;
}



BOOLEAN
SendSWVHTNDPAPacket(
    IN  PVOID           pDM_VOID,
    IN  pu1Byte         RA,
    IN  u2Byte          AID,
    IN  CHANNEL_WIDTH   BW
)
{
    PDM_ODM_T               pDM_Odm = (PDM_ODM_T)pDM_VOID;
    PADAPTER                Adapter = pDM_Odm->Adapter;
    struct xmit_frame       *pmgntframe;
    struct pkt_attrib       *pattrib;
    struct rtw_ieee80211_hdr    *pwlanhdr;
    struct xmit_priv        *pxmitpriv = &(Adapter->xmitpriv);
    struct mlme_ext_priv    *pmlmeext = &Adapter->mlmeextpriv;
    struct mlme_ext_info    *pmlmeinfo = &(pmlmeext->mlmext_info);
    struct mlme_priv        *pmlmepriv = &(Adapter->mlmepriv);
    RT_NDPA_STA_INFO    ndpa_sta_info;
    u1Byte  NDPTxRate = 0, sequence = 0, aSifsTime = 0, Idx = 0;
    pu1Byte pframe;
    pu2Byte fctrl;
    u2Byte  duration = 0;
    PRT_BEAMFORMING_INFO    pBeamInfo = &(pDM_Odm->BeamformingInfo);
    PRT_BEAMFORMEE_ENTRY    pBeamformEntry = phydm_Beamforming_GetBFeeEntryByAddr(pDM_Odm, RA, &Idx);

    NDPTxRate = Beamforming_GetVHTNDPTxRate(pDM_Odm, pBeamformEntry->CompSteeringNumofBFer);
    ODM_RT_TRACE(pDM_Odm, PHYDM_COMP_TXBF, ODM_DBG_LOUD, ("[%s] NDPTxRate =%d\n", __func__, NDPTxRate));

    pmgntframe = alloc_mgtxmitframe(pxmitpriv);

    if (pmgntframe == NULL)
    {
        DBG_871X("%s, alloc mgnt frame fail\n", __func__);
        return _FALSE;
    }

    /*update attribute*/
    pattrib = &pmgntframe->attrib;
    _rtw_memcpy(pattrib->ra, RA, ETH_ALEN);
    update_mgntframe_attrib(Adapter, pattrib);
    pattrib->qsel = QSLT_MGNT;
    pattrib->rate = NDPTxRate;
    pattrib->bwmode = BW;
    pattrib->subtype = WIFI_NDPA;

    _rtw_memset(pmgntframe->buf_addr, 0, WLANHDR_OFFSET + TXDESC_OFFSET);

    pframe = (u8 *)(pmgntframe->buf_addr) + TXDESC_OFFSET;

    pwlanhdr = (struct rtw_ieee80211_hdr *)pframe;

    fctrl = &pwlanhdr->frame_ctl;
    *(fctrl) = 0;

    SetFrameSubType(pframe, WIFI_NDPA);

    _rtw_memcpy(pwlanhdr->addr1, RA, ETH_ALEN);
    _rtw_memcpy(pwlanhdr->addr2, pBeamformEntry->MyMacAddr, ETH_ALEN);

    if (IsSupported5G(pmlmeext->cur_wireless_mode) || IsSupportedHT(pmlmeext->cur_wireless_mode))
        aSifsTime = 16;
    else
        aSifsTime = 10;

    duration = 2*aSifsTime + 44;

    if (BW == CHANNEL_WIDTH_80)
        duration += 40;
    else if (BW == CHANNEL_WIDTH_40)
        duration += 87;
    else
        duration += 180;

    SetDuration(pframe, duration);

    sequence = pBeamInfo->SoundingSequence << 2;
    if (pBeamInfo->SoundingSequence >= 0x3f)
        pBeamInfo->SoundingSequence = 0;
    else
        pBeamInfo->SoundingSequence++;

    _rtw_memcpy(pframe+16, &sequence, 1);
    if (((pmlmeinfo->state&0x03) == WIFI_FW_ADHOC_STATE) || ((pmlmeinfo->state&0x03) == WIFI_FW_AP_STATE))
        AID = 0;

    ndpa_sta_info.AID = AID;
    ndpa_sta_info.FeedbackType = 0;
    ndpa_sta_info.NcIndex = 0;

    _rtw_memcpy(pframe+17, (u8 *)&ndpa_sta_info, 2);

    pattrib->pktlen = 19;

    pattrib->last_txcmdsz = pattrib->pktlen;

    dump_mgntframe(Adapter, pmgntframe);
    ODM_RT_TRACE(pDM_Odm, PHYDM_COMP_TXBF, ODM_DBG_LOUD, ("[%s] [%d]\n", __func__, __LINE__));

    return _TRUE;
}





VOID
Beamforming_GetNDPAFrame(
    IN  PVOID           pDM_VOID,
    union recv_frame *precv_frame

)
{
    PDM_ODM_T                   pDM_Odm = (PDM_ODM_T)pDM_VOID;
    PADAPTER                    Adapter = pDM_Odm->Adapter;
    pu1Byte                     TA ;
    u1Byte                      Idx, Sequence;

    pu1Byte                     pNDPAFrame = precv_frame->u.hdr.rx_data;

    PRT_BEAMFORMER_ENTRY        pBeamformerEntry = NULL;        /*Modified By Jeffery @2014-10-29*/



    if (GetFrameSubType(pNDPAFrame) != WIFI_NDPA)
        return;
    else if (!(pDM_Odm->SupportICType & (ODM_RTL8812 | ODM_RTL8821)))
    {
        ODM_RT_TRACE(pDM_Odm, PHYDM_COMP_TXBF, ODM_DBG_LOUD, ("[%s] not 8812 or 8821A, return\n", __func__));
        return;
    }

    TA = GetAddr2Ptr(pNDPAFrame);

    /*Remove signaling TA. */
    TA[0] = TA[0] & 0xFE;

    pBeamformerEntry = phydm_Beamforming_GetBFerEntryByAddr(pDM_Odm, TA, &Idx);     // Modified By Jeffery @2014-10-29

    /*Break options for Clock Reset*/
    if (pBeamformerEntry == NULL)
        return;
    else if (!(pBeamformerEntry->BeamformEntryCap & BEAMFORMEE_CAP_VHT_SU))
        return;
    /*LogSuccess: As long as 8812A receive NDPA and feedback CSI succeed once, clock reset is NO LONGER needed !2015-04-10, Jeffery*/
    /*ClockResetTimes: While BFer entry always doesn't receive our CSI, clock will reset again and again.So ClockResetTimes is limited to 5 times.2015-04-13, Jeffery*/
    else if ((pBeamformerEntry->LogSuccess == 1) || (pBeamformerEntry->ClockResetTimes == 5))
    {
        ODM_RT_TRACE(pDM_Odm, PHYDM_COMP_TXBF, ODM_DBG_LOUD, ("[%s] LogSeq=%d, PreLogSeq=%d, LogRetryCnt=%d, LogSuccess=%d, ClockResetTimes=%d, clock reset is no longer needed.\n",
                     __func__, pBeamformerEntry->LogSeq, pBeamformerEntry->PreLogSeq, pBeamformerEntry->LogRetryCnt, pBeamformerEntry->LogSuccess, pBeamformerEntry->ClockResetTimes));

        return;
    }

    Sequence = (pNDPAFrame[16]) >> 2;

    ODM_RT_TRACE(pDM_Odm, PHYDM_COMP_TXBF, ODM_DBG_LOUD, ("[%s] Start, Sequence=%d, LogSeq=%d, PreLogSeq=%d, LogRetryCnt=%d, ClockResetTimes=%d, LogSuccess=%d\n",
                 __func__, Sequence, pBeamformerEntry->LogSeq, pBeamformerEntry->PreLogSeq, pBeamformerEntry->LogRetryCnt, pBeamformerEntry->ClockResetTimes, pBeamformerEntry->LogSuccess));

    if ((pBeamformerEntry->LogSeq != 0) && (pBeamformerEntry->PreLogSeq != 0))
    {
        /*Success condition*/
        if ((pBeamformerEntry->LogSeq != Sequence) && (pBeamformerEntry->PreLogSeq != pBeamformerEntry->LogSeq))
        {
            /* break option for clcok reset, 2015-03-30, Jeffery */
            pBeamformerEntry->LogRetryCnt = 0;
            /*As long as 8812A receive NDPA and feedback CSI succeed once, clock reset is no longer needed.*/
            /*That is, LogSuccess is NOT needed to be reset to zero, 2015-04-13, Jeffery*/
            pBeamformerEntry->LogSuccess = 1;

        }
        else    /*Fail condition*/
        {

            if (pBeamformerEntry->LogRetryCnt == 5)
            {
                pBeamformerEntry->ClockResetTimes++;
                pBeamformerEntry->LogRetryCnt = 0;

                ODM_RT_TRACE(pDM_Odm, PHYDM_COMP_TXBF, ODM_DBG_LOUD, ("[%s] Clock Reset!!! ClockResetTimes=%d\n",
                             __func__, pBeamformerEntry->ClockResetTimes));
                HalComTxbf_Set(pDM_Odm, TXBF_SET_SOUNDING_CLK, NULL);

            }
            else
                pBeamformerEntry->LogRetryCnt++;
        }
    }

    /*Update LogSeq & PreLogSeq*/
    pBeamformerEntry->PreLogSeq = pBeamformerEntry->LogSeq;
    pBeamformerEntry->LogSeq = Sequence;

}



#endif


