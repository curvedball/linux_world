


#include "phydm_precomp.h"



VOID
odm_DynamicTxPowerInit(
    IN      PVOID                   pDM_VOID
)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
}




VOID
odm_DynamicTxPowerSavePowerIndex(
    IN      PVOID                   pDM_VOID
)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;

    u1Byte      index;
    u4Byte      Power_Index_REG[6] = {0xc90, 0xc91, 0xc92, 0xc98, 0xc99, 0xc9a};
}




VOID
odm_DynamicTxPowerRestorePowerIndex(
    IN      PVOID                   pDM_VOID
)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;

    u1Byte          index;
    PADAPTER        Adapter = pDM_Odm->Adapter;
    HAL_DATA_TYPE   *pHalData = GET_HAL_DATA(Adapter);
    u4Byte          Power_Index_REG[6] = {0xc90, 0xc91, 0xc92, 0xc98, 0xc99, 0xc9a};
}




VOID
odm_DynamicTxPowerWritePowerIndex(
    IN      PVOID                   pDM_VOID,
    IN  u1Byte      Value)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
    u1Byte          index;
    u4Byte          Power_Index_REG[6] = {0xc90, 0xc91, 0xc92, 0xc98, 0xc99, 0xc9a};

    for(index = 0; index< 6; index++)
        //PlatformEFIOWrite1Byte(Adapter, Power_Index_REG[index], Value);
        ODM_Write1Byte(pDM_Odm, Power_Index_REG[index], Value);

}



VOID
odm_DynamicTxPower(
    IN      PVOID                   pDM_VOID
)
{
    //
    // For AP/ADSL use prtl8192cd_priv
    // For CE/NIC use PADAPTER
    //
    //PADAPTER      pAdapter = pDM_Odm->Adapter;
//  prtl8192cd_priv priv        = pDM_Odm->priv;
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
    if (!(pDM_Odm->SupportAbility & ODM_BB_DYNAMIC_TXPWR))
        return;
    //
    // 2011/09/29 MH In HW integration first stage, we provide 4 different handle to operate
    // at the same time. In the stage2/3, we need to prive universal interface and merge all
    // HW dynamic mechanism.
    //
    switch  (pDM_Odm->SupportPlatform)
    {
        case    ODM_WIN:
        case    ODM_CE:
            odm_DynamicTxPowerNIC(pDM_Odm);
            break;
        case    ODM_AP:
            odm_DynamicTxPowerAP(pDM_Odm);
            break;

        case    ODM_ADSL:
            //odm_DIGAP(pDM_Odm);
            break;
    }


}




VOID
odm_DynamicTxPowerNIC(
    IN      PVOID                   pDM_VOID
)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;

    if (!(pDM_Odm->SupportAbility & ODM_BB_DYNAMIC_TXPWR))
        return;



    if(pDM_Odm->SupportICType == ODM_RTL8192C)
    {
        odm_DynamicTxPower_92C(pDM_Odm);
    }
    else if(pDM_Odm->SupportICType == ODM_RTL8192D)
    {
        odm_DynamicTxPower_92D(pDM_Odm);
    }
    else if (pDM_Odm->SupportICType == ODM_RTL8821)
    {

    }

}





VOID
odm_DynamicTxPowerAP(
    IN      PVOID                   pDM_VOID

)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
}





VOID
odm_DynamicTxPower_92C(
    IN      PVOID                   pDM_VOID
)
{
    PDM_ODM_T       pDM_Odm = (PDM_ODM_T)pDM_VOID;
}





VOID
odm_DynamicTxPower_92D(
    IN      PVOID                   pDM_VOID
)
{

}




VOID
odm_DynamicTxPower_8821(
    IN      PVOID           pDM_VOID,
    IN      pu1Byte         pDesc,
    IN      u1Byte          macId
)
{

}




