


#ifndef	__ODM_PRECOMP_H__
#define __ODM_PRECOMP_H__



#include "phydm_types.h"


#define		TEST_FALG___		1



#define 	RTL8192CE_SUPPORT 				0
#define 	RTL8192CU_SUPPORT 				0
#define 	RTL8192C_SUPPORT 				0	

#define 	RTL8192DE_SUPPORT 				0
#define 	RTL8192DU_SUPPORT 				0
#define 	RTL8192D_SUPPORT 				0	

#define 	RTL8723AU_SUPPORT				0
#define 	RTL8723AS_SUPPORT				0
#define 	RTL8723AE_SUPPORT				0
#define 	RTL8723A_SUPPORT				0
#define 	RTL8723_FPGA_VERIFICATION		0



//2 Config Flags and Structs - defined by each ODM Type


#define __PACK
#define __WLAN_ATTRIB_PACK__


//2 OutSrc Header Files
 
#include "phydm.h" 
#include "phydm_hwconfig.h"
#include "phydm_debug.h"
#include "phydm_regdefine11ac.h"
#include "phydm_regdefine11n.h"
#include "phydm_interface.h"
#include "phydm_reg.h"



#define RTL8821B_SUPPORT		0
#define RTL8822B_SUPPORT		0



VOID
PHY_SetTxPowerLimit(
	IN	PDM_ODM_T	pDM_Odm,
	IN	u8	*Regulation,
	IN	u8	*Band,
	IN	u8	*Bandwidth,
	IN	u8	*RateSection,
	IN	u8	*RfPath,
	IN	u8	*Channel,
	IN	u8	*PowerLimit
);

    #include "rtl8812a/halphyrf_8812a_ce.h"
    #include "rtl8812a/halhwimg8812a_bb.h"
    #include "rtl8812a/halhwimg8812a_mac.h"
    #include "rtl8812a/halhwimg8812a_rf.h"
    #include "rtl8812a/phydm_regconfig8812a.h"
    #include "rtl8812a/halhwimg8812a_fw.h"
    //#include "rtl8812a/phydm_rtl8812a.h"
    #include "rtl8812a_hal.h"

#endif	// __ODM_PRECOMP_H__



