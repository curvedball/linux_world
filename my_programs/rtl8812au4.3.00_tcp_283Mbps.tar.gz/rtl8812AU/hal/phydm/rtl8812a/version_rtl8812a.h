

//RTL8812A PHY Parameters

#define RELEASE_DATE_8812A      20150602

#define COMMIT_BY_8192E         "BB_Jeffery"


#define RELEASE_VERSION_8812A       55



