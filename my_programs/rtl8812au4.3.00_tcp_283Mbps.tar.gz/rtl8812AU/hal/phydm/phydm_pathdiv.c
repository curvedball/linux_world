


#include "phydm_precomp.h"




VOID
phydm_c2h_dtp_handler(
    IN PVOID   pDM_VOID,
    IN     pu1Byte   CmdBuf,
    IN     u1Byte  CmdLen
)
{

}



VOID
odm_PathDiversity(
    IN  PVOID   pDM_VOID
)
{

}




VOID
odm_PathDiversityInit(
    IN  PVOID   pDM_VOID
)
{

}



