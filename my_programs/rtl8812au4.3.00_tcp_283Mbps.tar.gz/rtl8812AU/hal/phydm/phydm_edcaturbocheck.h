



#ifndef __PHYDMEDCATURBOCHECK_H__
#define    __PHYDMEDCATURBOCHECK_H__



#define EDCATURBO_VERSION   "2.2"   /*2015.01.13*/


typedef struct _EDCA_TURBO_
{
    BOOLEAN bCurrentTurboEDCA;
    BOOLEAN bIsCurRDLState;
	
    u4Byte  prv_traffic_idx; // edca turbo
} EDCA_T,*pEDCA_T;




static u4Byte edca_setting_UL[HT_IOT_PEER_MAX] =
// UNKNOWN      REALTEK_90  REALTEK_92SE    BROADCOM        RALINK      ATHEROS     CISCO       MERU        MARVELL 92U_AP      SELF_AP(DownLink/Tx)
{ 0x5e4322,         0xa44f,         0x5e4322,       0x5ea32b,       0x5ea422,   0x5ea322,   0x3ea430,   0x5ea42b, 0x5ea44f, 0x5e4322,   0x5e4322};




static u4Byte edca_setting_DL[HT_IOT_PEER_MAX] =
// UNKNOWN      REALTEK_90  REALTEK_92SE    BROADCOM        RALINK      ATHEROS     CISCO       MERU,       MARVELL 92U_AP      SELF_AP(UpLink/Rx)
{ 0xa44f,       0x5ea44f,   0x5e4322,       0x5ea42b,       0xa44f,         0xa630,         0x5ea630,   0x5ea42b, 0xa44f,       0xa42b,     0xa42b};



static u4Byte edca_setting_DL_GMode[HT_IOT_PEER_MAX] =
// UNKNOWN      REALTEK_90  REALTEK_92SE    BROADCOM        RALINK      ATHEROS     CISCO       MERU,       MARVELL 92U_AP      SELF_AP
{ 0x4322,       0xa44f,         0x5e4322,       0xa42b,             0x5e4322,   0x4322,         0xa42b,     0x5ea42b, 0xa44f,       0x5e4322,   0x5ea42b};





VOID
odm_EdcaTurboCheck(
    IN  PVOID       pDM_VOID
);
VOID
ODM_EdcaTurboInit(
    IN  PVOID       pDM_VOID
);



VOID
odm_EdcaTurboCheckCE(
    IN  PVOID       pDM_VOID
);


#endif




