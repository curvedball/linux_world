


#ifndef __COMMON_C2H_H__
#define __COMMON_C2H_H__



typedef enum _C2H_EVT
{
    C2H_DBG = 0x00,
    C2H_LB = 0x01,
    C2H_TXBF = 0x02,
    C2H_CCX_TX_RPT = 0x03,
    C2H_BT_INFO = 0x09,
    C2H_BT_MP_INFO = 0x0B,
    C2H_RA_RPT = 0x0C,
    C2H_RA_PARA_RPT = 0x0E,
    C2H_FW_SWCHNL = 0x10,
    C2H_IQK_FINISH = 0x11,
    C2H_MAILBOX_STATUS = 0x15,
    C2H_P2P_RPORT = 0x16,
    C2H_EXTEND = 0xff,
} C2H_EVT;




typedef enum _EXTEND_C2H_EVT
{
    EXTEND_C2H_DBG_PRINT = 0
} EXTEND_C2H_EVT;



#endif /* __COMMON_C2H_H__ */




