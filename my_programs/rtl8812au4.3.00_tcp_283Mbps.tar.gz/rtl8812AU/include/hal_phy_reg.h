


#ifndef __HAL_PHY_REG_H__
#define __HAL_PHY_REG_H__



#define         bRFRegOffsetMask    0xfffff


#endif //__HAL_PHY_REG_H__




