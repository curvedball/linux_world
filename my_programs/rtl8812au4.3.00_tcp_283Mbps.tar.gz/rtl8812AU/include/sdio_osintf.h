


#ifndef __SDIO_OSINTF_H__
#define __SDIO_OSINTF_H__


u8 sd_hal_bus_init(PADAPTER padapter);
u8 sd_hal_bus_deinit(PADAPTER padapter);
void sd_c2h_hdl(PADAPTER padapter);


#endif



