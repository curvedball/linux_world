

//
//#define CONFIG_WIFI_MONITOR


//------------------------------------------------------------------------------
//#define CONFIG_SINGLE_IMG
//#define AUTOCONF_INCLUDED


#define USE_OUR_SOLUTION   1



//
#define ZB2_PRINT 		0

//
#define ZB2_TCP_HANDSHAKE_PRINT 		1

//
#define ZB2_PROCESS_PKT_PRINT 		0





#define RTL871X_MODULE_NAME "8812AU"
#define DRV_NAME "rtl8812au"


#define CONFIG_USB_HCI  1
#define PLATFORM_LINUX  1




//------------------------------------------------------------------------------
//#ifdef CONFIG_IOCTL_CFG80211
//#define CONFIG_CFG80211_FORCE_COMPATIBLE_2_6_37_UNDER
//#define CONFIG_SET_SCAN_DENY_TIMER
//#endif



#define CONFIG_EMBEDDED_FWIMG   1



#define CONFIG_XMIT_ACK   //zbgcl

#ifdef CONFIG_XMIT_ACK
#define CONFIG_ACTIVE_KEEP_ALIVE_CHECK
#endif


//#define CONFIG_AUTO_AP_MODE



//------------------------------------------------------------------------------
#define CONFIG_80211N_HT    1



#ifdef CONFIG_80211N_HT
#define CONFIG_80211AC_VHT 1
#define CONFIG_BEAMFORMING

//------------
#ifdef CONFIG_BEAMFORMING
#define CONFIG_BEAMFORMER_FW_NDPA
#define CONFIG_PHYDM_BEAMFORMING

#ifdef CONFIG_PHYDM_BEAMFORMING
#define BEAMFORMING_SUPPORT     1   /*for phydm beamforming*/
#define SUPPORT_MU_BF           0
#else
#define BEAMFORMING_SUPPORT     0   /*for driver beamforming*/
#endif

#endif
//------------


#endif




//------------------------------------------------------------------------------
#define CONFIG_RECV_REORDERING_CTRL 1
//#define CONFIG_DFS  1


//#define CONFIG_IPS  1
//#ifdef CONFIG_IPS
//#define CONFIG_IPS_CHECK_IN_WD // Do IPS Check in WatchDog. 
//#endif

//#define CONFIG_LPS  1


//------------------------------------------------------------------------------
#define CONFIG_AP_MODE  1

#ifdef CONFIG_AP_MODE
#define CONFIG_NATIVEAP_MLME
//#define CONFIG_FIND_BEST_CHANNEL    1
#endif


#define BT_30_SUPPORT 0
#define CONFIG_SKB_COPY 1//for amsdu



#define CONFIG_LED

#ifdef CONFIG_LED
#define CONFIG_SW_LED
#endif // CONFIG_LED



#define USB_INTERFERENCE_ISSUE // this should be checked in all usb interface
#define CONFIG_GLOBAL_UI_PID


//#define CONFIG_LAYER2_ROAMING
//#define CONFIG_LAYER2_ROAMING_RESUME

#define CONFIG_LONG_DELAY_ISSUE
#define CONFIG_NEW_SIGNAL_STAT_PROCESS


#define RTW_NOTCH_FILTER 	0    	/* 0:Disable, 1:Enable, */
#define CONFIG_TX_MCAST2UNI      	/*Support IP multicast->unicast*/



//------------------------------------------------------------------------------
#define CONFIG_USB_TX_AGGREGATION   1
#define CONFIG_USB_RX_AGGREGATION   1


#define CONFIG_PREALLOC_RECV_SKB
#define CONFIG_USB_VENDOR_REQ_BUFFER_PREALLOC
#define CONFIG_USB_VENDOR_REQ_MUTEX
#define CONFIG_VENDOR_REQ_RETRY


#define RTL8812A_RX_PACKET_INCLUDE_CRC  	0
#define CONFIG_RX_PACKET_APPEND_FCS


#define CONFIG_OUT_EP_WIFI_MODE 	0
#define ENABLE_USB_DROP_INCORRECT_OUT
#define CONFIG_ADHOC_WORKAROUND_SETTING 	0 //zb
#define ENABLE_NEW_RFE_TYPE 	0
#define DISABLE_BB_RF   	0
#define MP_DRIVER 		0


#define RTL8188E_EARLY_MODE_PKT_NUM_10  		0
#define CONFIG_80211D
#define CONFIG_ATTEMPT_TO_FIX_AP_BEACON_ERROR


#define DBG 0





