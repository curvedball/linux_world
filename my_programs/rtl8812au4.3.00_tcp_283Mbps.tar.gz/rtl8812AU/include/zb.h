


#ifndef __ZB_H_
#define __ZB_H_



//#include <osdep_service_linux.h>
//#include <rtw_xmit.h>

#include <rtl8812a_hal.h>


//
#define ZB_DBG_PRINT 	0



#define ZB_BLOCK_ACK_PRINT 0


#define TARGET_PKT_SEQ 	50000000


//
void DbgPrintCtrlFrame(u8* p, int len);
void DbgPrintC2H_Frame(u8* p, int len);


//============================================================
bool IsAPMacAddress(_pkt* pkt);
bool IsSTAMacAddress(_pkt* pkt);


//============================================================
bool IsTcpHandshakeSynPkt(_pkt* pkt);
bool IsTcpHandshakeSynAckPkt(_pkt* pkt);
bool IsTcpHandshakeAckPkt(_pkt* pkt);


//
bool IsTcpDataPushAckPkt(_pkt* pkt);
bool IsTcpDataAckPkt(_pkt* pkt);



//
void SaveTcpInfoAndMacSeqNumber(_adapter *padapter, _pkt* pkt, u16 macSeqNumber);
void SaveTcpWndSize(_adapter *padapter, u32 wndSize);


//
void SaveTcpInfoToList(_adapter *padapter, _pkt* pkt, u16 macSeqNumber);
void SimpleProcess(_adapter *padapter, u32 num);




bool ApFindTcpFlowTraceByMacSeq(_adapter *padapter, u16 macSeqNumber, u32* pIndex);
bool ApFindTcpFlowTraceByTcpSeq(_adapter *padapter, u32 tcpSeqNumber, u32* pIndex);






//
bool ApIsBlockAckPkt(u8* p, int len);





void ApProcessFirstTransmitOkPkt(_adapter *padapter, u32 index);
void ApProcessRetransmitOkPkt(_adapter *padapter, u32 index);
void ApProcessDataTransmitOkPkt(_adapter *padapter, u32 index);





//========================================================
bool ApIsTcpAckPkt(_pkt* pkt);


void PutWndSizeToStaMacAddressField(_adapter *padapter, u16 wndSize);





//===========
void ApDoRecvBlockAck(_adapter *padapter, u8* pframe, uint len);




bool ApModifyTcpAckPkt(_adapter *padapter, _pkt* pkt);



bool StaIsTcpAckPkt(_pkt* pkt);
bool StaIsBlockAckPkt(u8* p, int len);
void StaDoRecvBlockAck(_adapter *padapter, u8* pframe, uint len);


//=============================================================================
//================================ NEW PROCESS  ===============================
//=============================================================================

void ApResetTcpInfoArray(_adapter *padapter);
void SaveBitmap(u8* p, u8* bitmap);
void ApProcessOnePkt(_adapter *padapter, u32 curPos);


void ApSaveTcpInfoToArray(_adapter *padapter, _pkt* pkt, u16 macSeqNumber);

void ApProcessBlockAckPkt(_adapter *padapter, u8* pframe, uint len);


#endif


