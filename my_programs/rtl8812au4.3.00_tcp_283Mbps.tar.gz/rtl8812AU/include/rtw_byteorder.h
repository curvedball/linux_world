


#ifndef _RTL871X_BYTEORDER_H_
#define _RTL871X_BYTEORDER_H_


#include <byteorder/little_endian.h>


#endif /* _RTL871X_BYTEORDER_H_ */



