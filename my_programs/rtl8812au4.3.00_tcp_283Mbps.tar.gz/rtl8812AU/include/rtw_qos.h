

#ifndef _RTW_QOS_H_
#define _RTW_QOS_H_


struct  qos_priv
{

    unsigned int      qos_option;   //bit mask option: u-apsd, s-apsd, ts, block ack...

};


#endif



