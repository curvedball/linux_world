

#ifndef __HAL_IC_CFG_H__
#define __HAL_IC_CFG_H__



#define RTL8188E_SUPPORT                0


//
#define RTL8812A_SUPPORT                0  


#define RTL8821A_SUPPORT                0
#define RTL8723B_SUPPORT                0
#define RTL8192E_SUPPORT                0
#define RTL8814A_SUPPORT                0
#define RTL8195A_SUPPORT                0
#define RTL8703B_SUPPORT                0
#define RTL8188F_SUPPORT                0
#define RTL8822B_SUPPORT                0
#define RTL8821B_SUPPORT                0


#define RATE_ADAPTIVE_SUPPORT           0
#define POWER_TRAINING_ACTIVE           0


#ifdef CONFIG_RTL8812A
#undef RTL8812A_SUPPORT
#define RTL8812A_SUPPORT                1
#endif


#endif /*__HAL_IC_CFG_H__*/



