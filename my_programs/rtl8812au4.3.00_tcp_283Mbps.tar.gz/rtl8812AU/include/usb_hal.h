

#ifndef __USB_HAL_H__
#define __USB_HAL_H__


int usb_init_recv_priv(_adapter *padapter, u16 ini_in_buf_sz);
void usb_free_recv_priv (_adapter *padapter, u16 ini_in_buf_sz);

u8 rtw_set_hal_ops(_adapter *padapter);


#if defined(CONFIG_RTL8812A)
void rtl8812au_set_hal_ops(_adapter * padapter);
#endif



#endif //__USB_HAL_H__



