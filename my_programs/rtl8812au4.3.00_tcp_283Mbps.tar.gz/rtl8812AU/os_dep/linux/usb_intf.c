
#define _HCI_INTF_C_


#include <drv_types.h>
#include <hal_data.h>
#include <platform_ops.h>
#include <zb.h>
//#include <linux/list.h>



#ifdef CONFIG_80211N_HT
extern int rtw_ht_enable;
extern int rtw_bw_mode;
extern int rtw_ampdu_enable;//for enable tx_ampdu
#endif


#ifdef CONFIG_GLOBAL_UI_PID
int ui_pid[3] = {0, 0, 0};
#endif


extern int pm_netdev_open(struct net_device *pnetdev,u8 bnormal);
static int rtw_suspend(struct usb_interface *intf, pm_message_t message);
static int rtw_resume(struct usb_interface *intf);


static int rtw_dev_probe(struct usb_interface *pusb_intf,const struct usb_device_id *pdid);
static void rtw_dev_remove(struct usb_interface *pusb_intf);




static void rtw_dev_shutdown(struct device *dev)
{
    struct usb_interface *usb_intf = container_of(dev, struct usb_interface, dev);
    struct dvobj_priv *dvobj = NULL;
    _adapter *adapter = NULL;
    int i;

    DBG_871X("%s\n", __func__);

    if(usb_intf)
    {
        dvobj = usb_get_intfdata(usb_intf);
        if (dvobj)
        {
            rtw_set_surprise_removed(dvobj->padapters[IFACE_ID0]);
            ATOMIC_SET(&dvobj->continual_io_error, MAX_CONTINUAL_IO_ERR+1);
        }
    }
}



#define USB_VENDER_ID_REALTEK       0x0BDA




static struct usb_device_id rtw_usb_id_tbl[] =
{
#ifdef CONFIG_RTL8812A
    /*=== Realtek demoboard ===*/
    {USB_DEVICE(USB_VENDER_ID_REALTEK, 0x8812),.driver_info = RTL8812},/* Default ID */
    {USB_DEVICE(USB_VENDER_ID_REALTEK, 0x881A),.driver_info = RTL8812},/* Default ID */
    {USB_DEVICE(USB_VENDER_ID_REALTEK, 0x881B),.driver_info = RTL8812},/* Default ID */
    {USB_DEVICE(USB_VENDER_ID_REALTEK, 0x881C),.driver_info = RTL8812},/* Default ID */
    
    /*=== Customer ID ===*/
    {USB_DEVICE(0x0409, 0x0408),.driver_info = RTL8812}, /* NEC - */
    {USB_DEVICE(0x04BB, 0x0952),.driver_info = RTL8812}, /* I-O DATA - Edimax */
    {USB_DEVICE(0x050D, 0x1106),.driver_info = RTL8812}, /* Belkin - sercomm */
    {USB_DEVICE(0x050D, 0x1109),.driver_info = RTL8812}, /* Belkin F9L1109 - SerComm */
    {USB_DEVICE(0x0586, 0x3426),.driver_info = RTL8812}, /* ZyXEL - */
    {USB_DEVICE(0x0789, 0x016E),.driver_info = RTL8812}, /* Logitec - Edimax */
    {USB_DEVICE(0x07B8, 0x8812),.driver_info = RTL8812}, /* Abocom - Abocom */
    {USB_DEVICE(0x0B05, 0x17D2),.driver_info = RTL8812}, /* ASUS - Edimax */
    {USB_DEVICE(0x0DF6, 0x0074),.driver_info = RTL8812}, /* Sitecom - Edimax */
    {USB_DEVICE(0x0E66, 0x0022),.driver_info = RTL8812}, /* HAWKING - Edimax */
    {USB_DEVICE(0x1058, 0x0632),.driver_info = RTL8812}, /* WD - Cybertan*/
    {USB_DEVICE(0x13B1, 0x003F),.driver_info = RTL8812}, /* Linksys WUSB6300 */
    {USB_DEVICE(0x148F, 0x9097),.driver_info = RTL8812}, /* Amped Wireless ACA1 */
    {USB_DEVICE(0x1740, 0x0100),.driver_info = RTL8812}, /* EnGenius - EnGenius */
    {USB_DEVICE(0x2001, 0x330E),.driver_info = RTL8812}, /* D-Link - ALPHA */
    {USB_DEVICE(0x2001, 0x3313),.driver_info = RTL8812}, /* D-Link - ALPHA */
    {USB_DEVICE(0x2001, 0x3315),.driver_info = RTL8812}, /* D-Link - Cameo */
    {USB_DEVICE(0x2001, 0x3316),.driver_info = RTL8812}, /* D-Link - Cameo */
    {USB_DEVICE(0x2019, 0xAB30),.driver_info = RTL8812}, /* Planex - Abocom */
    {USB_DEVICE(0x20F4, 0x805B),.driver_info = RTL8812}, /* TRENDnet - */
    {USB_DEVICE(0x2357, 0x0101),.driver_info = RTL8812}, /* TP-Link - Archer T4U */
    {USB_DEVICE(0x2357, 0x0103),.driver_info = RTL8812}, /* TP-Link - T4UH */
    {USB_DEVICE(0x7392, 0xA822),.driver_info = RTL8812}, /* Edimax - EW-7822UAC */
#endif

    {}  /* Terminating entry */
};




MODULE_DEVICE_TABLE(usb, rtw_usb_id_tbl);



int const rtw_usb_id_len = sizeof(rtw_usb_id_tbl) / sizeof(struct usb_device_id);




static struct specific_device_id specific_device_id_tbl[] =
{
    {.idVendor=USB_VENDER_ID_REALTEK, .idProduct=0x8177, .flags=SPEC_DEV_ID_DISABLE_HT},//8188cu 1*1 dongole, (b/g mode only)
    {.idVendor=USB_VENDER_ID_REALTEK, .idProduct=0x817E, .flags=SPEC_DEV_ID_DISABLE_HT},//8188CE-VAU USB minCard (b/g mode only)
    {.idVendor=0x0b05, .idProduct=0x1791, .flags=SPEC_DEV_ID_DISABLE_HT},
    {.idVendor=0x13D3, .idProduct=0x3311, .flags=SPEC_DEV_ID_DISABLE_HT},
    {.idVendor=0x13D3, .idProduct=0x3359, .flags=SPEC_DEV_ID_DISABLE_HT},//Russian customer -Azwave (8188CE-VAU  g mode)
    {}
};




struct rtw_usb_drv
{
    struct usb_driver usbdrv;
    int drv_registered;
    u8 hw_type;
};




struct rtw_usb_drv usb_drv =
{
    .usbdrv.name =(char*)DRV_NAME,
    .usbdrv.probe = rtw_dev_probe,
    .usbdrv.disconnect = rtw_dev_remove,
    .usbdrv.id_table = rtw_usb_id_tbl,
    .usbdrv.suspend =  rtw_suspend,
    .usbdrv.resume = rtw_resume,
    .usbdrv.reset_resume   = rtw_resume,
    .usbdrv.drvwrap.driver.shutdown = rtw_dev_shutdown,
};




static inline int RT_usb_endpoint_dir_in(const struct usb_endpoint_descriptor *epd)
{
    return ((epd->bEndpointAddress & USB_ENDPOINT_DIR_MASK) == USB_DIR_IN);
}

static inline int RT_usb_endpoint_dir_out(const struct usb_endpoint_descriptor *epd)
{
    return ((epd->bEndpointAddress & USB_ENDPOINT_DIR_MASK) == USB_DIR_OUT);
}

static inline int RT_usb_endpoint_xfer_int(const struct usb_endpoint_descriptor *epd)
{
    return ((epd->bmAttributes & USB_ENDPOINT_XFERTYPE_MASK) == USB_ENDPOINT_XFER_INT);
}

static inline int RT_usb_endpoint_xfer_bulk(const struct usb_endpoint_descriptor *epd)
{
    return ((epd->bmAttributes & USB_ENDPOINT_XFERTYPE_MASK) == USB_ENDPOINT_XFER_BULK);
}

static inline int RT_usb_endpoint_is_bulk_in(const struct usb_endpoint_descriptor *epd)
{
    return (RT_usb_endpoint_xfer_bulk(epd) && RT_usb_endpoint_dir_in(epd));
}

static inline int RT_usb_endpoint_is_bulk_out(const struct usb_endpoint_descriptor *epd)
{
    return (RT_usb_endpoint_xfer_bulk(epd) && RT_usb_endpoint_dir_out(epd));
}

static inline int RT_usb_endpoint_is_int_in(const struct usb_endpoint_descriptor *epd)
{
    return (RT_usb_endpoint_xfer_int(epd) && RT_usb_endpoint_dir_in(epd));
}

static inline int RT_usb_endpoint_num(const struct usb_endpoint_descriptor *epd)
{
    return epd->bEndpointAddress & USB_ENDPOINT_NUMBER_MASK;
}





static u8 rtw_init_intf_priv(struct dvobj_priv *dvobj)
{
    u8 rst = _SUCCESS;

#ifdef CONFIG_USB_VENDOR_REQ_MUTEX
    _rtw_mutex_init(&dvobj->usb_vendor_req_mutex);
#endif


#ifdef CONFIG_USB_VENDOR_REQ_BUFFER_PREALLOC
    dvobj->usb_alloc_vendor_req_buf = rtw_zmalloc(MAX_USB_IO_CTL_SIZE);
    if (dvobj->usb_alloc_vendor_req_buf == NULL)
    {
        DBG_871X("alloc usb_vendor_req_buf failed... /n");
        rst = _FAIL;
        goto exit;
    }
    dvobj->usb_vendor_req_buf  =
        (u8 *)N_BYTE_ALIGMENT((SIZE_PTR)(dvobj->usb_alloc_vendor_req_buf ), ALIGNMENT_UNIT);
exit:
#endif

    return rst;

}





static u8 rtw_deinit_intf_priv(struct dvobj_priv *dvobj)
{
    u8 rst = _SUCCESS;

#ifdef CONFIG_USB_VENDOR_REQ_BUFFER_PREALLOC
    if(dvobj->usb_vendor_req_buf)
        rtw_mfree(dvobj->usb_alloc_vendor_req_buf, MAX_USB_IO_CTL_SIZE);
#endif

#ifdef CONFIG_USB_VENDOR_REQ_MUTEX
    _rtw_mutex_free(&dvobj->usb_vendor_req_mutex);
#endif

    return rst;
}






static void rtw_decide_chip_type_by_usb_info(struct dvobj_priv *pdvobjpriv, const struct usb_device_id *pdid)
{
    pdvobjpriv->chip_type = pdid->driver_info;

#if defined(CONFIG_RTL8812A)
    if (pdvobjpriv->chip_type == RTL8812)
        rtl8812au_set_hw_type(pdvobjpriv);
#endif

}



static struct dvobj_priv *usb_dvobj_init(struct usb_interface *usb_intf, const struct usb_device_id *pdid)
{
    int i;
    u8  val8;
    int status = _FAIL;
    struct dvobj_priv *pdvobjpriv;
    struct usb_device_descriptor    *pdev_desc;
    struct usb_host_config          *phost_conf;
    struct usb_config_descriptor        *pconf_desc;
    struct usb_host_interface       *phost_iface;
    struct usb_interface_descriptor *piface_desc;
    struct usb_host_endpoint        *phost_endp;
    struct usb_endpoint_descriptor  *pendp_desc;
    struct usb_device               *pusbd;

    _func_enter_;


    if((pdvobjpriv = devobj_init()) == NULL)
    {
        goto exit;
    }


    pdvobjpriv->pusbintf = usb_intf ;
    pusbd = pdvobjpriv->pusbdev = interface_to_usbdev(usb_intf); //zb: Record this device in our driver!
    usb_set_intfdata(usb_intf, pdvobjpriv);

    pdvobjpriv->RtNumInPipes = 0;
    pdvobjpriv->RtNumOutPipes = 0;

    //padapter->EepromAddressSize = 6;
    //pdvobjpriv->nr_endpoint = 6;

    pdev_desc = &pusbd->descriptor;

    phost_conf = pusbd->actconfig;
    pconf_desc = &phost_conf->desc;


    //DBG_871X("\n/****** num of altsetting = (%d) ******/\n", pusb_interface->num_altsetting);

    phost_iface = &usb_intf->altsetting[0];
    piface_desc = &phost_iface->desc;

    pdvobjpriv->NumInterfaces = pconf_desc->bNumInterfaces;
    pdvobjpriv->InterfaceNumber = piface_desc->bInterfaceNumber;
    pdvobjpriv->nr_endpoint = piface_desc->bNumEndpoints;

    //DBG_871X("\ndump usb_endpoint_descriptor:\n");

    for (i = 0; i < pdvobjpriv->nr_endpoint; i++)
    {
        phost_endp = phost_iface->endpoint + i;
        if (phost_endp)
        {
            pendp_desc = &phost_endp->desc;

            DBG_871X("\nusb_endpoint_descriptor(%d):\n", i);
            DBG_871X("bLength=%x\n",pendp_desc->bLength);
            DBG_871X("bDescriptorType=%x\n",pendp_desc->bDescriptorType);
            DBG_871X("bEndpointAddress=%x\n",pendp_desc->bEndpointAddress);

			
            //DBG_871X("bmAttributes=%x\n",pendp_desc->bmAttributes);
            DBG_871X("wMaxPacketSize=%d\n",le16_to_cpu(pendp_desc->wMaxPacketSize));
            DBG_871X("bInterval=%x\n",pendp_desc->bInterval);
            //DBG_871X("bRefresh=%x\n",pendp_desc->bRefresh);
            //DBG_871X("bSynchAddress=%x\n",pendp_desc->bSynchAddress);

            if (RT_usb_endpoint_is_bulk_in(pendp_desc))
            {
                DBG_871X("RT_usb_endpoint_is_bulk_in = %x\n", RT_usb_endpoint_num(pendp_desc));
                pdvobjpriv->RtInPipe[pdvobjpriv->RtNumInPipes] = RT_usb_endpoint_num(pendp_desc);
                pdvobjpriv->RtNumInPipes++;
            }
            else if (RT_usb_endpoint_is_int_in(pendp_desc))
            {
                DBG_871X("RT_usb_endpoint_is_int_in = %x, Interval = %x\n", RT_usb_endpoint_num(pendp_desc),pendp_desc->bInterval);
                pdvobjpriv->RtInPipe[pdvobjpriv->RtNumInPipes] = RT_usb_endpoint_num(pendp_desc);
                pdvobjpriv->RtNumInPipes++;
            }
            else if (RT_usb_endpoint_is_bulk_out(pendp_desc))
            {
                DBG_871X("RT_usb_endpoint_is_bulk_out = %x\n", RT_usb_endpoint_num(pendp_desc));
                pdvobjpriv->RtOutPipe[pdvobjpriv->RtNumOutPipes] = RT_usb_endpoint_num(pendp_desc);
                pdvobjpriv->RtNumOutPipes++;
            }
			
            pdvobjpriv->ep_num[i] = RT_usb_endpoint_num(pendp_desc);
        }
    }


    DBG_871X("nr_endpoint=%d, in_num=%d, out_num=%d\n\n", pdvobjpriv->nr_endpoint, pdvobjpriv->RtNumInPipes, pdvobjpriv->RtNumOutPipes);

    switch(pusbd->speed)
    {
        case USB_SPEED_LOW:
            DBG_871X("USB_SPEED_LOW\n");
            pdvobjpriv->usb_speed = RTW_USB_SPEED_1_1;
            break;
        case USB_SPEED_FULL:
            DBG_871X("USB_SPEED_FULL\n");
            pdvobjpriv->usb_speed = RTW_USB_SPEED_1_1;
            break;
        case USB_SPEED_HIGH:
            DBG_871X("USB_SPEED_HIGH\n");
            pdvobjpriv->usb_speed = RTW_USB_SPEED_2;
            break;

        case USB_SPEED_SUPER:
            DBG_871X("USB_SPEED_SUPER\n");
            pdvobjpriv->usb_speed = RTW_USB_SPEED_3;
            break;
        default:
            DBG_871X("USB_SPEED_UNKNOWN(%x)\n",pusbd->speed);
            pdvobjpriv->usb_speed = RTW_USB_SPEED_UNKNOWN;
            break;
    }

    if (pdvobjpriv->usb_speed == RTW_USB_SPEED_UNKNOWN)
    {
        DBG_871X("UNKNOWN USB SPEED MODE, ERROR !!!\n");
        goto free_dvobj;
    }

    if (rtw_init_intf_priv(pdvobjpriv) == _FAIL)
    {
        RT_TRACE(_module_os_intfs_c_,_drv_err_,("\n Can't INIT rtw_init_intf_priv\n"));
        goto free_dvobj;
    }

    /*step 1-1., decide the chip_type via driver_info*/
    pdvobjpriv->interface_type = RTW_USB;
    rtw_decide_chip_type_by_usb_info(pdvobjpriv, pdid);

    //.3 misc
    _rtw_init_sema(&(pdvobjpriv->usb_suspend_sema), 0);
    rtw_reset_continual_io_error(pdvobjpriv);

    usb_get_dev(pusbd);

    status = _SUCCESS;

free_dvobj:
    if (status != _SUCCESS && pdvobjpriv)
    {
        usb_set_intfdata(usb_intf, NULL);

        devobj_deinit(pdvobjpriv);

        pdvobjpriv = NULL;
    }
exit:
    _func_exit_;
    return pdvobjpriv;
}





static void usb_dvobj_deinit(struct usb_interface *usb_intf)
{
    struct dvobj_priv *dvobj = usb_get_intfdata(usb_intf);

    _func_enter_;

    usb_set_intfdata(usb_intf, NULL);
    if (dvobj)
    {
        //Modify condition for 92DU DMDP 2010.11.18, by Thomas
        if ((dvobj->NumInterfaces != 2 && dvobj->NumInterfaces != 3)
            || (dvobj->InterfaceNumber == 1))
        {
            if (interface_to_usbdev(usb_intf)->state != USB_STATE_NOTATTACHED)
            {
                //If we didn't unplug usb dongle and remove/insert modlue, driver fails on sitesurvey for the first time when device is up .
                //Reset usb port for sitesurvey fail issue. 2009.8.13, by Thomas
                DBG_871X("usb attached..., try to reset usb device\n");
                usb_reset_device(interface_to_usbdev(usb_intf));
            }
        }

        rtw_deinit_intf_priv(dvobj);

        devobj_deinit(dvobj);
    }

    //DBG_871X("%s %d\n", __func__, ATOMIC_READ(&usb_intf->dev.kobj.kref.refcount));
    usb_put_dev(interface_to_usbdev(usb_intf));

    _func_exit_;
}





static int usb_reprobe_to_usb3(PADAPTER Adapter)
{
    struct registry_priv  *registry_par = &Adapter->registrypriv;
    int ret = _FALSE;

    if (registry_par->switch_usb3 == _TRUE) //zbDebug: usb3.0 ?
    {
        if (IS_HIGH_SPEED_USB(Adapter))
        {
            if ((rtw_read8(Adapter, 0x74) & (BIT(2)|BIT(3))) != BIT(3))
            {
                rtw_write8(Adapter, 0x74, 0x8);
                rtw_write8(Adapter, 0x70, 0x2);
                rtw_write8(Adapter, 0x3e, 0x1);
                rtw_write8(Adapter, 0x3d, 0x3);
                /* usb disconnect */
                rtw_write8(Adapter, 0x5, 0x80);
                ret = _TRUE;
            }

        }
        else if (IS_SUPER_SPEED_USB(Adapter))
        {
            rtw_write8(Adapter, 0x70, rtw_read8(Adapter, 0x70) & (~BIT(1)));
            rtw_write8(Adapter, 0x3e, rtw_read8(Adapter, 0x3e) & (~BIT(0)));
        }
    }

    return ret;
}





u8 rtw_set_hal_ops(_adapter *padapter)
{
    //alloc memory for HAL DATA
    if (rtw_hal_data_init(padapter) == _FAIL)
        return _FAIL;

    if (rtw_get_chip_type(padapter) == RTL8812)
        rtl8812au_set_hal_ops(padapter);

    if (_FAIL == rtw_hal_ops_check(padapter) )
        return _FAIL;

    if (hal_spec_init(padapter) == _FAIL)
        return _FAIL;

    return _SUCCESS;
}





void usb_set_intf_ops(_adapter *padapter,struct _io_ops *pops)
{
    if (rtw_get_chip_type(padapter) == RTL8812)
        rtl8812au_set_intf_ops(pops);
}




static void usb_intf_start(_adapter *padapter)
{

    RT_TRACE(_module_hci_intfs_c_,_drv_err_,("+usb_intf_start\n"));

    rtw_hal_inirp_init(padapter);

    RT_TRACE(_module_hci_intfs_c_,_drv_err_,("-usb_intf_start\n"));

}




static void usb_intf_stop(_adapter *padapter)
{

    RT_TRACE(_module_hci_intfs_c_,_drv_err_,("+usb_intf_stop\n"));

    //disabel_hw_interrupt
    if (!rtw_is_surprise_removed(padapter))
    {
        //device still exists, so driver can do i/o operation
        //TODO:
        RT_TRACE(_module_hci_intfs_c_,_drv_err_,("SurpriseRemoved==_FALSE\n"));
    }

    //cancel in irp
    rtw_hal_inirp_deinit(padapter);

    //cancel out irp
    rtw_write_port_cancel(padapter);

    //todo:cancel other irps

    RT_TRACE(_module_hci_intfs_c_,_drv_err_,("-usb_intf_stop\n"));

}




static void process_spec_devid(const struct usb_device_id *pdid)
{
    u16 vid, pid;
    u32 flags;
    int i;
    int num = sizeof(specific_device_id_tbl)/sizeof(struct specific_device_id);

    for(i=0; i<num; i++)
    {
        vid = specific_device_id_tbl[i].idVendor;
        pid = specific_device_id_tbl[i].idProduct;
        flags = specific_device_id_tbl[i].flags;

#ifdef CONFIG_80211N_HT
        if((pdid->idVendor==vid) && (pdid->idProduct==pid) && (flags&SPEC_DEV_ID_DISABLE_HT))
        {
            rtw_ht_enable = 0;
            rtw_bw_mode = 0;
            rtw_ampdu_enable = 0;
        }
#endif
    }
}




static int rtw_suspend(struct usb_interface *pusb_intf, pm_message_t message)
{
    struct dvobj_priv *dvobj;
    struct pwrctrl_priv *pwrpriv;
    struct debug_priv *pdbgpriv;
    PADAPTER padapter;
    int ret = 0;


    dvobj = usb_get_intfdata(pusb_intf);
    pwrpriv = dvobj_to_pwrctl(dvobj);
    pdbgpriv = &dvobj->drv_dbg;
    padapter = dvobj->padapters[IFACE_ID0];

    if (pwrpriv->bInSuspend == _TRUE)
    {
        DBG_871X("%s bInSuspend = %d\n", __FUNCTION__, pwrpriv->bInSuspend);
        pdbgpriv->dbg_suspend_error_cnt++;
        goto exit;
    }

    if ((padapter->bup) || !rtw_is_drv_stopped(padapter) || !rtw_is_surprise_removed(padapter))
    {

    }

    ret =  rtw_suspend_common(padapter);

exit:
    return ret;
}




int rtw_resume_process(_adapter *padapter)
{
    int ret,pm_cnt = 0;
    struct pwrctrl_priv *pwrpriv = adapter_to_pwrctl(padapter);
    struct dvobj_priv *pdvobj = padapter->dvobj;
    struct debug_priv *pdbgpriv = &pdvobj->drv_dbg;


    if (pwrpriv->bInSuspend == _FALSE)
    {
        pdbgpriv->dbg_resume_error_cnt++;
        DBG_871X("%s bInSuspend = %d\n", __FUNCTION__, pwrpriv->bInSuspend);
        return -1;
    }


    ret =  rtw_resume_common(padapter);
    return ret;
}



static int rtw_resume(struct usb_interface *pusb_intf)
{
    struct dvobj_priv *dvobj;
    struct pwrctrl_priv *pwrpriv;
    struct debug_priv *pdbgpriv;
    PADAPTER padapter;
    struct mlme_ext_priv *pmlmeext;
    int ret = 0;


    dvobj = usb_get_intfdata(pusb_intf);
    pwrpriv = dvobj_to_pwrctl(dvobj);
    pdbgpriv = &dvobj->drv_dbg;
    padapter = dvobj->padapters[IFACE_ID0];
    pmlmeext = &padapter->mlmeextpriv;

    DBG_871X("==> %s (%s:%d)\n", __FUNCTION__, current->comm, current->pid);
    pdbgpriv->dbg_resume_cnt++;

    if(pwrpriv->bInternalAutoSuspend)
    {
        ret = rtw_resume_process(padapter);
    }
    else
    {
        if(pwrpriv->wowlan_mode || pwrpriv->wowlan_ap_mode)
        {
            rtw_resume_lock_suspend();
            ret = rtw_resume_process(padapter);
            rtw_resume_unlock_suspend();
        }
        else
        {
            if (rtw_is_earlysuspend_registered(pwrpriv))
            {
                /* jeff: bypass resume here, do in late_resume */
                rtw_set_do_late_resume(pwrpriv, _TRUE);
            }
            else
            {
                rtw_resume_lock_suspend();
                ret = rtw_resume_process(padapter);
                rtw_resume_unlock_suspend();
            }
        }
    }

    pmlmeext->last_scan_time = rtw_get_current_time();
    DBG_871X("<========  %s return %d\n", __FUNCTION__, ret);

    return ret;
}




/*
 * drv_init() - a device potentially for us
 *
 * notes: drv_init() is called when the bus driver has located a card for us to support.
 *        We accept the new device by returning 0.
*/

_adapter  *rtw_sw_export = NULL;

_adapter *rtw_usb_if1_init(struct dvobj_priv *dvobj, struct usb_interface *pusb_intf)
{
    _adapter *padapter = NULL;
    int status = _FAIL;

    padapter = (_adapter *)rtw_zvmalloc(sizeof(*padapter));
    if (padapter == NULL)
        goto exit;

    if (loadparam(padapter) != _SUCCESS)
        goto free_adapter;

    padapter->dvobj = dvobj;


    rtw_set_drv_stopped(padapter);

    dvobj->padapters[dvobj->iface_nums++] = padapter;
    padapter->iface_id = IFACE_ID0;


	//===================Set all callback functions==================
    //step 2. hook HalFunc, allocate HalData
    //hal_set_hal_ops(padapter);
    if(rtw_set_hal_ops(padapter) ==_FAIL)
        goto free_hal_data;


    padapter->intf_start=&usb_intf_start;
    padapter->intf_stop=&usb_intf_stop;

    //step init_io_priv
    if( rtw_init_io_priv(padapter,usb_set_intf_ops) ==_FAIL)
        goto free_hal_data;
	//================================================================



	//================================Get Chip related information==================
    //step read_chip_version
    rtw_hal_read_chip_version(padapter);



	//===================Get Interface related information and Fill HalData==================
    //step usb endpoint mapping
    rtw_hal_chip_configure(padapter);



	//================================Get EEPROM related information (mac address is in it)==================
    //step read efuse/eeprom data and get mac_addr
    rtw_hal_read_chip_info(padapter);



	//==============================MLME xmit recv initialization==================================
    //step 5.
    if(rtw_init_drv_sw(padapter) ==_FAIL)
    {
        RT_TRACE(_module_hci_intfs_c_,_drv_err_,("Initialize driver software resource Failed!\n"));
        goto free_hal_data;
    }


	//zbAdd: init list
	//INIT_LIST_HEAD(&(padapter->apTcpPktInfoList));
	


    //2012-07-11 Move here to prevent the 8723AS-VAU BT auto suspend influence
    if (usb_autopm_get_interface(pusb_intf) < 0)
    {
        DBG_871X( "can't get autopm: \n");
    }


    // set mac addr
    rtw_macaddr_cfg(adapter_mac_addr(padapter), get_hal_mac_addr(padapter)); //zbDebug: Has already stored to this buf!


	//
	//PutWndSizeToStaMacAddressField(padapter, 100); //zbAdd

	//===================zbAdd======begin============
	_rtw_mutex_init ( &padapter->apTcpFlowTrace.seQBufMutex); //zbAdd

	//
	mutex_init(&padapter->tcpPktInfoMutext);
	printk("\n=====HZ: %u====\n\n", HZ);
	
	//===================zbAdd======end============


	

    DBG_871X("bDriverStopped:%s, bSurpriseRemoved:%s, bup:%d, hw_init_completed:%d\n"
             , rtw_is_drv_stopped(padapter)?"True":"False"
             , rtw_is_surprise_removed(padapter)?"True":"False"
             , padapter->bup
             , rtw_get_hw_init_completed(padapter)
            );

    status = _SUCCESS;


free_hal_data:
    if (status != _SUCCESS && padapter->HalData)
        rtw_hal_free_data(padapter);
free_adapter:
    if (status != _SUCCESS && padapter)
    {
        rtw_vmfree((u8 *)padapter, sizeof(*padapter));
        padapter = NULL;
    }
exit:
    return padapter;
}




static void rtw_usb_if1_deinit(_adapter *if1)
{
    struct pwrctrl_priv *pwrctl = adapter_to_pwrctl(if1);
    struct mlme_priv *pmlmepriv= &if1->mlmepriv;

    if(check_fwstate(pmlmepriv, _FW_LINKED))
        rtw_disassoc_cmd(if1, 0, _FALSE);


#ifdef CONFIG_AP_MODE
    free_mlme_ap_info(if1);
#endif

    rtw_cancel_all_timer(if1);



    rtw_dev_unload(if1);

    DBG_871X("+r871xu_dev_remove, hw_init_completed=%d\n", rtw_get_hw_init_completed(if1));


    rtw_free_drv_sw(if1);

    /* TODO: use rtw_os_ndevs_deinit instead at the first stage of driver's dev deinit function */
    rtw_os_ndev_free(if1);

    rtw_vmfree((u8 *)if1, sizeof(_adapter));

}






static int rtw_dev_probe(struct usb_interface *pusb_intf, const struct usb_device_id *pdid)
{
    _adapter *if1 = NULL, *if2 = NULL;
    int status = _FAIL;
    struct dvobj_priv *dvobj;

    //step 0.
    process_spec_devid(pdid);

    /* Initialize dvobj_priv */
    if ((dvobj = usb_dvobj_init(pusb_intf, pdid)) == NULL)
    {
        RT_TRACE(_module_hci_intfs_c_, _drv_err_, ("initialize device object priv Failed!\n"));
        goto exit;
    }

	//====================Various Parameters Init======================================
    if ((if1 = rtw_usb_if1_init(dvobj, pusb_intf)) == NULL)
    {
        DBG_871X("rtw_usb_if1_init Failed!\n");
        goto free_dvobj;
    }


	//====================Detect USB 3.0======================================
    if (usb_reprobe_to_usb3(if1) == _TRUE)
        goto free_if1;


#ifdef CONFIG_GLOBAL_UI_PID
    if(ui_pid[1]!=0)
    {
        DBG_871X("ui_pid[1]:%d\n",ui_pid[1]);
        rtw_signal_process(ui_pid[1], SIGUSR2);
    }
#endif

	//====================Allocate ndev======================================
    if (rtw_os_ndevs_init(dvobj) != _SUCCESS) //zbDebug: 
        goto free_if2;


	//



    RT_TRACE(_module_hci_intfs_c_,_drv_err_,("-871x_drv - drv_init, success!\n"));

    status = _SUCCESS;


free_if2:
    if(status != _SUCCESS && if2)
    {
    }
free_if1:
    if (status != _SUCCESS && if1)
    {
        rtw_usb_if1_deinit(if1);
    }
free_dvobj:
    if (status != _SUCCESS)
        usb_dvobj_deinit(pusb_intf);
exit:
    return status == _SUCCESS?0:-ENODEV;
}





static void rtw_dev_remove(struct usb_interface *pusb_intf)
{
    struct dvobj_priv *dvobj = usb_get_intfdata(pusb_intf);
    struct pwrctrl_priv *pwrctl = dvobj_to_pwrctl(dvobj);
    _adapter *padapter = dvobj->padapters[IFACE_ID0];
    struct net_device *pnetdev = padapter->pnetdev;
    struct mlme_priv *pmlmepriv= &padapter->mlmepriv;

    _func_enter_;

    DBG_871X("+rtw_dev_remove\n");
    RT_TRACE(_module_hci_intfs_c_,_drv_err_,("+dev_remove()\n"));

    dvobj->processing_dev_remove = _TRUE;

    /* TODO: use rtw_os_ndevs_deinit instead at the first stage of driver's dev deinit function */
    rtw_os_ndevs_unregister(dvobj);

    if(usb_drv.drv_registered == _TRUE)
    {
        //DBG_871X("r871xu_dev_remove():padapter->bSurpriseRemoved == _TRUE\n");
        rtw_set_surprise_removed(padapter);
    }
    /*else
    {
        //DBG_871X("r871xu_dev_remove():module removed\n");
        padapter->HalData->hw_init_completed = _FALSE;
    }*/


    if (padapter->bFWReady == _TRUE)
    {
        rtw_pm_set_ips(padapter, IPS_NONE);
        rtw_pm_set_lps(padapter, PS_MODE_ACTIVE);

        LeaveAllPowerSaveMode(padapter);
    }
    rtw_set_drv_stopped(padapter);  /*for stop thread*/
    rtw_usb_if1_deinit(padapter);

    usb_dvobj_deinit(pusb_intf);

    RT_TRACE(_module_hci_intfs_c_,_drv_err_,("-dev_remove()\n"));
    DBG_871X("-r871xu_dev_remove, done\n");

    _func_exit_;

    return;

}


extern int console_suspend_enabled;


static int __init rtw_drv_init(void)
{
    int ret = 0;

	
    DBG_871X_LEVEL(_drv_always_, "module init start\n");
    dump_drv_version(RTW_DBGDUMP);

    ret = platform_wifi_power_on();
    if(ret != 0)
    {
        DBG_871X("%s: power on failed!!(%d)\n", __FUNCTION__, ret);
        ret = -1;
        goto exit;
    }

    usb_drv.drv_registered = _TRUE;
    rtw_suspend_lock_init();

	//
    rtw_ndev_notifier_register();

    ret = usb_register(&usb_drv.usbdrv);
    if (ret != 0)
    {
        usb_drv.drv_registered = _FALSE;
        rtw_suspend_lock_uninit();
		
        rtw_ndev_notifier_unregister();
        goto exit;
    }

exit:
    DBG_871X_LEVEL(_drv_always_, "module init ret=%d\n", ret);
    return ret;
}




static void __exit rtw_drv_exit(void)
{
    DBG_871X_LEVEL(_drv_always_, "module exit start\n");

    usb_drv.drv_registered = _FALSE;

    usb_deregister(&usb_drv.usbdrv);

    platform_wifi_power_off();

    rtw_suspend_lock_uninit();

    rtw_ndev_notifier_unregister();

    DBG_871X_LEVEL(_drv_always_, "module exit success\n");

    rtw_mstat_dump(RTW_DBGDUMP);
}


module_init(rtw_drv_init);
module_exit(rtw_drv_exit);



