


#define _OS_INTFS_C_



#include <drv_types.h>
#include <hal_data.h>



MODULE_LICENSE ( "GPL" );
MODULE_DESCRIPTION ( "Realtek Wireless Lan Driver" );
MODULE_AUTHOR ( "Realtek Semiconductor Corp." );
MODULE_VERSION ( DRIVERVERSION );



/* module param defaults */
int rtw_chip_version = 0x00;
int rtw_rfintfs = HWPI;
int rtw_lbkmode = 0;//RTL8712_AIR_TRX;
int rtw_network_mode = Ndis802_11IBSS;//Ndis802_11Infrastructure;//infra, ad-hoc, auto


//NDIS_802_11_SSID  ssid;
int rtw_channel = 1;//ad-hoc support requirement
int rtw_wireless_mode = WIRELESS_MODE_MAX;
int rtw_vrtl_carrier_sense = AUTO_VCS;
int rtw_vcs_type = RTS_CTS;//*
int rtw_rts_thresh = 2347;//*
int rtw_frag_thresh = 2346;//*
int rtw_preamble = PREAMBLE_LONG;//long, short, auto
int rtw_scan_mode = 1;//active, passive
int rtw_adhoc_tx_pwr = 1;
int rtw_soft_ap = 0;


int rtw_power_mgnt = PS_MODE_ACTIVE;
int rtw_ips_mode = IPS_NONE;


module_param ( rtw_ips_mode, int, 0644 );
MODULE_PARM_DESC ( rtw_ips_mode, "The default IPS mode" );


int rtw_smart_ps = 2;
int rtw_check_fw_ps = 1;
int rtw_usb_rxagg_mode = 2;//USB_RX_AGG_DMA =1,USB_RX_AGG_USB=2


module_param ( rtw_usb_rxagg_mode, int, 0644 );


int rtw_radio_enable = 1;
int rtw_long_retry_lmt = 7;
int rtw_short_retry_lmt = 7;
int rtw_busy_thresh = 40;

//int qos_enable = 0; //*
//int rtw_ack_policy = NORMAL_ACK; //zbDebug
int rtw_ack_policy = NO_ACK; //zbDebug
//int rtw_ack_policy = NON_EXPLICIT_ACK; //zbDebug
//int rtw_ack_policy = BLOCK_ACK; //zbDebug






int rtw_mp_mode = 0;

int rtw_software_encrypt = 0;
int rtw_software_decrypt = 0;

int rtw_acm_method = 0;// 0:By SW 1:By HW.

int rtw_wmm_enable = 1;// default is set to enable the wmm.
int rtw_uapsd_enable = 0;
int rtw_uapsd_max_sp = NO_LIMIT;
int rtw_uapsd_acbk_en = 0;
int rtw_uapsd_acbe_en = 0;
int rtw_uapsd_acvi_en = 0;
int rtw_uapsd_acvo_en = 0;

int rtw_rfkfree_enable = 0; /* Default Enalbe kfree by efuse config */



#ifdef CONFIG_80211N_HT
int rtw_ht_enable = 1;
// 0: 20 MHz, 1: 40 MHz, 2: 80 MHz, 3: 160MHz, 4: 80+80MHz
// 2.4G use bit 0 ~ 3, 5G use bit 4 ~ 7
// 0x21 means enable 2.4G 40MHz & 5G 80MHz
int rtw_bw_mode = 0x21;
int rtw_ampdu_enable = 1;//for enable tx_ampdu ,// 0: disable, 0x1:enable (but wifi_spec should be 0), 0x2: force enable (don't care wifi_spec)
int rtw_rx_stbc = 1;// 0: disable, bit(0):enable 2.4g, bit(1):enable 5g, default is set to enable 2.4GHZ for IOT issue with bufflao's AP at 5GHZ
int rtw_ampdu_amsdu = 0;// 0: disabled, 1:enabled, 2:auto . There is an IOT issu with DLINK DIR-629 when the flag turn on
// Short GI support Bit Map
// BIT0 - 20MHz, 0: non-support, 1: support
// BIT1 - 40MHz, 0: non-support, 1: support
// BIT2 - 80MHz, 0: non-support, 1: support
// BIT3 - 160MHz, 0: non-support, 1: support
int rtw_short_gi = 0xf;
// BIT0: Enable VHT LDPC Rx, BIT1: Enable VHT LDPC Tx, BIT4: Enable HT LDPC Rx, BIT5: Enable HT LDPC Tx
int rtw_ldpc_cap = 0x00;
// BIT0: Enable VHT STBC Rx, BIT1: Enable VHT STBC Tx, BIT4: Enable HT STBC Rx, BIT5: Enable HT STBC Tx
int rtw_stbc_cap = 0x13;
// BIT0: Enable VHT Beamformer, BIT1: Enable VHT Beamformee, BIT4: Enable HT Beamformer, BIT5: Enable HT Beamformee
int rtw_beamform_cap = 0x2;
int rtw_bfer_rf_number = 0; /*BeamformerCapRfNum Rf path number, 0 for auto, others for manual*/
int rtw_bfee_rf_number = 0; /*BeamformeeCapRfNum  Rf path number, 0 for auto, others for manual*/

#endif //CONFIG_80211N_HT



#ifdef CONFIG_80211AC_VHT
int rtw_vht_enable = 1; //0:disable, 1:enable, 2:force auto enable
int rtw_ampdu_factor = 7;
int rtw_vht_rate_sel = 0;
#endif //CONFIG_80211AC_VHT


int rtw_lowrate_two_xmit = 1;//Use 2 path Tx to transmit MCS0~7 and legacy mode
int rtw_rf_config = RF_MAX_TYPE;  //auto
int rtw_low_power = 0;
int rtw_wifi_spec = 0;
int rtw_special_rf_path = 0; //0: 2T2R ,1: only turn on path A 1T1R
int rtw_channel_plan = RTW_CHPLAN_MAX;



int rtw_AcceptAddbaReq = _TRUE;// 0:Reject AP's Add BA req, 1:Accept AP's Add BA req.
int rtw_antdiv_cfg = 2; // 0:OFF , 1:ON, 2:decide by Efuse config
int rtw_antdiv_type = 0 ; //0:decide by efuse  1: for 88EE, 1Tx and 1RxCG are diversity.(2 Ant with SPDT), 2:  for 88EE, 1Tx and 2Rx are diversity.( 2 Ant, Tx and RxCG are both on aux port, RxCS is on main port ), 3: for 88EE, 1Tx and 1RxCG are fixed.(1Ant, Tx and RxCG are both on aux port)
int rtw_switch_usb3 = _FALSE; /* _FALSE: doesn't switch, _TRUE: switch from usb2.0 to usb 3.0 */



#ifdef CONFIG_USB_AUTOSUSPEND
int rtw_enusbss = 1;//0:disable,1:enable
#else
int rtw_enusbss = 0;//0:disable,1:enable
#endif


int rtw_hwpdn_mode = 2; //0:disable,1:enable,2: by EFUSE config


#ifdef CONFIG_HW_PWRP_DETECTION
int rtw_hwpwrp_detect = 1;
#else
int rtw_hwpwrp_detect = 0; //HW power  ping detect 0:disable , 1:enable
#endif


#ifdef CONFIG_USB_HCI
int rtw_hw_wps_pbc = 1;
#else
int rtw_hw_wps_pbc = 0;
#endif


#ifdef CONFIG_TX_MCAST2UNI
int rtw_mc2u_disable = 0;
#endif  // CONFIG_TX_MCAST2UNI


#ifdef CONFIG_80211D
int rtw_80211d = 0;
#endif





#ifdef CONFIG_QOS_OPTIMIZATION
int rtw_qos_opt_enable = 1; //0: disable,1:enable
#else
int rtw_qos_opt_enable = 0; //0: disable,1:enable
#endif
module_param ( rtw_qos_opt_enable, int, 0644 );



char* ifname = "wlan%d";

module_param ( ifname, charp, 0644 );
MODULE_PARM_DESC ( ifname, "The default name to allocate for first interface" );


char* if2name = "wlan%d";


module_param ( if2name, charp, 0644 );
MODULE_PARM_DESC ( if2name, "The default name to allocate for second interface" );

char* rtw_initmac = 0;  // temp mac address if users want to use instead of the mac address in Efuse





module_param ( rtw_rfkfree_enable, int, 0644 );
module_param ( rtw_initmac, charp, 0644 );
module_param ( rtw_channel_plan, int, 0644 );
module_param ( rtw_special_rf_path, int, 0644 );
module_param ( rtw_chip_version, int, 0644 );
module_param ( rtw_rfintfs, int, 0644 );
module_param ( rtw_lbkmode, int, 0644 );
module_param ( rtw_network_mode, int, 0644 );
module_param ( rtw_channel, int, 0644 );
module_param ( rtw_mp_mode, int, 0644 );
module_param ( rtw_wmm_enable, int, 0644 );
module_param ( rtw_vrtl_carrier_sense, int, 0644 );
module_param ( rtw_vcs_type, int, 0644 );
module_param ( rtw_busy_thresh, int, 0644 );


#ifdef CONFIG_80211N_HT
module_param ( rtw_ht_enable, int, 0644 );
module_param ( rtw_bw_mode, int, 0644 );
module_param ( rtw_ampdu_enable, int, 0644 );
module_param ( rtw_rx_stbc, int, 0644 );
module_param ( rtw_ampdu_amsdu, int, 0644 );
#endif //CONFIG_80211N_HT



#ifdef CONFIG_80211AC_VHT
module_param ( rtw_vht_enable, int, 0644 );
#endif //CONFIG_80211AC_VHT


#ifdef CONFIG_BEAMFORMING
module_param ( rtw_beamform_cap, int, 0644 );
#endif

module_param ( rtw_lowrate_two_xmit, int, 0644 );

module_param ( rtw_rf_config, int, 0644 );
module_param ( rtw_power_mgnt, int, 0644 );
module_param ( rtw_smart_ps, int, 0644 );
module_param ( rtw_low_power, int, 0644 );
module_param ( rtw_wifi_spec, int, 0644 );

module_param ( rtw_antdiv_cfg, int, 0644 );
module_param ( rtw_antdiv_type, int, 0644 );

module_param ( rtw_switch_usb3, int, 0644 );

module_param ( rtw_enusbss, int, 0644 );
module_param ( rtw_hwpdn_mode, int, 0644 );
module_param ( rtw_hwpwrp_detect, int, 0644 );

module_param ( rtw_hw_wps_pbc, int, 0644 );



#ifdef CONFIG_TX_MCAST2UNI
module_param ( rtw_mc2u_disable, int, 0644 );
#endif  // CONFIG_TX_MCAST2UNI


#ifdef CONFIG_80211D
module_param ( rtw_80211d, int, 0644 );
MODULE_PARM_DESC ( rtw_80211d, "Enable 802.11d mechanism" );
#endif



uint rtw_notch_filter = RTW_NOTCH_FILTER;
module_param ( rtw_notch_filter, uint, 0644 );
MODULE_PARM_DESC ( rtw_notch_filter, "0:Disable, 1:Enable, 2:Enable only for P2P" );

uint rtw_hiq_filter = CONFIG_RTW_HIQ_FILTER;
module_param ( rtw_hiq_filter, uint, 0644 );
MODULE_PARM_DESC ( rtw_hiq_filter, "0:allow all, 1:allow special, 2:deny all" );

uint rtw_adaptivity_en = CONFIG_RTW_ADAPTIVITY_EN;
module_param ( rtw_adaptivity_en, uint, 0644 );
MODULE_PARM_DESC ( rtw_adaptivity_en, "0:disable, 1:enable" );

uint rtw_adaptivity_mode = CONFIG_RTW_ADAPTIVITY_MODE;
module_param ( rtw_adaptivity_mode, uint, 0644 );
MODULE_PARM_DESC ( rtw_adaptivity_mode, "0:normal, 1:carrier sense" );

uint rtw_adaptivity_dml = CONFIG_RTW_ADAPTIVITY_DML;
module_param ( rtw_adaptivity_dml, uint, 0644 );
MODULE_PARM_DESC ( rtw_adaptivity_dml, "0:disable, 1:enable" );

uint rtw_adaptivity_dc_backoff = CONFIG_RTW_ADAPTIVITY_DC_BACKOFF;
module_param ( rtw_adaptivity_dc_backoff, uint, 0644 );
MODULE_PARM_DESC ( rtw_adaptivity_dc_backoff, "DC backoff for Adaptivity" );

int rtw_adaptivity_th_l2h_ini = CONFIG_RTW_ADAPTIVITY_TH_L2H_INI;
module_param ( rtw_adaptivity_th_l2h_ini, int, 0644 );
MODULE_PARM_DESC ( rtw_adaptivity_th_l2h_ini, "TH_L2H_ini for Adaptivity" );

int rtw_adaptivity_th_edcca_hl_diff = CONFIG_RTW_ADAPTIVITY_TH_EDCCA_HL_DIFF;
module_param ( rtw_adaptivity_th_edcca_hl_diff, int, 0644 );
MODULE_PARM_DESC ( rtw_adaptivity_th_edcca_hl_diff, "TH_EDCCA_HL_diff for Adaptivity" );

uint rtw_amplifier_type_2g = CONFIG_RTW_AMPLIFIER_TYPE_2G;
module_param ( rtw_amplifier_type_2g, uint, 0644 );
MODULE_PARM_DESC ( rtw_amplifier_type_2g, "BIT3:2G ext-PA, BIT4:2G ext-LNA" );

uint rtw_amplifier_type_5g = CONFIG_RTW_AMPLIFIER_TYPE_5G;
module_param ( rtw_amplifier_type_5g, uint, 0644 );
MODULE_PARM_DESC ( rtw_amplifier_type_5g, "BIT6:5G ext-PA, BIT7:5G ext-LNA" );

uint rtw_RFE_type = CONFIG_RTW_RFE_TYPE;
module_param ( rtw_RFE_type, uint, 0644 );
MODULE_PARM_DESC ( rtw_RFE_type, "default init value:64" );

uint rtw_GLNA_type = CONFIG_RTW_GLNA_TYPE;
module_param ( rtw_GLNA_type, uint, 0644 );
MODULE_PARM_DESC ( rtw_GLNA_type, "default init value:0" );

uint rtw_TxBBSwing_2G = 0xFF;
module_param ( rtw_TxBBSwing_2G, uint, 0644 );
MODULE_PARM_DESC ( rtw_TxBBSwing_2G, "default init value:0xFF" );

uint rtw_TxBBSwing_5G = 0xFF;
module_param ( rtw_TxBBSwing_5G, uint, 0644 );
MODULE_PARM_DESC ( rtw_TxBBSwing_5G, "default init value:0xFF" );

uint rtw_OffEfuseMask = 0;
module_param ( rtw_OffEfuseMask, uint, 0644 );
MODULE_PARM_DESC ( rtw_OffEfuseMask, "default open Efuse Mask value:0" );

uint rtw_FileMaskEfuse = 0;
module_param ( rtw_FileMaskEfuse, uint, 0644 );
MODULE_PARM_DESC ( rtw_FileMaskEfuse, "default drv Mask Efuse value:0" );

uint rtw_kfree = 0;
module_param ( rtw_kfree, uint, 0644 );
MODULE_PARM_DESC ( rtw_kfree, "default kfree config value:0" );

uint rtw_pll_ref_clk_sel = CONFIG_RTW_PLL_REF_CLK_SEL;
module_param ( rtw_pll_ref_clk_sel, uint, 0644 );
MODULE_PARM_DESC ( rtw_pll_ref_clk_sel, "force pll_ref_clk_sel, 0xF:use autoload value" );

int rtw_fwoffload = 0; /* 0 default disable , 2 for enable */
module_param ( rtw_fwoffload, int, 0644 );
MODULE_PARM_DESC ( rtw_fwoffload, "for FW offload control" );



#if defined(CONFIG_CALIBRATE_TX_POWER_BY_REGULATORY) //eFuse: Regulatory selection=1
int rtw_tx_pwr_lmt_enable = 1;
int rtw_tx_pwr_by_rate = 1;
#elif defined(CONFIG_CALIBRATE_TX_POWER_TO_MAX)//eFuse: Regulatory selection=0
int rtw_tx_pwr_lmt_enable = 0;
int rtw_tx_pwr_by_rate = 1;
#else //eFuse: Regulatory selection=2
int rtw_tx_pwr_lmt_enable = 0;
int rtw_tx_pwr_by_rate = 0;
#endif



module_param ( rtw_tx_pwr_lmt_enable, int, 0644 );
MODULE_PARM_DESC ( rtw_tx_pwr_lmt_enable, "0:Disable, 1:Enable, 2: Depend on efuse" );

module_param ( rtw_tx_pwr_by_rate, int, 0644 );
MODULE_PARM_DESC ( rtw_tx_pwr_by_rate, "0:Disable, 1:Enable, 2: Depend on efuse" );

static int rtw_target_tx_pwr_2g_a[RATE_SECTION_NUM] = CONFIG_RTW_TARGET_TX_PWR_2G_A;
static int rtw_target_tx_pwr_2g_a_num = 0;
module_param_array ( rtw_target_tx_pwr_2g_a, int, &rtw_target_tx_pwr_2g_a_num, 0644 );
MODULE_PARM_DESC ( rtw_target_tx_pwr_2g_a, "2.4G target tx power (unit:dBm) of RF path A for each rate section, should match the real calibrate power, -1: undefined" );

static int rtw_target_tx_pwr_2g_b[RATE_SECTION_NUM] = CONFIG_RTW_TARGET_TX_PWR_2G_B;
static int rtw_target_tx_pwr_2g_b_num = 0;
module_param_array ( rtw_target_tx_pwr_2g_b, int, &rtw_target_tx_pwr_2g_b_num, 0644 );
MODULE_PARM_DESC ( rtw_target_tx_pwr_2g_b, "2.4G target tx power (unit:dBm) of RF path B for each rate section, should match the real calibrate power, -1: undefined" );

static int rtw_target_tx_pwr_2g_c[RATE_SECTION_NUM] = CONFIG_RTW_TARGET_TX_PWR_2G_C;
static int rtw_target_tx_pwr_2g_c_num = 0;
module_param_array ( rtw_target_tx_pwr_2g_c, int, &rtw_target_tx_pwr_2g_c_num, 0644 );
MODULE_PARM_DESC ( rtw_target_tx_pwr_2g_c, "2.4G target tx power (unit:dBm) of RF path C for each rate section, should match the real calibrate power, -1: undefined" );

static int rtw_target_tx_pwr_2g_d[RATE_SECTION_NUM] = CONFIG_RTW_TARGET_TX_PWR_2G_D;
static int rtw_target_tx_pwr_2g_d_num = 0;
module_param_array ( rtw_target_tx_pwr_2g_d, int, &rtw_target_tx_pwr_2g_d_num, 0644 );
MODULE_PARM_DESC ( rtw_target_tx_pwr_2g_d, "2.4G target tx power (unit:dBm) of RF path D for each rate section, should match the real calibrate power, -1: undefined" );




#ifdef CONFIG_IEEE80211_BAND_5GHZ
static int rtw_target_tx_pwr_5g_a[RATE_SECTION_NUM - 1] = CONFIG_RTW_TARGET_TX_PWR_5G_A;
static int rtw_target_tx_pwr_5g_a_num = 0;
module_param_array ( rtw_target_tx_pwr_5g_a, int, &rtw_target_tx_pwr_5g_a_num, 0644 );
MODULE_PARM_DESC ( rtw_target_tx_pwr_5g_a, "5G target tx power (unit:dBm) of RF path A for each rate section, should match the real calibrate power, -1: undefined" );

static int rtw_target_tx_pwr_5g_b[RATE_SECTION_NUM - 1] = CONFIG_RTW_TARGET_TX_PWR_5G_B;
static int rtw_target_tx_pwr_5g_b_num = 0;
module_param_array ( rtw_target_tx_pwr_5g_b, int, &rtw_target_tx_pwr_5g_b_num, 0644 );
MODULE_PARM_DESC ( rtw_target_tx_pwr_5g_b, "5G target tx power (unit:dBm) of RF path B for each rate section, should match the real calibrate power, -1: undefined" );

static int rtw_target_tx_pwr_5g_c[RATE_SECTION_NUM - 1] = CONFIG_RTW_TARGET_TX_PWR_5G_C;
static int rtw_target_tx_pwr_5g_c_num = 0;
module_param_array ( rtw_target_tx_pwr_5g_c, int, &rtw_target_tx_pwr_5g_c_num, 0644 );
MODULE_PARM_DESC ( rtw_target_tx_pwr_5g_c, "5G target tx power (unit:dBm) of RF path C for each rate section, should match the real calibrate power, -1: undefined" );

static int rtw_target_tx_pwr_5g_d[RATE_SECTION_NUM - 1] = CONFIG_RTW_TARGET_TX_PWR_5G_D;
static int rtw_target_tx_pwr_5g_d_num = 0;
module_param_array ( rtw_target_tx_pwr_5g_d, int, &rtw_target_tx_pwr_5g_d_num, 0644 );
MODULE_PARM_DESC ( rtw_target_tx_pwr_5g_d, "5G target tx power (unit:dBm) of RF path D for each rate section, should match the real calibrate power, -1: undefined" );
#endif /* CONFIG_IEEE80211_BAND_5GHZ */



int _netdev_open ( struct net_device *pnetdev );
int netdev_open ( struct net_device *pnetdev );
static int netdev_close ( struct net_device *pnetdev );




void rtw_regsty_load_target_tx_power ( struct registry_priv *regsty )
{
    int path, rs;
    int *target_tx_pwr;

    for ( path = RF_PATH_A; path < RF_PATH_MAX; path++ )
    {
        if ( path == RF_PATH_A )
            target_tx_pwr = rtw_target_tx_pwr_2g_a;
        else if ( path == RF_PATH_B )
            target_tx_pwr = rtw_target_tx_pwr_2g_b;
        else if ( path == RF_PATH_C )
            target_tx_pwr = rtw_target_tx_pwr_2g_c;
        else if ( path == RF_PATH_D )
            target_tx_pwr = rtw_target_tx_pwr_2g_d;

        for ( rs = CCK; rs < RATE_SECTION_NUM; rs++ )
            regsty->target_tx_pwr_2g[path][rs] = target_tx_pwr[rs];
    }

#ifdef CONFIG_IEEE80211_BAND_5GHZ

    for ( path = RF_PATH_A; path < RF_PATH_MAX; path++ )
    {
        if ( path == RF_PATH_A )
            target_tx_pwr = rtw_target_tx_pwr_5g_a;
        else if ( path == RF_PATH_B )
            target_tx_pwr = rtw_target_tx_pwr_5g_b;
        else if ( path == RF_PATH_C )
            target_tx_pwr = rtw_target_tx_pwr_5g_c;
        else if ( path == RF_PATH_D )
            target_tx_pwr = rtw_target_tx_pwr_5g_d;

        for ( rs = OFDM; rs < RATE_SECTION_NUM; rs++ )
            regsty->target_tx_pwr_5g[path][rs - 1] = target_tx_pwr[rs - 1];
    }

#endif /* CONFIG_IEEE80211_BAND_5GHZ */
}



uint loadparam ( _adapter *padapter )
{
    uint status = _SUCCESS;
    struct registry_priv  *registry_par = &padapter->registrypriv;

    _func_enter_;

    registry_par->chip_version = ( u8 ) rtw_chip_version;
    registry_par->rfintfs = ( u8 ) rtw_rfintfs;
    registry_par->lbkmode = ( u8 ) rtw_lbkmode;
    //registry_par->hci = (u8)hci;
    registry_par->network_mode  = ( u8 ) rtw_network_mode;

    _rtw_memcpy ( registry_par->ssid.Ssid, "ANY", 3 );
    registry_par->ssid.SsidLength = 3;

    registry_par->channel = ( u8 ) rtw_channel;
    registry_par->wireless_mode = ( u8 ) rtw_wireless_mode; //zbDebug: suppose it supports all modes at first!

    if ( IsSupported24G ( registry_par->wireless_mode ) && ( !IsSupported5G ( registry_par->wireless_mode ) ) && ( registry_par->channel > 14 ) )
    {
        registry_par->channel = 1;
    }
    else if ( IsSupported5G ( registry_par->wireless_mode ) && ( !IsSupported24G ( registry_par->wireless_mode ) ) && ( registry_par->channel <= 14 ) )
    {
        registry_par->channel = 36;
    }

    registry_par->vrtl_carrier_sense = ( u8 ) rtw_vrtl_carrier_sense ;
    registry_par->vcs_type = ( u8 ) rtw_vcs_type;
    registry_par->rts_thresh = ( u16 ) rtw_rts_thresh;
    registry_par->frag_thresh = ( u16 ) rtw_frag_thresh;
    registry_par->preamble = ( u8 ) rtw_preamble;
    registry_par->scan_mode = ( u8 ) rtw_scan_mode;
    registry_par->adhoc_tx_pwr = ( u8 ) rtw_adhoc_tx_pwr;
    registry_par->soft_ap = ( u8 ) rtw_soft_ap;
    registry_par->smart_ps = ( u8 ) rtw_smart_ps;
    registry_par->check_fw_ps = ( u8 ) rtw_check_fw_ps;
    registry_par->power_mgnt = ( u8 ) rtw_power_mgnt;
    registry_par->ips_mode = ( u8 ) rtw_ips_mode;
    registry_par->radio_enable = ( u8 ) rtw_radio_enable;
    registry_par->long_retry_lmt = ( u8 ) rtw_long_retry_lmt;
    registry_par->short_retry_lmt = ( u8 ) rtw_short_retry_lmt;
    registry_par->busy_thresh = ( u16 ) rtw_busy_thresh;
    //registry_par->qos_enable = (u8)rtw_qos_enable;
    registry_par->ack_policy = ( u8 ) rtw_ack_policy;
    registry_par->mp_mode = ( u8 ) rtw_mp_mode;
    registry_par->software_encrypt = ( u8 ) rtw_software_encrypt;
    registry_par->software_decrypt = ( u8 ) rtw_software_decrypt;

    registry_par->acm_method = ( u8 ) rtw_acm_method;
    registry_par->usb_rxagg_mode = ( u8 ) rtw_usb_rxagg_mode;

    //UAPSD
    registry_par->wmm_enable = ( u8 ) rtw_wmm_enable;
    registry_par->uapsd_enable = ( u8 ) rtw_uapsd_enable;
    registry_par->uapsd_max_sp = ( u8 ) rtw_uapsd_max_sp;
    registry_par->uapsd_acbk_en = ( u8 ) rtw_uapsd_acbk_en;
    registry_par->uapsd_acbe_en = ( u8 ) rtw_uapsd_acbe_en;
    registry_par->uapsd_acvi_en = ( u8 ) rtw_uapsd_acvi_en;
    registry_par->uapsd_acvo_en = ( u8 ) rtw_uapsd_acvo_en;

    registry_par->RegRfKFreeEnable = ( u8 ) rtw_rfkfree_enable;

#ifdef CONFIG_80211N_HT
    registry_par->ht_enable = ( u8 ) rtw_ht_enable;
    registry_par->bw_mode = ( u8 ) rtw_bw_mode;
    registry_par->ampdu_enable = ( u8 ) rtw_ampdu_enable;
    registry_par->rx_stbc = ( u8 ) rtw_rx_stbc;
    registry_par->ampdu_amsdu = ( u8 ) rtw_ampdu_amsdu;
    registry_par->short_gi = ( u8 ) rtw_short_gi;
    registry_par->ldpc_cap = ( u8 ) rtw_ldpc_cap;
    registry_par->stbc_cap = ( u8 ) rtw_stbc_cap;
    registry_par->beamform_cap = ( u8 ) rtw_beamform_cap;
    registry_par->beamformer_rf_num = ( u8 ) rtw_bfer_rf_number;
    registry_par->beamformee_rf_num = ( u8 ) rtw_bfee_rf_number;
#endif


#ifdef CONFIG_80211AC_VHT
    registry_par->vht_enable = ( u8 ) rtw_vht_enable;
    registry_par->ampdu_factor = ( u8 ) rtw_ampdu_factor;
    registry_par->vht_rate_sel = ( u8 ) rtw_vht_rate_sel;
#endif


    registry_par->lowrate_two_xmit = ( u8 ) rtw_lowrate_two_xmit;
    registry_par->rf_config = ( u8 ) rtw_rf_config;
    registry_par->low_power = ( u8 ) rtw_low_power;
    registry_par->wifi_spec = ( u8 ) rtw_wifi_spec;
    registry_par->channel_plan = ( u8 ) rtw_channel_plan;
    registry_par->special_rf_path = ( u8 ) rtw_special_rf_path;
    registry_par->bAcceptAddbaReq = ( u8 ) rtw_AcceptAddbaReq;
    registry_par->antdiv_cfg = ( u8 ) rtw_antdiv_cfg;
    registry_par->antdiv_type = ( u8 ) rtw_antdiv_type;
    registry_par->switch_usb3 = ( u8 ) rtw_switch_usb3;
    registry_par->hw_wps_pbc = ( u8 ) rtw_hw_wps_pbc;


#ifdef CONFIG_80211D
    registry_par->enable80211d = ( u8 ) rtw_80211d;
#endif

    snprintf ( registry_par->ifname, 16, "%s", ifname );
    snprintf ( registry_par->if2name, 16, "%s", if2name );

    //DBG_871X_LEVEL(_drv_always_, "zbzb============loadparam===========1.0====ifname:%s if2name:%s \n", ifname, if2name);


    registry_par->notch_filter = ( u8 ) rtw_notch_filter;
    registry_par->pll_ref_clk_sel = ( u8 ) rtw_pll_ref_clk_sel;

    registry_par->RegEnableTxPowerLimit = ( u8 ) rtw_tx_pwr_lmt_enable;
    registry_par->RegEnableTxPowerByRate = ( u8 ) rtw_tx_pwr_by_rate;

    rtw_regsty_load_target_tx_power ( registry_par );

    registry_par->RegPowerBase = 14;
    registry_par->TxBBSwing_2G = ( s8 ) rtw_TxBBSwing_2G;
    registry_par->TxBBSwing_5G = ( s8 ) rtw_TxBBSwing_5G;
    registry_par->bEn_RFE = 1;
    registry_par->RFE_Type = ( u8 ) rtw_RFE_type;
    registry_par->AmplifierType_2G = ( u8 ) rtw_amplifier_type_2g;
    registry_par->AmplifierType_5G = ( u8 ) rtw_amplifier_type_5g;
    registry_par->GLNA_Type = ( u8 ) rtw_GLNA_type;

    registry_par->qos_opt_enable = ( u8 ) rtw_qos_opt_enable;
    registry_par->hiq_filter = ( u8 ) rtw_hiq_filter;

    registry_par->adaptivity_en = ( u8 ) rtw_adaptivity_en;
    registry_par->adaptivity_mode = ( u8 ) rtw_adaptivity_mode;
    registry_par->adaptivity_dml = ( u8 ) rtw_adaptivity_dml;
    registry_par->adaptivity_dc_backoff = ( u8 ) rtw_adaptivity_dc_backoff;
    registry_par->adaptivity_th_l2h_ini = ( s8 ) rtw_adaptivity_th_l2h_ini;
    registry_par->adaptivity_th_edcca_hl_diff = ( s8 ) rtw_adaptivity_th_edcca_hl_diff;

    registry_par->boffefusemask = ( u8 ) rtw_OffEfuseMask;
    registry_par->bFileMaskEfuse = ( u8 ) rtw_FileMaskEfuse;


    registry_par->Regfwoffload = ( u8 ) rtw_fwoffload;
    _func_exit_;

    return status;
}





/**
 * rtw_net_set_mac_address
 * This callback function is used for the Media Access Control address
 * of each net_device needs to be changed.
 *
 * Arguments:
 * @pnetdev: net_device pointer.
 * @addr: new MAC address.
 *
 * Return:
 * ret = 0: Permit to change net_device's MAC address.
 * ret = -1 (Default): Operation not permitted.
 *
 * Auther: Arvin Liu
 * Date: 2015/05/29
 */
static int rtw_net_set_mac_address ( struct net_device *pnetdev, void *addr )
{
    _adapter *padapter = ( _adapter * ) rtw_netdev_priv ( pnetdev );
    struct mlme_priv *pmlmepriv = &padapter->mlmepriv;
    struct sockaddr *sa = ( struct sockaddr * ) addr;
    int ret = -1;

    /* only the net_device is in down state to permit modifying mac addr */
    if ( ( pnetdev->flags & IFF_UP ) == _TRUE )
    {
        DBG_871X ( FUNC_ADPT_FMT": The net_device's is not in down state\n"
                   , FUNC_ADPT_ARG ( padapter ) );

        return ret;
    }

    /* if the net_device is linked, it's not permit to modify mac addr */
    if ( check_fwstate ( pmlmepriv, _FW_UNDER_LINKING ) ||
         check_fwstate ( pmlmepriv, _FW_LINKED ) ||
         check_fwstate ( pmlmepriv, _FW_UNDER_SURVEY ) )
    {
        DBG_871X ( FUNC_ADPT_FMT": The net_device's is not idle currently\n"
                   , FUNC_ADPT_ARG ( padapter ) );

        return ret;
    }

    /* check whether the input mac address is valid to permit modifying mac addr */
    if ( rtw_check_invalid_mac_address ( sa->sa_data, _FALSE ) == _TRUE )
    {
        DBG_871X ( FUNC_ADPT_FMT": Invalid Mac Addr for "MAC_FMT"\n"
                   , FUNC_ADPT_ARG ( padapter ), MAC_ARG ( sa->sa_data ) );

        return ret;
    }

    _rtw_memcpy ( adapter_mac_addr ( padapter ), sa->sa_data, ETH_ALEN ); /* set mac addr to adapter */
    _rtw_memcpy ( pnetdev->dev_addr, sa->sa_data, ETH_ALEN ); /* set mac addr to net_device */

    rtw_ps_deny ( padapter, PS_DENY_IOCTL );
    LeaveAllPowerSaveModeDirect ( padapter ); /* leave PS mode for guaranteeing to access hw register successfully */
    rtw_hal_set_hwreg ( padapter, HW_VAR_MAC_ADDR, sa->sa_data ); /* set mac addr to mac register */
    rtw_ps_deny_cancel ( padapter, PS_DENY_IOCTL );

    DBG_871X ( FUNC_ADPT_FMT": Set Mac Addr to "MAC_FMT" Successfully\n"
               , FUNC_ADPT_ARG ( padapter ), MAC_ARG ( sa->sa_data ) );

    ret = 0;

    return ret;
}



static struct net_device_stats *rtw_net_get_stats ( struct net_device *pnetdev )
{
    _adapter *padapter = ( _adapter * ) rtw_netdev_priv ( pnetdev );
    struct xmit_priv *pxmitpriv = & ( padapter->xmitpriv );
    struct recv_priv *precvpriv = & ( padapter->recvpriv );

    padapter->stats.tx_packets = pxmitpriv->tx_pkts;//pxmitpriv->tx_pkts++;
    padapter->stats.rx_packets = precvpriv->rx_pkts;//precvpriv->rx_pkts++;
    padapter->stats.tx_dropped = pxmitpriv->tx_drop;
    padapter->stats.rx_dropped = precvpriv->rx_drop;
    padapter->stats.tx_bytes = pxmitpriv->tx_bytes;
    padapter->stats.rx_bytes = precvpriv->rx_bytes;

    return &padapter->stats;
}




/*
 * AC to queue mapping
 *
 * AC_VO -> queue 0
 * AC_VI -> queue 1
 * AC_BE -> queue 2
 * AC_BK -> queue 3
 */
static const u16 rtw_1d_to_queue[8] = { 2, 3, 3, 2, 1, 1, 0, 0 };



/* Given a data frame determine the 802.1p/1d tag to use. */
unsigned int rtw_classify8021d ( struct sk_buff *skb )
{
    unsigned int dscp;

    /* skb->priority values from 256->263 are magic values to
     * directly indicate a specific 802.1d priority.  This is used
     * to allow 802.1d priority to be passed directly in from VLAN
     * tags, etc.
     */
    if ( skb->priority >= 256 && skb->priority <= 263 )
        return skb->priority - 256;

    switch ( skb->protocol )
    {
        case htons ( ETH_P_IP ) :
            dscp = ip_hdr ( skb )->tos & 0xfc;
            break;

        default:
            return 0;
    }

    return dscp >> 5;
}



static u16 rtw_select_queue ( struct net_device *dev, struct sk_buff *skb
                              , void *accel_priv
                              , select_queue_fallback_t fallback
                            )
{
    _adapter    *padapter = rtw_netdev_priv ( dev );
    struct mlme_priv *pmlmepriv = &padapter->mlmepriv;

    skb->priority = rtw_classify8021d ( skb );

    if ( pmlmepriv->acm_mask != 0 )
    {
        skb->priority = qos_acm ( pmlmepriv->acm_mask, skb->priority );
    }

    return rtw_1d_to_queue[skb->priority];
}



u16 rtw_recv_select_queue ( struct sk_buff *skb )
{
    struct iphdr *piphdr;
    unsigned int dscp;
    u16 eth_type;
    u32 priority;
    u8 *pdata = skb->data;

    _rtw_memcpy ( &eth_type, pdata + ( ETH_ALEN << 1 ), 2 );

    switch ( eth_type )
    {
        case htons ( ETH_P_IP ) :

            piphdr = ( struct iphdr * ) ( pdata + ETH_HLEN );

            dscp = piphdr->tos & 0xfc;

            priority = dscp >> 5;

            break;

        default:
            priority = 0;
    }

    return rtw_1d_to_queue[priority];

}






static int rtw_ndev_notifier_call ( struct notifier_block * nb, unsigned long state, void *ptr )
{
    struct net_device *dev = netdev_notifier_info_to_dev ( ptr );

    //_adapter *adapter = rtw_netdev_priv ( dev );
    //DBG_871X_LEVEL(_drv_always_, "zbzb===========rtw_ndev_notifier_call=========1.0\n");

    if ( dev->netdev_ops->ndo_do_ioctl != rtw_ioctl )
        return NOTIFY_DONE;

    DBG_871X_LEVEL ( _drv_info_, FUNC_NDEV_FMT" state:%lu\n", FUNC_NDEV_ARG ( dev ), state );

    switch ( state )
    {
        case NETDEV_CHANGENAME:
            //DBG_871X_LEVEL(_drv_always_, "zbzb===========rtw_ndev_notifier_call=========2.0===dev->name: %s\n", dev->name);
            //strncpy(adapter->old_ifname, dev->name, IFNAMSIZ);
            //strncpy(dev->name, "wlan0", IFNAMSIZ);
            //rtw_adapter_proc_replace ( dev );
            break;
    }

    return NOTIFY_DONE;
}




static struct notifier_block rtw_ndev_notifier =
{
    .notifier_call = rtw_ndev_notifier_call,
};


int rtw_ndev_notifier_register ( void )
{
    return register_netdevice_notifier ( &rtw_ndev_notifier );
}



void rtw_ndev_notifier_unregister ( void )
{
    unregister_netdevice_notifier ( &rtw_ndev_notifier );
}




int rtw_ndev_init ( struct net_device *dev )
{
    _adapter *adapter = rtw_netdev_priv ( dev );

    //DBG_871X_LEVEL(_drv_always_, "zbzb============rtw_ndev_init===========1.0====\n");

    DBG_871X_LEVEL ( _drv_always_, FUNC_ADPT_FMT" if%d mac_addr="MAC_FMT"\n"
                     , FUNC_ADPT_ARG ( adapter ), ( adapter->iface_id + 1 ), MAC_ARG ( dev->dev_addr ) );
    strncpy ( adapter->old_ifname, dev->name, IFNAMSIZ );
    adapter->old_ifname[IFNAMSIZ - 1] = '\0';

    //DBG_871X_LEVEL(_drv_always_, "zbzb============rtw_ndev_init===========2.0====old_ifname: %s\n", adapter->old_ifname);
    //rtw_adapter_proc_init ( dev );

    return 0;
}


void rtw_ndev_uninit ( struct net_device *dev )
{
    _adapter *adapter = rtw_netdev_priv ( dev );

    DBG_871X_LEVEL ( _drv_always_, FUNC_ADPT_FMT" if%d\n"
                     , FUNC_ADPT_ARG ( adapter ), ( adapter->iface_id + 1 ) );
    //rtw_adapter_proc_deinit ( dev );
}



static const struct net_device_ops rtw_netdev_ops =  //zbDebug: Callback Functions (Network)
{
    .ndo_init = rtw_ndev_init,
    .ndo_uninit = rtw_ndev_uninit,

	//
    .ndo_open = netdev_open,
    .ndo_stop = netdev_close,

	//
    .ndo_start_xmit = rtw_xmit_entry,  //zbDebug: Xmit ( Entry Point )

	//
    .ndo_select_queue   = rtw_select_queue,

	//
    .ndo_set_mac_address = rtw_net_set_mac_address,

	//
    .ndo_get_stats = rtw_net_get_stats,

	//
    .ndo_do_ioctl = rtw_ioctl,
};



int rtw_init_netdev_name ( struct net_device *pnetdev, const char *ifname )
{
    _adapter *padapter = rtw_netdev_priv ( pnetdev );

    //DBG_871X_LEVEL(_drv_always_, "zbzb===========rtw_init_netdev_name========1.0==========\n");
    //DBG_871X_LEVEL(_drv_always_, "zbzb===========rtw_init_netdev_name========2.0==========ifname:%s\n", ifname);
    if ( dev_alloc_name ( pnetdev, ifname) < 0 )
    {
        RT_TRACE ( _module_os_intfs_c_, _drv_err_, ( "dev_alloc_name, fail! \n" ) );
    }

    netif_carrier_off ( pnetdev );
    //rtw_netif_stop_queue(pnetdev);

    return 0;
}


void rtw_hook_if_ops ( struct net_device *ndev )
{
    ndev->netdev_ops = &rtw_netdev_ops; //zbgcl
}



struct net_device *rtw_init_netdev ( _adapter *old_padapter )
{
    _adapter *padapter;
    struct net_device *pnetdev;

    RT_TRACE ( _module_os_intfs_c_, _drv_info_, ( "+init_net_dev\n" ) );

    if ( old_padapter != NULL )
        pnetdev = rtw_alloc_etherdev_with_old_priv ( sizeof ( _adapter ), ( void * ) old_padapter );
    else
        pnetdev = rtw_alloc_etherdev ( sizeof ( _adapter ) );

    if ( !pnetdev )
        return NULL;

    padapter = rtw_netdev_priv ( pnetdev );
    padapter->pnetdev = pnetdev;



    rtw_hook_if_ops ( pnetdev );

    //pnetdev->tx_timeout = NULL;
    pnetdev->watchdog_timeo = HZ * 3; /* 3 second timeout */

#ifdef CONFIG_WIRELESS_EXT
    pnetdev->wireless_handlers = ( struct iw_handler_def * ) &rtw_handlers_def;  //zbDebug: Callback Functions (WEXT)
#endif

    return pnetdev;
}




int rtw_os_ndev_alloc ( _adapter *adapter )
{
    int ret = _FAIL;
    struct net_device *ndev = NULL;

    ndev = rtw_init_netdev ( adapter );

    if ( ndev == NULL )
    {
        rtw_warn_on ( 1 );
        goto exit;
    }


    SET_NETDEV_DEV ( ndev, dvobj_to_dev ( adapter_to_dvobj ( adapter ) ) );


#if defined(CONFIG_IOCTL_CFG80211)

    if ( rtw_cfg80211_ndev_res_alloc ( adapter ) != _SUCCESS )
    {
        rtw_warn_on ( 1 );
        goto free_ndev;
    }

#endif

    ret = _SUCCESS;

free_ndev:

    if ( ret != _SUCCESS && ndev )
        rtw_free_netdev ( ndev );

exit:
    return ret;
}



void rtw_os_ndev_free ( _adapter *adapter )
{
#if defined(CONFIG_IOCTL_CFG80211)
    rtw_cfg80211_ndev_res_free ( adapter );
#endif

    if ( adapter->pnetdev )
    {
        rtw_free_netdev ( adapter->pnetdev );
        adapter->pnetdev = NULL;
    }
}




int rtw_os_ndev_register ( _adapter *adapter, char *name )
{
    int ret = _SUCCESS;
    struct net_device *ndev = adapter->pnetdev;

#if defined(CONFIG_IOCTL_CFG80211)

    if ( rtw_cfg80211_ndev_res_register ( adapter ) != _SUCCESS )
    {
        rtw_warn_on ( 1 );
        ret = _FAIL;
        goto exit;
    }

#endif

    /* alloc netdev name */
    rtw_init_netdev_name ( ndev, name );

    _rtw_memcpy ( ndev->dev_addr, adapter_mac_addr ( adapter ), ETH_ALEN );

    //DBG_871X_LEVEL(_drv_always_, "zbzb============rtw_os_ndev_register===========1.0====ndev->name:%s\n", ndev->name);

    /* Tell the network stack we exist */
    if ( register_netdev ( ndev ) != 0 )
    {
        DBG_871X ( FUNC_NDEV_FMT" if%d Failed!\n", FUNC_NDEV_ARG ( ndev ), ( adapter->iface_id + 1 ) );
        ret = _FAIL;
    }

    //DBG_871X_LEVEL(_drv_always_, "zbzb============rtw_os_ndev_register===========1.1====ndev->name:%s\n", ndev->name);

#if defined(CONFIG_IOCTL_CFG80211)

    if ( ret != _SUCCESS )
    {
        rtw_cfg80211_ndev_res_unregister ( adapter );
        rtw_wiphy_unregister ( adapter_to_wiphy ( adapter ) );
    }
#endif

exit:
    return ret;
}




void rtw_os_ndev_unregister ( _adapter *adapter )
{
    struct net_device *netdev = NULL;

    if ( adapter == NULL )
        return;

    adapter->ndev_unregistering = 1;

    netdev = adapter->pnetdev;

#if defined(CONFIG_IOCTL_CFG80211)
    rtw_cfg80211_ndev_res_unregister ( adapter );
#endif

    if ( ( adapter->DriverState != DRIVER_DISAPPEAR ) && netdev )
        unregister_netdev ( netdev ); /* will call netdev_close() */

#if defined(CONFIG_IOCTL_CFG80211)
    rtw_wiphy_unregister ( adapter_to_wiphy ( adapter ) );
#endif

    adapter->ndev_unregistering = 0;
}




/**
 * rtw_os_ndev_init - Allocate and register OS layer net device and relating structures for @adapter
 * @adapter: the adapter on which this function applies
 * @name: the requesting net device name
 *
 * Returns:
 * _SUCCESS or _FAIL
 */
int rtw_os_ndev_init ( _adapter *adapter, char *name )
{
    int ret = _FAIL;

    if ( rtw_os_ndev_alloc ( adapter ) != _SUCCESS )
        goto exit;

    if ( rtw_os_ndev_register ( adapter, name ) != _SUCCESS )
        goto os_ndev_free;

    ret = _SUCCESS;

os_ndev_free:

    if ( ret != _SUCCESS )
        rtw_os_ndev_free ( adapter );

exit:
    return ret;
}




/**
 * rtw_os_ndev_deinit - Unregister and free OS layer net device and relating structures for @adapter
 * @adapter: the adapter on which this function applies
 */
void rtw_os_ndev_deinit ( _adapter *adapter )
{
    rtw_os_ndev_unregister ( adapter );
    rtw_os_ndev_free ( adapter );
}

int rtw_os_ndevs_alloc ( struct dvobj_priv *dvobj )
{
    int i, status = _SUCCESS;
    _adapter *adapter;

#if defined(CONFIG_IOCTL_CFG80211)

    if ( rtw_cfg80211_dev_res_alloc ( dvobj ) != _SUCCESS )
    {
        rtw_warn_on ( 1 );
        status = _FAIL;
        goto exit;
    }

#endif

    for ( i = 0; i < dvobj->iface_nums; i++ )
    {

        if ( i >= IFACE_ID_MAX )
        {
            DBG_871X_LEVEL ( _drv_err_, "%s %d >= IFACE_ID_MAX\n", __func__, i );
            rtw_warn_on ( 1 );
            continue;
        }

        adapter = dvobj->padapters[i];

        if ( adapter && !adapter->pnetdev )
        {
            status = rtw_os_ndev_alloc ( adapter );

            if ( status != _SUCCESS )
            {
                rtw_warn_on ( 1 );
                break;
            }
        }
    }

    if ( status != _SUCCESS )
    {
        for ( ; i >= 0; i-- )
        {
            adapter = dvobj->padapters[i];

            if ( adapter && adapter->pnetdev )
                rtw_os_ndev_free ( adapter );
        }
    }

#if defined(CONFIG_IOCTL_CFG80211)

    if ( status != _SUCCESS )
        rtw_cfg80211_dev_res_free ( dvobj );

#endif
exit:
    return status;
}




void rtw_os_ndevs_free ( struct dvobj_priv *dvobj )
{
    int i;
    _adapter *adapter = NULL;

    for ( i = 0; i < dvobj->iface_nums; i++ )
    {

        if ( i >= IFACE_ID_MAX )
        {
            DBG_871X_LEVEL ( _drv_err_, "%s %d >= IFACE_ID_MAX\n", __func__, i );
            rtw_warn_on ( 1 );
            continue;
        }

        adapter = dvobj->padapters[i];

        if ( adapter == NULL )
            continue;

        rtw_os_ndev_free ( adapter );
    }

#if defined(CONFIG_IOCTL_CFG80211)
    rtw_cfg80211_dev_res_free ( dvobj );
#endif
}



u32 rtw_start_drv_threads ( _adapter *padapter )
{
    u32 _status = _SUCCESS;

    RT_TRACE ( _module_os_intfs_c_, _drv_info_, ( "+rtw_start_drv_threads\n" ) );

    if ( is_primary_adapter ( padapter ) )
    {
        padapter->cmdThread = kthread_run ( rtw_cmd_thread, padapter, "RTW_CMD_THREAD" );

        if ( IS_ERR ( padapter->cmdThread ) )
            _status = _FAIL;
        else
            _rtw_down_sema ( &padapter->cmdpriv.terminate_cmdthread_sema ); //wait for cmd_thread to run
    }

    rtw_hal_start_thread ( padapter );
    return _status;

}



void rtw_stop_drv_threads ( _adapter *padapter )
{
    RT_TRACE ( _module_os_intfs_c_, _drv_info_, ( "+rtw_stop_drv_threads\n" ) );

    if ( is_primary_adapter ( padapter ) )
        rtw_stop_cmd_thread ( padapter );

    rtw_hal_stop_thread ( padapter );
}




u8 rtw_init_default_value ( _adapter *padapter );
u8 rtw_init_default_value ( _adapter *padapter )
{
    u8 ret  = _SUCCESS;
    struct registry_priv* pregistrypriv = &padapter->registrypriv;
    struct xmit_priv    *pxmitpriv = &padapter->xmitpriv;
    struct mlme_priv *pmlmepriv = &padapter->mlmepriv;
    struct security_priv *psecuritypriv = &padapter->securitypriv;

    //xmit_priv
    pxmitpriv->vcs_setting = pregistrypriv->vrtl_carrier_sense;
    pxmitpriv->vcs = pregistrypriv->vcs_type;
    pxmitpriv->vcs_type = pregistrypriv->vcs_type;
    //pxmitpriv->rts_thresh = pregistrypriv->rts_thresh;
    pxmitpriv->frag_len = pregistrypriv->frag_thresh;

    //recv_priv

    //mlme_priv
    pmlmepriv->scan_mode = SCAN_ACTIVE;

    //qos_priv
    //pmlmepriv->qospriv.qos_option = pregistrypriv->wmm_enable;

    //ht_priv
#ifdef CONFIG_80211N_HT
    pmlmepriv->htpriv.ampdu_enable = _FALSE;//set to disabled
#endif

    //security_priv
    //rtw_get_encrypt_decrypt_from_registrypriv(padapter);
    psecuritypriv->binstallGrpkey = _FAIL;

    psecuritypriv->sw_encrypt = pregistrypriv->software_encrypt;
    psecuritypriv->sw_decrypt = pregistrypriv->software_decrypt;

    psecuritypriv->dot11AuthAlgrthm = dot11AuthAlgrthm_Open; //open system
    psecuritypriv->dot11PrivacyAlgrthm = _NO_PRIVACY_;

    psecuritypriv->dot11PrivacyKeyIndex = 0;

    psecuritypriv->dot118021XGrpPrivacy = _NO_PRIVACY_;
    psecuritypriv->dot118021XGrpKeyid = 1;

    psecuritypriv->ndisauthtype = Ndis802_11AuthModeOpen;
    psecuritypriv->ndisencryptstatus = Ndis802_11WEPDisabled;


    //pwrctrl_priv


    //registry_priv
    rtw_init_registrypriv_dev_network ( padapter );


	//==================Fill network related information=======================
    rtw_update_registrypriv_dev_network ( padapter );


    //hal_priv
    rtw_hal_def_value_init ( padapter );

    //misc.
    RTW_ENABLE_FUNC ( padapter, DF_RX_BIT );
    RTW_ENABLE_FUNC ( padapter, DF_TX_BIT );
    padapter->bLinkInfoDump = 0;
    padapter->bNotifyChannelChange = _FALSE;


    //for debug purpose
    padapter->fix_rate = 0xFF;
    padapter->data_fb = 0;
    padapter->driver_ampdu_spacing = 0xFF;
    padapter->driver_rx_ampdu_factor =  0xFF;
    padapter->driver_rx_ampdu_spacing = 0xFF;
    padapter->fix_rx_ampdu_accept = RX_AMPDU_ACCEPT_INVALID;
    padapter->fix_rx_ampdu_size = RX_AMPDU_SIZE_INVALID;

    return ret;
}




struct dvobj_priv *devobj_init ( void )
{
    struct dvobj_priv *pdvobj = NULL;

    if ( ( pdvobj = ( struct dvobj_priv* ) rtw_zmalloc ( sizeof ( *pdvobj ) ) ) == NULL )
    {
        return NULL;
    }

    _rtw_mutex_init ( &pdvobj->hw_init_mutex );
    _rtw_mutex_init ( &pdvobj->h2c_fwcmd_mutex );
    _rtw_mutex_init ( &pdvobj->setch_mutex );
    _rtw_mutex_init ( &pdvobj->setbw_mutex );


    pdvobj->processing_dev_remove = _FALSE;

    ATOMIC_SET ( &pdvobj->disable_func, 0 );

    rtw_macid_ctl_init ( &pdvobj->macid_ctl );
    _rtw_spinlock_init ( &pdvobj->cam_ctl.lock );
    _rtw_mutex_init ( &pdvobj->cam_ctl.sec_cam_access_mutex );

    return pdvobj;

}



void devobj_deinit ( struct dvobj_priv *pdvobj )
{
    if ( !pdvobj )
        return;

    /* TODO: use rtw_os_ndevs_deinit instead at the first stage of driver's dev deinit function */
#if defined(CONFIG_IOCTL_CFG80211)
    rtw_cfg80211_dev_res_free ( pdvobj );
#endif

    _rtw_mutex_free ( &pdvobj->hw_init_mutex );
    _rtw_mutex_free ( &pdvobj->h2c_fwcmd_mutex );
    _rtw_mutex_free ( &pdvobj->setch_mutex );
    _rtw_mutex_free ( &pdvobj->setbw_mutex );

    rtw_macid_ctl_deinit ( &pdvobj->macid_ctl );
    _rtw_spinlock_free ( &pdvobj->cam_ctl.lock );
    _rtw_mutex_free ( &pdvobj->cam_ctl.sec_cam_access_mutex );

    rtw_mfree ( ( u8* ) pdvobj, sizeof ( *pdvobj ) );
}




u8 rtw_reset_drv_sw ( _adapter *padapter )
{
    u8  ret8 = _SUCCESS;
    struct mlme_priv *pmlmepriv = &padapter->mlmepriv;
    struct pwrctrl_priv *pwrctrlpriv = adapter_to_pwrctl ( padapter );

    //hal_priv
    if ( is_primary_adapter ( padapter ) )
        rtw_hal_def_value_init ( padapter );

    RTW_ENABLE_FUNC ( padapter, DF_RX_BIT );
    RTW_ENABLE_FUNC ( padapter, DF_TX_BIT );
    padapter->bLinkInfoDump = 0;

    padapter->xmitpriv.tx_pkts = 0;
    padapter->recvpriv.rx_pkts = 0;

    pmlmepriv->LinkDetectInfo.bBusyTraffic = _FALSE;

    //pmlmepriv->LinkDetectInfo.TrafficBusyState = _FALSE;
    pmlmepriv->LinkDetectInfo.TrafficTransitionCount = 0;
    pmlmepriv->LinkDetectInfo.LowPowerTransitionCount = 0;

    _clr_fwstate_ ( pmlmepriv, _FW_UNDER_SURVEY | _FW_UNDER_LINKING );

    pwrctrlpriv->pwr_state_check_cnts = 0;

    //mlmeextpriv
    mlmeext_set_scan_state ( &padapter->mlmeextpriv, SCAN_DISABLE );

#ifdef CONFIG_NEW_SIGNAL_STAT_PROCESS
    rtw_set_signal_stat_timer ( &padapter->recvpriv );
#endif

    return ret8;
}




u8 rtw_init_drv_sw ( _adapter *padapter )
{

    u8  ret8 = _SUCCESS;

    _func_enter_;

	//
    ret8 = rtw_init_default_value ( padapter );

	//
    if ( ( rtw_init_cmd_priv ( &padapter->cmdpriv ) ) == _FAIL )
    {
        RT_TRACE ( _module_os_intfs_c_, _drv_err_, ( "\n Can't init cmd_priv\n" ) );
        ret8 = _FAIL;
        goto exit;
    }
    padapter->cmdpriv.padapter = padapter;

	//
    if ( ( rtw_init_evt_priv ( &padapter->evtpriv ) ) == _FAIL )
    {
        RT_TRACE ( _module_os_intfs_c_, _drv_err_, ( "\n Can't init evt_priv\n" ) );
        ret8 = _FAIL;
        goto exit;
    }

	//
    if ( rtw_init_mlme_priv ( padapter ) == _FAIL )
    {
        RT_TRACE ( _module_os_intfs_c_, _drv_err_, ( "\n Can't init mlme_priv\n" ) );
        ret8 = _FAIL;
        goto exit;
    }

	//
    if ( init_mlme_ext_priv ( padapter ) == _FAIL )
    {
        RT_TRACE ( _module_os_intfs_c_, _drv_err_, ( "\n Can't init mlme_ext_priv\n" ) );
        ret8 = _FAIL;
        goto exit;
    }

	//
    if ( _rtw_init_xmit_priv ( &padapter->xmitpriv, padapter ) == _FAIL )
    {
        DBG_871X ( "Can't _rtw_init_xmit_priv\n" );
        ret8 = _FAIL;
        goto exit;
    }


	//
    if ( _rtw_init_recv_priv ( &padapter->recvpriv, padapter ) == _FAIL )
    {
        DBG_871X ( "Can't _rtw_init_recv_priv\n" );
        ret8 = _FAIL;
        goto exit;
    }

    // add for , none 11w also can use
    _rtw_spinlock_init ( &padapter->security_key_mutex );

    // We don't need to memset padapter->XXX to zero, because adapter is allocated by rtw_zvmalloc().
    //_rtw_memset((unsigned char *)&padapter->securitypriv, 0, sizeof (struct security_priv));

    //_init_timer(&(padapter->securitypriv.tkip_timer), padapter->pifp, rtw_use_tkipkey_handler, padapter);

    if ( _rtw_init_sta_priv ( &padapter->stapriv ) == _FAIL )
    {
        DBG_871X ( "Can't _rtw_init_sta_priv\n" );
        ret8 = _FAIL;
        goto exit;
    }

    padapter->stapriv.padapter = padapter;
    padapter->setband = WIFI_FREQUENCY_BAND_AUTO;
    padapter->fix_rate = 0xFF;
    padapter->data_fb = 0;
    padapter->fix_rx_ampdu_accept = RX_AMPDU_ACCEPT_INVALID;
    padapter->fix_rx_ampdu_size = RX_AMPDU_SIZE_INVALID;


    rtw_init_bcmc_stainfo ( padapter );

    rtw_init_pwrctrl_priv ( padapter );

    //_rtw_memset((u8 *)&padapter->qospriv, 0, sizeof (struct qos_priv));//move to mlme_priv


	//
    rtw_hal_dm_init ( padapter );

	//
    rtw_hal_sw_led_init ( padapter );

exit:
    _func_exit_;

    return ret8;

}



void rtw_cancel_all_timer ( _adapter *padapter )
{
    RT_TRACE ( _module_os_intfs_c_, _drv_info_, ( "+rtw_cancel_all_timer\n" ) );

    _cancel_timer_ex ( &padapter->mlmepriv.assoc_timer );
    RT_TRACE ( _module_os_intfs_c_, _drv_info_, ( "rtw_cancel_all_timer:cancel association timer complete!\n" ) );


    _cancel_timer_ex ( &padapter->mlmepriv.scan_to_timer );
    RT_TRACE ( _module_os_intfs_c_, _drv_info_, ( "rtw_cancel_all_timer:cancel scan_to_timer!\n" ) );



    _cancel_timer_ex ( &padapter->mlmepriv.dynamic_chk_timer );
    RT_TRACE ( _module_os_intfs_c_, _drv_info_, ( "rtw_cancel_all_timer:cancel dynamic_chk_timer!\n" ) );

    // cancel sw led timer
    rtw_hal_sw_led_deinit ( padapter );
    RT_TRACE ( _module_os_intfs_c_, _drv_info_, ( "rtw_cancel_all_timer:cancel DeInitSwLeds! \n" ) );

    _cancel_timer_ex ( & ( adapter_to_pwrctl ( padapter )->pwr_state_check_timer ) );



#ifdef CONFIG_NEW_SIGNAL_STAT_PROCESS
    _cancel_timer_ex ( &padapter->recvpriv.signal_stat_timer );
#endif
    //cancel dm timer
    rtw_hal_dm_deinit ( padapter );
}




u8 rtw_free_drv_sw ( _adapter *padapter )
{
    RT_TRACE ( _module_os_intfs_c_, _drv_info_, ( "==>rtw_free_drv_sw" ) );


    //we can call rtw_p2p_enable here, but:
    // 1. rtw_p2p_enable may have IO operation
    // 2. rtw_p2p_enable is bundled with wext interface
    // add for , none 11w also can use
    _rtw_spinlock_free ( &padapter->security_key_mutex );

    free_mlme_ext_priv ( &padapter->mlmeextpriv );


    rtw_free_cmd_priv ( &padapter->cmdpriv );

    rtw_free_evt_priv ( &padapter->evtpriv );

    rtw_free_mlme_priv ( &padapter->mlmepriv );

    //free_io_queue(padapter);

    _rtw_free_xmit_priv ( &padapter->xmitpriv );

    _rtw_free_sta_priv ( &padapter->stapriv ); //will free bcmc_stainfo here

    _rtw_free_recv_priv ( &padapter->recvpriv );

    rtw_free_pwrctrl_priv ( padapter );

    //rtw_mfree((void *)padapter, sizeof (padapter));


    rtw_hal_free_data ( padapter );

    RT_TRACE ( _module_os_intfs_c_, _drv_info_, ( "<==rtw_free_drv_sw\n" ) );

    //free the old_pnetdev
    if ( padapter->rereg_nd_name_priv.old_pnetdev )
    {
        free_netdev ( padapter->rereg_nd_name_priv.old_pnetdev );
        padapter->rereg_nd_name_priv.old_pnetdev = NULL;
    }

    // clear pbuddy_adapter to avoid access wrong pointer.
    if ( padapter->pbuddy_adapter != NULL )
    {
        padapter->pbuddy_adapter->pbuddy_adapter = NULL;
    }

    RT_TRACE ( _module_os_intfs_c_, _drv_info_, ( "-rtw_free_drv_sw\n" ) );

    return _SUCCESS;

}




int rtw_os_ndevs_register ( struct dvobj_priv *dvobj )
{
    int i, status = _SUCCESS;
    struct registry_priv *regsty = dvobj_to_regsty ( dvobj );
    _adapter *adapter;

#if defined(CONFIG_IOCTL_CFG80211)

    if ( rtw_cfg80211_dev_res_register ( dvobj ) != _SUCCESS )
    {
        rtw_warn_on ( 1 );
        status = _FAIL;
        goto exit;
    }

#endif

    //
    //DBG_871X_LEVEL(_drv_always_, "zbzb============rtw_os_ndevs_register===========1.0====iface_nums: %d\n", dvobj->iface_nums);

    for ( i = 0; i < dvobj->iface_nums; i++ )
    {

        if ( i >= IFACE_ID_MAX )
        {
            DBG_871X_LEVEL ( _drv_err_, "%s %d >= IFACE_ID_MAX\n", __func__, i );
            rtw_warn_on ( 1 );
            continue;
        }

        adapter = dvobj->padapters[i];

        if ( adapter )
        {
            char *name;

            if ( adapter->iface_id == IFACE_ID0 )
            {
                //strncpy (regsty->ifname, "R0", IFNAMSIZ);
                name = regsty->ifname;
                //DBG_871X_LEVEL(_drv_always_, "zbzb============rtw_os_ndevs_register===========2.0a====regsty->ifname:%s\n", regsty->ifname);

            }
            else if ( adapter->iface_id == IFACE_ID1 )
            {
                name = regsty->if2name;
                //DBG_871X_LEVEL(_drv_always_, "zbzb============rtw_os_ndevs_register===========2.0b====regsty->if2name:%s\n", regsty->if2name);
            }
            else
            {
                name = "wlan%d";
            }

            status = rtw_os_ndev_register ( adapter, name );

            if ( status != _SUCCESS )
            {
                rtw_warn_on ( 1 );
                break;
            }
        }
    }

    if ( status != _SUCCESS )
    {
        for ( ; i >= 0; i-- )
        {
            adapter = dvobj->padapters[i];

            if ( adapter )
                rtw_os_ndev_unregister ( adapter );
        }
    }

#if defined(CONFIG_IOCTL_CFG80211)

    if ( status != _SUCCESS )
        rtw_cfg80211_dev_res_unregister ( dvobj );

#endif
exit:
    return status;
}



void rtw_os_ndevs_unregister ( struct dvobj_priv *dvobj )
{
    int i;
    _adapter *adapter = NULL;

    for ( i = 0; i < dvobj->iface_nums; i++ )
    {
        adapter = dvobj->padapters[i];

        if ( adapter == NULL )
            continue;

        rtw_os_ndev_unregister ( adapter );
    }

#if defined(CONFIG_IOCTL_CFG80211)
    rtw_cfg80211_dev_res_unregister ( dvobj );
#endif
}




/**
 * rtw_os_ndevs_init - Allocate and register OS layer net devices and relating structures for @dvobj
 * @dvobj: the dvobj on which this function applies
 *
 * Returns:
 * _SUCCESS or _FAIL
 */
int rtw_os_ndevs_init ( struct dvobj_priv *dvobj )
{
    int ret = _FAIL;

    if ( rtw_os_ndevs_alloc ( dvobj ) != _SUCCESS )
        goto exit;

    if ( rtw_os_ndevs_register ( dvobj ) != _SUCCESS )
        goto os_ndevs_free;

    ret = _SUCCESS;

os_ndevs_free:

    if ( ret != _SUCCESS )
        rtw_os_ndevs_free ( dvobj );

exit:
    return ret;
}



/**
 * rtw_os_ndevs_deinit - Unregister and free OS layer net devices and relating structures for @dvobj
 * @dvobj: the dvobj on which this function applies
 */
void rtw_os_ndevs_deinit ( struct dvobj_priv *dvobj )
{
    rtw_os_ndevs_unregister ( dvobj );
    rtw_os_ndevs_free ( dvobj );
}



int _netdev_open ( struct net_device *pnetdev )
{
    uint status;
    _adapter *padapter = ( _adapter * ) rtw_netdev_priv ( pnetdev );
    struct pwrctrl_priv *pwrctrlpriv = adapter_to_pwrctl ( padapter );


    RT_TRACE ( _module_os_intfs_c_, _drv_info_, ( "+871x_drv - dev_open\n" ) );
    DBG_871X ( "+871x_drv - drv_open, bup=%d\n", padapter->bup );

	//printk("==============_netdev_open========1.0====jiffies:%ld\n", jiffies);

    padapter->netif_up = _TRUE;

    if ( pwrctrlpriv->ps_flag == _TRUE )
    {
        padapter->net_closed = _FALSE;
        goto netdev_open_normal_process;
    }

    if ( padapter->bup == _FALSE )
    {
        rtw_clr_surprise_removed ( padapter );
        rtw_clr_drv_stopped ( padapter );

        status = rtw_hal_init ( padapter );

        if ( status == _FAIL )
        {
            RT_TRACE ( _module_os_intfs_c_, _drv_err_, ( "rtl871x_hal_init(): Can't init h/w!\n" ) );
            goto netdev_open_error;
        }

        DBG_871X ( "MAC Address = "MAC_FMT"\n", MAC_ARG ( pnetdev->dev_addr ) );

        status = rtw_start_drv_threads ( padapter );

        if ( status == _FAIL )
        {
            DBG_871X ( "Initialize driver software resource Failed!\n" );
            goto netdev_open_error;
        }


        if ( padapter->intf_start )
        {
            padapter->intf_start ( padapter );
        }

#ifdef CONFIG_IOCTL_CFG80211
        rtw_cfg80211_init_wiphy ( padapter );
#endif

        rtw_led_control ( padapter, LED_CTL_NO_LINK );

        padapter->bup = _TRUE;
        pwrctrlpriv->bips_processing = _FALSE;
    }

    padapter->net_closed = _FALSE;

    _set_timer ( &padapter->mlmepriv.dynamic_chk_timer, 2000 );


    rtw_set_pwr_state_check_timer ( pwrctrlpriv );


    //netif_carrier_on(pnetdev);//call this func when rtw_joinbss_event_callback return success
    rtw_netif_wake_queue ( pnetdev );





netdev_open_normal_process:



    RT_TRACE ( _module_os_intfs_c_, _drv_info_, ( "-871x_drv - dev_open\n" ) );
    DBG_871X ( "-871x_drv - drv_open, bup=%d\n", padapter->bup );

    return 0;

netdev_open_error:

    padapter->bup = _FALSE;

    netif_carrier_off ( pnetdev );
    rtw_netif_stop_queue ( pnetdev );

    RT_TRACE ( _module_os_intfs_c_, _drv_err_, ( "-871x_drv - dev_open, fail!\n" ) );
    DBG_871X ( "-871x_drv - drv_open fail, bup=%d\n", padapter->bup );

    return ( -1 );

}



int netdev_open ( struct net_device *pnetdev )
{
    int ret;
    _adapter *padapter = ( _adapter * ) rtw_netdev_priv ( pnetdev );
    struct pwrctrl_priv *pwrctrlpriv = adapter_to_pwrctl ( padapter );

	//
	//printk("==============netdev_open========1.0====jiffies:%ld\n", jiffies);

    if ( pwrctrlpriv->bInSuspend == _TRUE )
    {
		//
		printk("==============netdev_open========1.1====jiffies:%ld\n", jiffies);

		
        DBG_871X ( "+871x_drv - drv_open, bInSuspend=%d\n", pwrctrlpriv->bInSuspend );
        return 0;
    }

    _enter_critical_mutex ( & ( adapter_to_dvobj ( padapter )->hw_init_mutex ), NULL );
    ret = _netdev_open ( pnetdev );
    _exit_critical_mutex ( & ( adapter_to_dvobj ( padapter )->hw_init_mutex ), NULL );

    return ret;
}



void rtw_ips_dev_unload ( _adapter *padapter )
{
    struct net_device *pnetdev = ( struct net_device* ) padapter->pnetdev;
    struct xmit_priv    *pxmitpriv = & ( padapter->xmitpriv );
    PHAL_DATA_TYPE pHalData = GET_HAL_DATA ( padapter );

    DBG_871X ( "====> %s...\n", __FUNCTION__ );

    {
        rtw_hal_set_hwreg ( padapter, HW_VAR_FIFO_CLEARN_UP, 0 );

        if ( padapter->intf_stop )
        {
            padapter->intf_stop ( padapter );
        }
    }

    if ( !rtw_is_surprise_removed ( padapter ) )
        rtw_hal_deinit ( padapter );

}


int pm_netdev_open ( struct net_device *pnetdev, u8 bnormal )
{
    int status = 0;

    _adapter *padapter = ( _adapter * ) rtw_netdev_priv ( pnetdev );

    if ( _TRUE == bnormal )
    {
        _enter_critical_mutex ( & ( adapter_to_dvobj ( padapter )->hw_init_mutex ), NULL );
        status = _netdev_open ( pnetdev );
        _exit_critical_mutex ( & ( adapter_to_dvobj ( padapter )->hw_init_mutex ), NULL );
    }

    return status;
}



static int netdev_close ( struct net_device *pnetdev )
{
    _adapter *padapter = ( _adapter * ) rtw_netdev_priv ( pnetdev );
    struct pwrctrl_priv *pwrctl = adapter_to_pwrctl ( padapter );
    struct mlme_priv    *pmlmepriv = &padapter->mlmepriv;

    RT_TRACE ( _module_os_intfs_c_, _drv_info_, ( "+871x_drv - drv_close\n" ) );

	printk("==============netdev_close========1.0====jiffies:%ld\n\n", jiffies);

    if ( pwrctl->bInternalAutoSuspend == _TRUE )
    {
        //rtw_pwr_wakeup(padapter);
        if ( pwrctl->rf_pwrstate == rf_off )
            pwrctl->ps_flag = _TRUE;
    }

    padapter->net_closed = _TRUE;
    padapter->netif_up = _FALSE;
    pmlmepriv->LinkDetectInfo.bBusyTraffic = _FALSE;

    /*  if (!rtw_is_hw_init_completed(padapter)) {
            DBG_871X("(1)871x_drv - drv_close, bup=%d, hw_init_completed=%s\n", padapter->bup, rtw_is_hw_init_completed(padapter)?"_TRUE":"_FALSE");

            rtw_set_drv_stopped(padapter);

            rtw_dev_unload(padapter);
        }
        else*/
    if ( pwrctl->rf_pwrstate == rf_on )
    {
        DBG_871X ( "(2)871x_drv - drv_close, bup=%d, hw_init_completed=%s\n", padapter->bup, rtw_is_hw_init_completed ( padapter ) ? "_TRUE" : "_FALSE" );

        //s1.
        if ( pnetdev )
        {
            rtw_netif_stop_queue ( pnetdev );
        }


        //s2.
        LeaveAllPowerSaveMode ( padapter );
        rtw_disassoc_cmd ( padapter, 500, _FALSE );
        //s2-2.  indicate disconnect to os
        rtw_indicate_disconnect ( padapter );
        //s2-3.
        rtw_free_assoc_resources ( padapter, 1 );
        //s2-4.
        rtw_free_network_queue ( padapter, _TRUE );

        // Close LED
        rtw_led_control ( padapter, LED_CTL_POWER_OFF );
    }


#ifdef CONFIG_IOCTL_CFG80211
    rtw_scan_abort ( padapter );
    rtw_cfg80211_wait_scan_req_empty ( padapter, 200 );
    adapter_wdev_data ( padapter )->bandroid_scan = _FALSE;
    //padapter->rtw_wdev->iftype = NL80211_IFTYPE_MONITOR; //set this at the end
#endif //CONFIG_IOCTL_CFG80211


    RT_TRACE ( _module_os_intfs_c_, _drv_info_, ( "-871x_drv - drv_close\n" ) );
    DBG_871X ( "-871x_drv - drv_close, bup=%d\n", padapter->bup );

    return 0;

}



int pm_netdev_close ( struct net_device *pnetdev, u8 bnormal )
{
    int status = 0;

    status = netdev_close ( pnetdev );

    return status;
}


void rtw_ndev_destructor ( struct net_device *ndev )
{
    DBG_871X ( FUNC_NDEV_FMT"\n", FUNC_NDEV_ARG ( ndev ) );

#ifdef CONFIG_IOCTL_CFG80211

    if ( ndev->ieee80211_ptr )
        rtw_mfree ( ( u8 * ) ndev->ieee80211_ptr, sizeof ( struct wireless_dev ) );

#endif
    free_netdev ( ndev );
}



void rtw_dev_unload ( PADAPTER padapter )
{
    struct net_device *pnetdev = ( struct net_device* ) padapter->pnetdev;
    struct pwrctrl_priv *pwrctl = adapter_to_pwrctl ( padapter );
    struct dvobj_priv *pobjpriv = padapter->dvobj;
    struct debug_priv *pdbgpriv = &pobjpriv->drv_dbg;
    struct cmd_priv *pcmdpriv = &padapter->cmdpriv;
    u8 cnt = 0;

    RT_TRACE ( _module_hci_intfs_c_, _drv_notice_, ( "+%s\n", __FUNCTION__ ) );

    if ( padapter->bup == _TRUE )
    {
        DBG_871X ( "===> %s\n", __FUNCTION__ );

        rtw_set_drv_stopped ( padapter );
#ifdef CONFIG_XMIT_ACK

        if ( padapter->xmitpriv.ack_tx )
            rtw_ack_tx_done ( &padapter->xmitpriv, RTW_SCTX_DONE_DRV_STOP );
#endif

        if ( padapter->intf_stop )
            padapter->intf_stop ( padapter );

        RT_TRACE ( _module_hci_intfs_c_, _drv_notice_, ( "@ rtw_dev_unload: stop intf complete!\n" ) );

        if ( !pwrctl->bInternalAutoSuspend )
            rtw_stop_drv_threads ( padapter );

        while ( ATOMIC_READ ( & ( pcmdpriv->cmdthd_running ) ) == _TRUE )
        {
            if ( cnt > 5 )
            {
                DBG_871X ( "stop cmdthd timeout\n" );
                break;
            }
            else
            {
                cnt ++;
                DBG_871X ( "cmdthd is running(%d)\n", cnt );
                rtw_msleep_os ( 10 );
            }
        }

        RT_TRACE ( _module_hci_intfs_c_, _drv_notice_, ( "@ %s: stop thread complete!\n", __FUNCTION__ ) );

        //check the status of IPS
        if ( rtw_hal_check_ips_status ( padapter ) == _TRUE || pwrctl->rf_pwrstate == rf_off ) //check HW status and SW state
        {
            DBG_871X_LEVEL ( _drv_always_, "%s: driver in IPS-FWLPS\n", __func__ );
            pdbgpriv->dbg_dev_unload_inIPS_cnt++;
        }
        else
        {
            DBG_871X_LEVEL ( _drv_always_, "%s: driver not in IPS\n", __func__ );
        }

        if ( !rtw_is_surprise_removed ( padapter ) )
        {
            {
                //amy modify 20120221 for power seq is different between driver open and ips
                rtw_hal_deinit ( padapter );
            }

            rtw_set_surprise_removed ( padapter );
        }

        RT_TRACE ( _module_hci_intfs_c_, _drv_notice_, ( "@ %s: deinit hal complelt!\n", __FUNCTION__ ) );

        padapter->bup = _FALSE;

        DBG_871X ( "<=== %s\n", __FUNCTION__ );
    }
    else
    {
        RT_TRACE ( _module_hci_intfs_c_, _drv_notice_, ( "%s: bup==_FALSE\n", __FUNCTION__ ) );
        DBG_871X ( "%s: bup==_FALSE\n", __FUNCTION__ );
    }

    RT_TRACE ( _module_hci_intfs_c_, _drv_notice_, ( "-%s\n", __FUNCTION__ ) );
}



int rtw_suspend_free_assoc_resource ( _adapter *padapter )
{
    struct mlme_priv *pmlmepriv = &padapter->mlmepriv;
    struct net_device *pnetdev = padapter->pnetdev;


    DBG_871X ( "==> "FUNC_ADPT_FMT" entry....\n", FUNC_ADPT_ARG ( padapter ) );

    if ( rtw_chk_roam_flags ( padapter, RTW_ROAM_ON_RESUME ) )
    {
        if ( check_fwstate ( pmlmepriv, WIFI_STATION_STATE )
             && check_fwstate ( pmlmepriv, _FW_LINKED )

           )
        {
            DBG_871X ( "%s %s(" MAC_FMT "), length:%d assoc_ssid.length:%d\n", __FUNCTION__,
                       pmlmepriv->cur_network.network.Ssid.Ssid,
                       MAC_ARG ( pmlmepriv->cur_network.network.MacAddress ),
                       pmlmepriv->cur_network.network.Ssid.SsidLength,
                       pmlmepriv->assoc_ssid.SsidLength );
            rtw_set_to_roam ( padapter, 1 );
        }
    }

    if ( check_fwstate ( pmlmepriv, WIFI_STATION_STATE ) && check_fwstate ( pmlmepriv, _FW_LINKED ) )
    {
        rtw_disassoc_cmd ( padapter, 0, _FALSE );
        //s2-2.  indicate disconnect to os
        rtw_indicate_disconnect ( padapter );
    }

#ifdef CONFIG_AP_MODE
    else if ( check_fwstate ( pmlmepriv, WIFI_AP_STATE ) )
    {
        rtw_sta_flush ( padapter, _TRUE );
    }
#endif

    //s2-3.
    rtw_free_assoc_resources ( padapter, 1 );

    //s2-4.
    rtw_free_network_queue ( padapter, _TRUE );

    if ( check_fwstate ( pmlmepriv, _FW_UNDER_SURVEY ) )
    {
        DBG_871X_LEVEL ( _drv_always_, "%s: fw_under_survey\n", __func__ );
        rtw_indicate_scan_done ( padapter, 1 );
        clr_fwstate ( pmlmepriv, _FW_UNDER_SURVEY );
    }

    if ( check_fwstate ( pmlmepriv, _FW_UNDER_LINKING ) == _TRUE )
    {
        DBG_871X_LEVEL ( _drv_always_, "%s: fw_under_linking\n", __FUNCTION__ );
        rtw_indicate_disconnect ( padapter );
    }

    DBG_871X ( "<== "FUNC_ADPT_FMT" exit....\n", FUNC_ADPT_ARG ( padapter ) );
    return _SUCCESS;
}



int rtw_suspend_normal ( _adapter *padapter )
{
    struct mlme_priv *pmlmepriv = &padapter->mlmepriv;
    struct net_device *pnetdev = padapter->pnetdev;

    struct pwrctrl_priv *pwrpriv = adapter_to_pwrctl ( padapter );
    int ret = _SUCCESS;

    DBG_871X ( "==> "FUNC_ADPT_FMT" entry....\n", FUNC_ADPT_ARG ( padapter ) );

    if ( pnetdev )
    {
        netif_carrier_off ( pnetdev );
        rtw_netif_stop_queue ( pnetdev );
    }


    rtw_suspend_free_assoc_resource ( padapter );

    rtw_led_control ( padapter, LED_CTL_POWER_OFF );

    if ( ( rtw_hal_check_ips_status ( padapter ) == _TRUE )
         || ( adapter_to_pwrctl ( padapter )->rf_pwrstate == rf_off ) )
    {
        DBG_871X_LEVEL ( _drv_always_, "%s: ### ERROR #### driver in IPS ####ERROR###!!!\n", __FUNCTION__ );

    }

    rtw_dev_unload ( padapter );

    //sdio_deinit(adapter_to_dvobj(padapter));
    if ( padapter->intf_deinit )
        padapter->intf_deinit ( adapter_to_dvobj ( padapter ) );

    DBG_871X ( "<== "FUNC_ADPT_FMT" exit....\n", FUNC_ADPT_ARG ( padapter ) );
    return ret;
}



int rtw_suspend_common ( _adapter *padapter )
{
    struct dvobj_priv *psdpriv = padapter->dvobj;
    struct debug_priv *pdbgpriv = &psdpriv->drv_dbg;
    struct pwrctrl_priv *pwrpriv = dvobj_to_pwrctl ( psdpriv );
    struct mlme_priv *pmlmepriv = &padapter->mlmepriv;

    int ret = 0;
    u32 start_time = rtw_get_current_time();

    DBG_871X_LEVEL ( _drv_always_, " suspend start\n" );
    DBG_871X ( "==> %s (%s:%d)\n", __FUNCTION__, current->comm, current->pid );

    pdbgpriv->dbg_suspend_cnt++;

    pwrpriv->bInSuspend = _TRUE;

    while ( pwrpriv->bips_processing == _TRUE )
        rtw_msleep_os ( 1 );


    if ( ( !padapter->bup ) || RTW_CANNOT_RUN ( padapter ) )
    {
        DBG_871X ( "%s bup=%d bDriverStopped=%s bSurpriseRemoved = %s\n", __func__
                   , padapter->bup
                   , rtw_is_drv_stopped ( padapter ) ? "True" : "False"
                   , rtw_is_surprise_removed ( padapter ) ? "True" : "False" );
        pdbgpriv->dbg_suspend_error_cnt++;
        goto exit;
    }

    rtw_ps_deny ( padapter, PS_DENY_SUSPEND );

    rtw_cancel_all_timer ( padapter );


    LeaveAllPowerSaveModeDirect ( padapter );

    rtw_stop_cmd_thread ( padapter );
    rtw_ps_deny_cancel ( padapter, PS_DENY_SUSPEND );

    if ( check_fwstate ( pmlmepriv, WIFI_STATION_STATE ) == _TRUE
       )
    {
        rtw_suspend_normal ( padapter );
    }
    else if ( check_fwstate ( pmlmepriv, WIFI_AP_STATE ) == _TRUE
            )
    {
        rtw_suspend_normal ( padapter );
    }
    else
    {
        rtw_suspend_normal ( padapter );
    }


    DBG_871X_LEVEL ( _drv_always_, "rtw suspend success in %d ms\n",
                     rtw_get_passing_time_ms ( start_time ) );

exit:
    DBG_871X ( "<===  %s return %d.............. in %dms\n", __FUNCTION__
               , ret, rtw_get_passing_time_ms ( start_time ) );

    return ret;
}



int rtw_resume_process_normal ( _adapter *padapter )
{
    struct net_device *pnetdev;

    struct pwrctrl_priv *pwrpriv;
    struct mlme_priv *pmlmepriv;
    struct dvobj_priv *psdpriv;
    struct debug_priv *pdbgpriv;

    int ret = _SUCCESS;
    _func_enter_;

    if ( !padapter )
    {
        ret = -1;
        goto exit;
    }

    pnetdev = padapter->pnetdev;
    pwrpriv = adapter_to_pwrctl ( padapter );
    pmlmepriv = &padapter->mlmepriv;
    psdpriv = padapter->dvobj;
    pdbgpriv = &psdpriv->drv_dbg;

    DBG_871X ( "==> "FUNC_ADPT_FMT" entry....\n", FUNC_ADPT_ARG ( padapter ) );

    // interface init
    //if (sdio_init(adapter_to_dvobj(padapter)) != _SUCCESS)
    if ( ( padapter->intf_init ) && ( padapter->intf_init ( adapter_to_dvobj ( padapter ) ) != _SUCCESS ) )
    {
        ret = -1;
        RT_TRACE ( _module_hci_intfs_c_, _drv_err_, ( "%s: initialize SDIO Failed!!\n", __FUNCTION__ ) );
        goto exit;
    }

    rtw_hal_disable_interrupt ( padapter );

    //if (sdio_alloc_irq(adapter_to_dvobj(padapter)) != _SUCCESS)
    if ( ( padapter->intf_alloc_irq ) && ( padapter->intf_alloc_irq ( adapter_to_dvobj ( padapter ) ) != _SUCCESS ) )
    {
        ret = -1;
        RT_TRACE ( _module_hci_intfs_c_, _drv_err_, ( "%s: sdio_alloc_irq Failed!!\n", __FUNCTION__ ) );
        goto exit;
    }

    rtw_reset_drv_sw ( padapter );


    pwrpriv->bkeepfwalive = _FALSE;

    DBG_871X ( "bkeepfwalive(%x)\n", pwrpriv->bkeepfwalive );

    if ( pm_netdev_open ( pnetdev, _TRUE ) != 0 )
    {
        ret = -1;
        pdbgpriv->dbg_resume_error_cnt++;
        goto exit;
    }

    netif_device_attach ( pnetdev );
    netif_carrier_on ( pnetdev );



    if ( padapter->pid[1] != 0 )
    {
        DBG_871X ( "pid[1]:%d\n", padapter->pid[1] );
        rtw_signal_process ( padapter->pid[1], SIGUSR2 );
    }


    if ( check_fwstate ( pmlmepriv, WIFI_STATION_STATE ) )
    {
        DBG_871X ( FUNC_ADPT_FMT" fwstate:0x%08x - WIFI_STATION_STATE\n", FUNC_ADPT_ARG ( padapter ), get_fwstate ( pmlmepriv ) );

        if ( rtw_chk_roam_flags ( padapter, RTW_ROAM_ON_RESUME ) )
            rtw_roaming ( padapter, NULL );

    }
    else if ( check_fwstate ( pmlmepriv, WIFI_AP_STATE ) )
    {
        DBG_871X ( FUNC_ADPT_FMT" fwstate:0x%08x - WIFI_AP_STATE\n", FUNC_ADPT_ARG ( padapter ), get_fwstate ( pmlmepriv ) );
        rtw_ap_restore_network ( padapter );
    }
    else if ( check_fwstate ( pmlmepriv, WIFI_ADHOC_STATE ) )
    {
        DBG_871X ( FUNC_ADPT_FMT" fwstate:0x%08x - WIFI_ADHOC_STATE\n", FUNC_ADPT_ARG ( padapter ), get_fwstate ( pmlmepriv ) );
    }
    else
    {
        DBG_871X ( FUNC_ADPT_FMT" fwstate:0x%08x - ???\n", FUNC_ADPT_ARG ( padapter ), get_fwstate ( pmlmepriv ) );
    }


    DBG_871X ( "<== "FUNC_ADPT_FMT" exit....\n", FUNC_ADPT_ARG ( padapter ) );

exit:
    _func_exit_;
    return ret;
}



int rtw_resume_common ( _adapter *padapter )
{
    int ret = 0;
    u32 start_time = rtw_get_current_time();
    struct pwrctrl_priv *pwrpriv = adapter_to_pwrctl ( padapter );
    struct mlme_priv *pmlmepriv = &padapter->mlmepriv;

    _func_enter_;

    if ( pwrpriv->bInSuspend == _FALSE )
        return 0;

    DBG_871X_LEVEL ( _drv_always_, "resume start\n" );
    DBG_871X ( "==> %s (%s:%d)\n", __FUNCTION__, current->comm, current->pid );

    if ( check_fwstate ( pmlmepriv, WIFI_STATION_STATE ) == _TRUE
       )
    {
        rtw_resume_process_normal ( padapter );
    }
    else if ( check_fwstate ( pmlmepriv, WIFI_AP_STATE ) == _TRUE
            )
    {
        rtw_resume_process_normal ( padapter );
    }
    else
    {
        rtw_resume_process_normal ( padapter );
    }


    if ( pwrpriv )
    {
        pwrpriv->bInSuspend = _FALSE;
    }

    DBG_871X_LEVEL ( _drv_always_, "%s:%d in %d ms\n", __FUNCTION__, ret,
                     rtw_get_passing_time_ms ( start_time ) );

    _func_exit_;

    return ret;
}




