

service dnsmasq stop
service hostapd stop

rmmod 8812au

service systemd-resolved start
service NetworkManager start

rfkill unblock wlan
nmcli radio wifi on






































