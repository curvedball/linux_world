

print_help()
{
	echo "Usage: $0 version"
	echo "Example: $0 1.0.06"
	echo ""
}



#-----------------------------------------------------
if [ $# != 1 ] ; then
	print_help;
	exit 1;
fi



service dnsmasq stop
service hostapd stop

rmmod rtl8812au

service systemd-resolved start
service NetworkManager start

rfkill unblock wlan
nmcli radio wifi on


make clean

cd /root/.wine/drive_c
tar zcvf rtl8812au$1.tar.gz rtl8812AU/

cd /root/.wine/drive_c/rtl8812AU


































