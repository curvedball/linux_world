


int platform_wifi_power_on(void)
{
    int ret = 0;
    return ret;
}



void platform_wifi_power_off(void)
{

}



