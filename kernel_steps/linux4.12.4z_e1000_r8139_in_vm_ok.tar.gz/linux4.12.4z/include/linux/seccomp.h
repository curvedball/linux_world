

#ifndef _LINUX_SECCOMP_H
#define _LINUX_SECCOMP_H


#include <uapi/linux/seccomp.h>


#define SECCOMP_FILTER_FLAG_MASK    (SECCOMP_FILTER_FLAG_TSYNC)



#include <linux/errno.h>

struct seccomp 
{
	
};


struct seccomp_filter 
{
	
};




static inline void secure_computing_strict(int this_syscall)
{
    return;
}


static inline long prctl_get_seccomp(void)
{
    return -EINVAL;
}


static inline long prctl_set_seccomp(unsigned long arg2, char __user *arg3)
{
    return -EINVAL;
}

static inline int seccomp_mode(struct seccomp *s)
{
    return SECCOMP_MODE_DISABLED;
}



static inline void put_seccomp_filter(struct task_struct *tsk)
{
    return;
}


static inline void get_seccomp_filter(struct task_struct *tsk)
{
    return;
}



static inline long seccomp_get_filter(struct task_struct *task,
                                      unsigned long n, void __user *data)
{
    return -EINVAL;
}


#endif



