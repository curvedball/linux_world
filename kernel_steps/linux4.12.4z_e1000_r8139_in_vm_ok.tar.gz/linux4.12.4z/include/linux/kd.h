



#ifndef _LINUX_KD_H
#define _LINUX_KD_H

#include <uapi/linux/kd.h>

#define KD_FONT_FLAG_OLD        0x80000000  /* Invoked via old interface [compat] */


#endif


