


/* memcontrol.h - Memory Controller
 *
 * Copyright IBM Corporation, 2007
 * Author Balbir Singh <balbir@linux.vnet.ibm.com>
 *
 * Copyright 2007 OpenVZ SWsoft Inc
 * Author: Pavel Emelianov <xemul@openvz.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef _LINUX_MEMCONTROL_H
#define _LINUX_MEMCONTROL_H
#include <linux/cgroup.h>
#include <linux/vm_event_item.h>
#include <linux/hardirq.h>
#include <linux/jump_label.h>
#include <linux/page_counter.h>
#include <linux/vmpressure.h>
#include <linux/eventfd.h>
#include <linux/mmzone.h>
#include <linux/writeback.h>
#include <linux/page-flags.h>


struct mem_cgroup;
struct page;
struct mm_struct;
struct kmem_cache;



/* Cgroup-specific page state, on top of universal node page state */
enum memcg_stat_item
{
    MEMCG_CACHE = NR_VM_NODE_STAT_ITEMS,
    MEMCG_RSS,
    MEMCG_RSS_HUGE,
    MEMCG_SWAP,
    MEMCG_SOCK,
    /* XXX: why are these zone and not node counters? */
    MEMCG_KERNEL_STACK_KB,
    MEMCG_SLAB_RECLAIMABLE,
    MEMCG_SLAB_UNRECLAIMABLE,
    MEMCG_NR_STAT,
};



/* Cgroup-specific events, on top of universal VM events */
enum memcg_event_item
{
    MEMCG_LOW = NR_VM_EVENT_ITEMS,
    MEMCG_HIGH,
    MEMCG_MAX,
    MEMCG_OOM,
    MEMCG_NR_EVENTS,
};



struct mem_cgroup_reclaim_cookie
{
    pg_data_t *pgdat;
    int priority;
    unsigned int generation;
};



#define MEM_CGROUP_ID_SHIFT 0
#define MEM_CGROUP_ID_MAX   0


struct mem_cgroup;



static inline bool mem_cgroup_disabled(void)
{
    return true;
}

static inline void mem_cgroup_event(struct mem_cgroup *memcg, enum memcg_event_item event)
{
	
}

static inline bool mem_cgroup_low(struct mem_cgroup *root, struct mem_cgroup *memcg)
{
    return false;
}


static inline int mem_cgroup_try_charge(struct page *page, struct mm_struct *mm, gfp_t gfp_mask, struct mem_cgroup **memcgp, bool compound)
{
    *memcgp = NULL;
    return 0;
}


static inline void mem_cgroup_commit_charge(struct page *page, struct mem_cgroup *memcg, bool lrucare, bool compound)
{
	
}

static inline void mem_cgroup_cancel_charge(struct page *page, struct mem_cgroup *memcg, bool compound)
{
	
}



static inline void mem_cgroup_uncharge(struct page *page)
{
	
}

static inline void mem_cgroup_uncharge_list(struct list_head *page_list)
{
}

static inline void mem_cgroup_migrate(struct page *old, struct page *new)
{
	
}


static inline struct lruvec *mem_cgroup_lruvec(struct pglist_data *pgdat, struct mem_cgroup *memcg)
{
    return node_lruvec(pgdat);
}


static inline struct lruvec *mem_cgroup_page_lruvec(struct page *page, struct pglist_data *pgdat)
{
    return &pgdat->lruvec;
}




static inline bool mm_match_cgroup(struct mm_struct *mm, struct mem_cgroup *memcg)
{
    return true;
}

static inline bool task_in_mem_cgroup(struct task_struct *task, const struct mem_cgroup *memcg)
{
    return true;
}




static inline struct mem_cgroup * mem_cgroup_iter(struct mem_cgroup *root, struct mem_cgroup *prev, struct mem_cgroup_reclaim_cookie *reclaim)
{
    return NULL;
}


static inline void mem_cgroup_iter_break(struct mem_cgroup *root, struct mem_cgroup *prev)
{
	
}

static inline int mem_cgroup_scan_tasks(struct mem_cgroup *memcg, int (*fn)(struct task_struct *, void *), void *arg)
{
    return 0;
}


static inline unsigned short mem_cgroup_id(struct mem_cgroup *memcg)
{
    return 0;
}

static inline struct mem_cgroup *mem_cgroup_from_id(unsigned short id)
{
    WARN_ON_ONCE(id);
    /* XXX: This should always return root_mem_cgroup */
    return NULL;
}

static inline bool mem_cgroup_online(struct mem_cgroup *memcg)
{
    return true;
}

static inline unsigned long mem_cgroup_get_lru_size(struct lruvec *lruvec, enum lru_list lru)
{
    return 0;
}


static inline unsigned long mem_cgroup_get_zone_lru_size(struct lruvec *lruvec, enum lru_list lru, int zone_idx)
{
    return 0;
}



static inline unsigned long mem_cgroup_node_nr_lru_pages(struct mem_cgroup *memcg, int nid, unsigned int lru_mask)
{
    return 0;
}

static inline unsigned long mem_cgroup_get_limit(struct mem_cgroup *memcg)
{
    return 0;
}


static inline void mem_cgroup_print_oom_info(struct mem_cgroup *memcg, struct task_struct *p)
{
	
}

static inline void lock_page_memcg(struct page *page)
{
	
}

static inline void unlock_page_memcg(struct page *page)
{
	
}



static inline void mem_cgroup_handle_over_high(void)
{
	
}

static inline void mem_cgroup_oom_enable(void)
{
	
}

static inline void mem_cgroup_oom_disable(void)
{
	
}

static inline bool task_in_memcg_oom(struct task_struct *p)
{
    return false;
}

static inline bool mem_cgroup_oom_synchronize(bool wait)
{
    return false;
}



static inline unsigned long memcg_page_state(struct mem_cgroup *memcg, enum memcg_stat_item idx)
{
    return 0;
}

static inline void mod_memcg_state(struct mem_cgroup *memcg, enum memcg_stat_item idx, int nr)
{
	
}

static inline void inc_memcg_state(struct mem_cgroup *memcg, enum memcg_stat_item idx)
{
	
}

static inline void dec_memcg_state(struct mem_cgroup *memcg, enum memcg_stat_item idx)
{
	
}

static inline void mod_memcg_page_state(struct page *page, enum memcg_stat_item idx, int nr)
{
	
}

static inline void inc_memcg_page_state(struct page *page, enum memcg_stat_item idx)
{
	
}

static inline void dec_memcg_page_state(struct page *page, enum memcg_stat_item idx)
{
	
}

static inline unsigned long mem_cgroup_soft_limit_reclaim(pg_data_t *pgdat, int order, gfp_t gfp_mask, unsigned long *total_scanned)
{
    return 0;
}



static inline void mem_cgroup_split_huge_fixup(struct page *head)
{
	
}

static inline void mem_cgroup_count_vm_event(struct mm_struct *mm, enum vm_event_item idx)
{
}






static inline struct wb_domain *mem_cgroup_wb_domain(struct bdi_writeback *wb)
{
    return NULL;
}


static inline void mem_cgroup_wb_stats(struct bdi_writeback *wb, unsigned long *pfilepages, unsigned long *pheadroom, unsigned long *pdirty, unsigned long *pwriteback)
{
	
}


struct sock;


bool mem_cgroup_charge_skmem(struct mem_cgroup *memcg, unsigned int nr_pages);
void mem_cgroup_uncharge_skmem(struct mem_cgroup *memcg, unsigned int nr_pages);




#define mem_cgroup_sockets_enabled 0


static inline void mem_cgroup_sk_alloc(struct sock *sk) 
{ 
	
};


static inline void mem_cgroup_sk_free(struct sock *sk) 
{ 
	
};


static inline bool mem_cgroup_under_socket_pressure(struct mem_cgroup *memcg)
{
    return false;
}


struct kmem_cache *memcg_kmem_get_cache(struct kmem_cache *cachep);
void memcg_kmem_put_cache(struct kmem_cache *cachep);
int memcg_kmem_charge_memcg(struct page *page, gfp_t gfp, int order, struct mem_cgroup *memcg);
int memcg_kmem_charge(struct page *page, gfp_t gfp, int order);
void memcg_kmem_uncharge(struct page *page, int order);




#define for_each_memcg_cache_index(_idx)     for (; NULL; )


static inline bool memcg_kmem_enabled(void)
{
    return false;
}


static inline int memcg_cache_id(struct mem_cgroup *memcg)
{
    return -1;
}

static inline void memcg_get_cache_ids(void)
{
	
}

static inline void memcg_put_cache_ids(void)
{
	
}

static inline void memcg_kmem_update_page_stat(struct page *page, enum memcg_stat_item idx, int val)
{
	
}


#endif




