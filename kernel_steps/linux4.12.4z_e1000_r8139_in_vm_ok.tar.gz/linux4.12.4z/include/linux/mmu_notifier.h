


#ifndef _LINUX_MMU_NOTIFIER_H
#define _LINUX_MMU_NOTIFIER_H


#include <linux/list.h>
#include <linux/spinlock.h>
#include <linux/mm_types.h>
#include <linux/srcu.h>


struct mmu_notifier;
struct mmu_notifier_ops;




static inline void mmu_notifier_release(struct mm_struct *mm)
{
	
}

static inline int mmu_notifier_clear_flush_young(struct mm_struct *mm,
        unsigned long start,
        unsigned long end)
{
    return 0;
}

static inline int mmu_notifier_test_young(struct mm_struct *mm,
        unsigned long address)
{
    return 0;
}

static inline void mmu_notifier_change_pte(struct mm_struct *mm, unsigned long address, pte_t pte)
{
	
}

static inline void mmu_notifier_invalidate_page(struct mm_struct *mm, unsigned long address)
{
	
}

static inline void mmu_notifier_invalidate_range_start(struct mm_struct *mm, unsigned long start, unsigned long end)
{
	
}

static inline void mmu_notifier_invalidate_range_end(struct mm_struct *mm, unsigned long start, unsigned long end)
{
	
}

static inline void mmu_notifier_invalidate_range(struct mm_struct *mm, unsigned long start, unsigned long end)
{
	
}

static inline void mmu_notifier_mm_init(struct mm_struct *mm)
{
	
}

static inline void mmu_notifier_mm_destroy(struct mm_struct *mm)
{
	
}



#define ptep_clear_flush_young_notify 	ptep_clear_flush_young
#define pmdp_clear_flush_young_notify 	pmdp_clear_flush_young

#define ptep_clear_young_notify 		ptep_test_and_clear_young
#define pmdp_clear_young_notify 		pmdp_test_and_clear_young

#define ptep_clear_flush_notify 		ptep_clear_flush
#define pmdp_huge_clear_flush_notify 	pmdp_huge_clear_flush
#define pudp_huge_clear_flush_notify 	pudp_huge_clear_flush

#define set_pte_at_notify 				set_pte_at



#endif



