

#ifndef _SCREEN_INFO_H
#define _SCREEN_INFO_H


#include <uapi/linux/screen_info.h>


extern struct screen_info screen_info;


#endif



