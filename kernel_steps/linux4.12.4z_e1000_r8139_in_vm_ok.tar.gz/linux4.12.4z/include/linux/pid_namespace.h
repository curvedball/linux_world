

#ifndef _LINUX_PID_NS_H
#define _LINUX_PID_NS_H


#include <linux/sched.h>
#include <linux/bug.h>
#include <linux/mm.h>
#include <linux/workqueue.h>
#include <linux/threads.h>
#include <linux/nsproxy.h>
#include <linux/kref.h>
#include <linux/ns_common.h>


struct pidmap
{
    atomic_t nr_free;
    void *page;
};


#define BITS_PER_PAGE       (PAGE_SIZE * 8)
#define BITS_PER_PAGE_MASK  (BITS_PER_PAGE-1)
#define PIDMAP_ENTRIES      ((PID_MAX_LIMIT+BITS_PER_PAGE-1)/BITS_PER_PAGE)


struct fs_pin;


enum   /* definitions for pid_namespace's hide_pid field */
{
    HIDEPID_OFF   = 0,
    HIDEPID_NO_ACCESS = 1,
    HIDEPID_INVISIBLE = 2,
};



struct pid_namespace
{
    struct kref kref;
    struct pidmap pidmap[PIDMAP_ENTRIES];
    struct rcu_head rcu;
    int last_pid;
    unsigned int nr_hashed;
    struct task_struct *child_reaper;
    struct kmem_cache *pid_cachep;
    unsigned int level;
    struct pid_namespace *parent;
#ifdef CONFIG_PROC_FS
    struct vfsmount *proc_mnt;
    struct dentry *proc_self;
    struct dentry *proc_thread_self;
#endif

    struct user_namespace *user_ns;
    struct ucounts *ucounts;
    struct work_struct proc_work;
    kgid_t pid_gid;
    int hide_pid;
    int reboot; /* group exit code if this pidns was rebooted */
    struct ns_common ns;
};



extern struct pid_namespace init_pid_ns;


#define PIDNS_HASH_ADDING (1U << 31)



#include <linux/err.h>



static inline struct pid_namespace *get_pid_ns(struct pid_namespace *ns)
{
    return ns;
}



static inline struct pid_namespace *copy_pid_ns(unsigned long flags, struct user_namespace *user_ns, struct pid_namespace *ns)
{
    if(flags & CLONE_NEWPID)
    {
        ns = ERR_PTR(-EINVAL);
    }

    return ns;
}


static inline void put_pid_ns(struct pid_namespace *ns)
{
	
}

static inline void zap_pid_ns_processes(struct pid_namespace *ns)
{
    BUG();
}

static inline int reboot_pid_ns(struct pid_namespace *pid_ns, int cmd)
{
    return 0;
}


extern struct pid_namespace *task_active_pid_ns(struct task_struct *tsk);

void pidhash_init(void);
void pidmap_init(void);


#endif



