


#ifndef _BPF_CGROUP_H
#define _BPF_CGROUP_H



#include <linux/jump_label.h>
#include <uapi/linux/bpf.h>



struct sock;
struct cgroup;
struct sk_buff;




struct cgroup_bpf 
{
	
};


static inline void cgroup_bpf_put(struct cgroup *cgrp) 
{
	
}

static inline void cgroup_bpf_inherit(struct cgroup *cgrp, struct cgroup *parent) 
{
	
}



#define BPF_CGROUP_RUN_PROG_INET_INGRESS(sk,skb) ({ 0; })
#define BPF_CGROUP_RUN_PROG_INET_EGRESS(sk,skb) ({ 0; })
#define BPF_CGROUP_RUN_PROG_INET_SOCK(sk) ({ 0; })



#endif




