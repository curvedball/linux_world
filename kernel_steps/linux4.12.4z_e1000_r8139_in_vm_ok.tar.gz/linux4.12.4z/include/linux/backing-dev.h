


/*
 * include/linux/backing-dev.h
 *
 * low-level device information and state which is propagated up through
 * to high-level code.
 */

#ifndef _LINUX_BACKING_DEV_H
#define _LINUX_BACKING_DEV_H


#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/blkdev.h>
#include <linux/writeback.h>
#include <linux/blk-cgroup.h>
#include <linux/backing-dev-defs.h>
#include <linux/slab.h>


static inline struct backing_dev_info *bdi_get(struct backing_dev_info *bdi)
{
    kref_get(&bdi->refcnt);
    return bdi;
}


void bdi_put(struct backing_dev_info *bdi);

__printf(2, 3)int bdi_register(struct backing_dev_info *bdi, const char *fmt, ...);
int bdi_register_va(struct backing_dev_info *bdi, const char *fmt, va_list args);
int bdi_register_owner(struct backing_dev_info *bdi, struct device *owner);
void bdi_unregister(struct backing_dev_info *bdi);


struct backing_dev_info *bdi_alloc_node(gfp_t gfp_mask, int node_id);


static inline struct backing_dev_info *bdi_alloc(gfp_t gfp_mask)
{
    return bdi_alloc_node(gfp_mask, NUMA_NO_NODE);
}



void wb_start_writeback(struct bdi_writeback *wb, long nr_pages, bool range_cyclic, enum wb_reason reason);
void wb_start_background_writeback(struct bdi_writeback *wb);
void wb_workfn(struct work_struct *work);
void wb_wakeup_delayed(struct bdi_writeback *wb);



extern spinlock_t bdi_lock;
extern struct list_head bdi_list;
extern struct workqueue_struct *bdi_wq;



static inline bool wb_has_dirty_io(struct bdi_writeback *wb)
{
    return test_bit(WB_has_dirty_io, &wb->state);
}


static inline bool bdi_has_dirty_io(struct backing_dev_info *bdi)
{
    /*
     * @bdi->tot_write_bandwidth is guaranteed to be > 0 if there are
     * any dirty wbs.  See wb_update_write_bandwidth().
     */
    return atomic_long_read(&bdi->tot_write_bandwidth);
}


static inline void __add_wb_stat(struct bdi_writeback *wb, enum wb_stat_item item, s64 amount)
{
    percpu_counter_add_batch(&wb->stat[item], amount, WB_STAT_BATCH);
}


static inline void inc_wb_stat(struct bdi_writeback *wb, enum wb_stat_item item)
{
    __add_wb_stat(wb, item, 1);
}


static inline void dec_wb_stat(struct bdi_writeback *wb, enum wb_stat_item item)
{
    __add_wb_stat(wb, item, -1);
}


static inline s64 wb_stat(struct bdi_writeback *wb, enum wb_stat_item item)
{
    return percpu_counter_read_positive(&wb->stat[item]);
}


static inline s64 __wb_stat_sum(struct bdi_writeback *wb, enum wb_stat_item item)
{
    return percpu_counter_sum_positive(&wb->stat[item]);
}


static inline s64 wb_stat_sum(struct bdi_writeback *wb, enum wb_stat_item item)
{
    s64 sum;
    unsigned long flags;

    local_irq_save(flags);
    sum = __wb_stat_sum(wb, item);
    local_irq_restore(flags);

    return sum;
}


extern void wb_writeout_inc(struct bdi_writeback *wb);



/*
 * maximal error of a stat counter.
 */
static inline unsigned long wb_stat_error(struct bdi_writeback *wb)
{
#ifdef CONFIG_SMP
    return nr_cpu_ids * WB_STAT_BATCH;
#else
    return 1;
#endif
}




int bdi_set_min_ratio(struct backing_dev_info *bdi, unsigned int min_ratio);
int bdi_set_max_ratio(struct backing_dev_info *bdi, unsigned int max_ratio);




/*
 * Flags in backing_dev_info::capability
 *
 * The first three flags control whether dirty pages will contribute to the
 * VM's accounting and whether writepages() should be called for dirty pages
 * (something that would not, for example, be appropriate for ramfs)
 *
 * WARNING: these flags are closely related and should not normally be
 * used separately.  The BDI_CAP_NO_ACCT_AND_WRITEBACK combines these
 * three flags into a single convenience macro.
 *
 * BDI_CAP_NO_ACCT_DIRTY:  Dirty pages shouldn't contribute to accounting
 * BDI_CAP_NO_WRITEBACK:   Don't write pages back
 * BDI_CAP_NO_ACCT_WB:     Don't automatically account writeback pages
 * BDI_CAP_STRICTLIMIT:    Keep number of dirty pages below bdi threshold.
 *
 * BDI_CAP_CGROUP_WRITEBACK: Supports cgroup-aware writeback.
 */
#define BDI_CAP_NO_ACCT_DIRTY   0x00000001
#define BDI_CAP_NO_WRITEBACK    0x00000002
#define BDI_CAP_NO_ACCT_WB  	0x00000004
#define BDI_CAP_STABLE_WRITES   0x00000008
#define BDI_CAP_STRICTLIMIT 	0x00000010
#define BDI_CAP_CGROUP_WRITEBACK 0x00000020

#define BDI_CAP_NO_ACCT_AND_WRITEBACK (BDI_CAP_NO_WRITEBACK | BDI_CAP_NO_ACCT_DIRTY | BDI_CAP_NO_ACCT_WB)



extern struct backing_dev_info noop_backing_dev_info;




/**
 * writeback_in_progress - determine whether there is writeback in progress
 * @wb: bdi_writeback of interest
 *
 * Determine whether there is writeback waiting to be handled against a
 * bdi_writeback.
 */
static inline bool writeback_in_progress(struct bdi_writeback *wb)
{
    return test_bit(WB_writeback_running, &wb->state);
}



static inline struct backing_dev_info *inode_to_bdi(struct inode *inode)
{
    struct super_block *sb;

    if(!inode)
    {
        return &noop_backing_dev_info;
    }

    sb = inode->i_sb;
#ifdef CONFIG_BLOCK

    if(sb_is_blkdev_sb(sb))
    {
        return I_BDEV(inode)->bd_bdi;
    }

#endif
    return sb->s_bdi;
}




static inline int wb_congested(struct bdi_writeback *wb, int cong_bits)
{
    struct backing_dev_info *bdi = wb->bdi;

    if(bdi->congested_fn)
    {
        return bdi->congested_fn(bdi->congested_data, cong_bits);
    }

    return wb->congested->state & cong_bits;
}




long congestion_wait(int sync, long timeout);
long wait_iff_congested(struct pglist_data *pgdat, int sync, long timeout);
int pdflush_proc_obsolete(struct ctl_table *table, int write, void __user *buffer, size_t *lenp, loff_t *ppos);




static inline bool bdi_cap_stable_pages_required(struct backing_dev_info *bdi)
{
    return bdi->capabilities & BDI_CAP_STABLE_WRITES;
}



static inline bool bdi_cap_writeback_dirty(struct backing_dev_info *bdi)
{
    return !(bdi->capabilities & BDI_CAP_NO_WRITEBACK);
}


static inline bool bdi_cap_account_dirty(struct backing_dev_info *bdi)
{
    return !(bdi->capabilities & BDI_CAP_NO_ACCT_DIRTY);
}




static inline bool bdi_cap_account_writeback(struct backing_dev_info *bdi)
{
    /* Paranoia: BDI_CAP_NO_WRITEBACK implies BDI_CAP_NO_ACCT_WB */
    return !(bdi->capabilities & (BDI_CAP_NO_ACCT_WB | BDI_CAP_NO_WRITEBACK));
}



static inline bool mapping_cap_writeback_dirty(struct address_space *mapping)
{
    return bdi_cap_writeback_dirty(inode_to_bdi(mapping->host));
}

static inline bool mapping_cap_account_dirty(struct address_space *mapping)
{
    return bdi_cap_account_dirty(inode_to_bdi(mapping->host));
}

static inline int bdi_sched_wait(void *word)
{
    schedule();
    return 0;
}



static inline bool inode_cgwb_enabled(struct inode *inode)
{
    return false;
}

static inline struct bdi_writeback_congested * wb_congested_get_create(struct backing_dev_info *bdi, int blkcg_id, gfp_t gfp)
{
    atomic_inc(&bdi->wb_congested->refcnt);
    return bdi->wb_congested;
}


static inline void wb_congested_put(struct bdi_writeback_congested *congested)
{
    if(atomic_dec_and_test(&congested->refcnt))
    {
        kfree(congested);
    }
}

static inline struct bdi_writeback *wb_find_current(struct backing_dev_info *bdi)
{
    return &bdi->wb;
}



static inline struct bdi_writeback * wb_get_create_current(struct backing_dev_info *bdi, gfp_t gfp)
{
    return &bdi->wb;
}

static inline bool inode_to_wb_is_valid(struct inode *inode)
{
    return true;
}



static inline struct bdi_writeback *inode_to_wb(struct inode *inode)
{
    return &inode_to_bdi(inode)->wb;
}



static inline struct bdi_writeback * unlocked_inode_to_wb_begin(struct inode *inode, bool *lockedp)
{
    return inode_to_wb(inode);
}

static inline void unlocked_inode_to_wb_end(struct inode *inode, bool locked)
{
	
}

static inline void wb_memcg_offline(struct mem_cgroup *memcg)
{
	
}

static inline void wb_blkcg_offline(struct blkcg *blkcg)
{
	
}

static inline int inode_congested(struct inode *inode, int cong_bits)
{
    return wb_congested(&inode_to_bdi(inode)->wb, cong_bits);
}



static inline int inode_read_congested(struct inode *inode)
{
    return inode_congested(inode, 1 << WB_sync_congested);
}

static inline int inode_write_congested(struct inode *inode)
{
    return inode_congested(inode, 1 << WB_async_congested);
}

static inline int inode_rw_congested(struct inode *inode)
{
    return inode_congested(inode, (1 << WB_sync_congested) | (1 << WB_async_congested));
}


static inline int bdi_congested(struct backing_dev_info *bdi, int cong_bits)
{
    return wb_congested(&bdi->wb, cong_bits);
}

static inline int bdi_read_congested(struct backing_dev_info *bdi)
{
    return bdi_congested(bdi, 1 << WB_sync_congested);
}

static inline int bdi_write_congested(struct backing_dev_info *bdi)
{
    return bdi_congested(bdi, 1 << WB_async_congested);
}

static inline int bdi_rw_congested(struct backing_dev_info *bdi)
{
    return bdi_congested(bdi, (1 << WB_sync_congested) | (1 << WB_async_congested));
}


#endif



