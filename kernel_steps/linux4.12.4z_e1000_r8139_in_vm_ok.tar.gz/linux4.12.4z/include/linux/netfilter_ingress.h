


#ifndef _NETFILTER_INGRESS_H_
#define _NETFILTER_INGRESS_H_



#include <linux/netfilter.h>
#include <linux/netdevice.h>


static inline int nf_hook_ingress_active(struct sk_buff *skb)
{
    return 0;
}

static inline int nf_hook_ingress(struct sk_buff *skb)
{
    return 0;
}

static inline void nf_hook_ingress_init(struct net_device *dev) 
{
	
}

#endif



