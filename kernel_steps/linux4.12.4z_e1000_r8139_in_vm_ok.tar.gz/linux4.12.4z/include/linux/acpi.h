


/*
 * acpi.h - ACPI Interface
 *
 * Copyright (C) 2001 Paul Diefenbaugh <paul.s.diefenbaugh@intel.com>
 */

#ifndef _LINUX_ACPI_H
#define _LINUX_ACPI_H


#include <linux/errno.h>
#include <linux/ioport.h>   /* for struct resource */
#include <linux/resource_ext.h>
#include <linux/device.h>
#include <linux/property.h>


#ifndef _LINUX
#define _LINUX
#endif


#include <acpi/acpi.h>



#define acpi_disabled 1


#define ACPI_COMPANION(dev)     (NULL)
#define ACPI_COMPANION_SET(dev, adev)   do { } while (0)
#define ACPI_HANDLE(dev)        (NULL)
#define ACPI_DEVICE_CLASS(_cls, _msk)   .cls = (0), .cls_msk = (0),


struct fwnode_handle;


static inline bool acpi_dev_found(const char *hid)
{
    return false;
}

static inline bool acpi_dev_present(const char *hid, const char *uid, s64 hrv)
{
    return false;
}

static inline bool is_acpi_node(struct fwnode_handle *fwnode)
{
    return false;
}

static inline bool is_acpi_device_node(struct fwnode_handle *fwnode)
{
    return false;
}

static inline struct acpi_device *to_acpi_device_node(struct fwnode_handle *fwnode)
{
    return NULL;
}

static inline bool is_acpi_data_node(struct fwnode_handle *fwnode)
{
    return false;
}

static inline struct acpi_data_node *to_acpi_data_node(struct fwnode_handle *fwnode)
{
    return NULL;
}

static inline bool acpi_data_node_match(struct fwnode_handle *fwnode,
                                        const char *name)
{
    return false;
}

static inline struct fwnode_handle *acpi_fwnode_handle(struct acpi_device *adev)
{
    return NULL;
}

static inline bool has_acpi_companion(struct device *dev)
{
    return false;
}

static inline void acpi_preset_companion(struct device *dev, struct acpi_device *parent, u64 addr)
{
	
}

static inline const char *acpi_dev_name(struct acpi_device *adev)
{
    return NULL;
}

static inline struct device *acpi_get_first_physical_node(struct acpi_device *adev)
{
    return NULL;
}

static inline void acpi_early_init(void) 
{ 
	
}


static inline void acpi_subsystem_init(void) 
{
	
}

static inline int early_acpi_boot_init(void)
{
    return 0;
}
static inline int acpi_boot_init(void)
{
    return 0;
}

static inline void acpi_boot_table_init(void)
{
    return;
}

static inline int acpi_mps_check(void)
{
    return 0;
}

static inline int acpi_check_resource_conflict(struct resource *res)
{
    return 0;
}

static inline int acpi_check_region(resource_size_t start, resource_size_t n, const char *name)
{
    return 0;
}


struct acpi_table_header;


static inline int acpi_table_parse(char *id, int (*handler)(struct acpi_table_header *))
{
    return -ENODEV;
}

static inline int acpi_nvs_register(__u64 start, __u64 size)
{
    return 0;
}

static inline int acpi_nvs_for_each_region(int (*func)(__u64, __u64, void *), void *data)
{
    return 0;
}


struct acpi_device_id;


static inline const struct acpi_device_id *acpi_match_device(const struct acpi_device_id *ids, const struct device *dev)
{
    return NULL;
}

static inline bool acpi_driver_match_device(struct device *dev, const struct device_driver *drv)
{
    return false;
}

static inline union acpi_object *acpi_evaluate_dsm(acpi_handle handle, const u8 *uuid, int rev, int func, union acpi_object *argv4)
{
    return NULL;
}



static inline int acpi_device_uevent_modalias(struct device *dev, struct kobj_uevent_env *env)
{
    return -ENODEV;
}

static inline int acpi_device_modalias(struct device *dev, char *buf, int size)
{
    return -ENODEV;
}


static inline bool acpi_dma_supported(struct acpi_device *adev)
{
    return false;
}

static inline enum dev_dma_attr acpi_get_dma_attr(struct acpi_device *adev)
{
    return DEV_DMA_NOT_SUPPORTED;
}

static inline int acpi_dma_configure(struct device *dev, enum dev_dma_attr attr)
{
    return 0;
}

static inline void acpi_dma_deconfigure(struct device *dev) 
{
	
}


#define ACPI_PTR(_ptr)  (NULL)


static inline void acpi_device_set_enumerated(struct acpi_device *adev)
{
	
}

static inline void acpi_device_clear_enumerated(struct acpi_device *adev)
{
	
}

static inline int acpi_reconfig_notifier_register(struct notifier_block *nb)
{
    return -EINVAL;
}

static inline int acpi_reconfig_notifier_unregister(struct notifier_block *nb)
{
    return -EINVAL;
}

static inline struct acpi_device *acpi_resource_consumer(struct resource *res)
{
    return NULL;
}




static inline int acpi_ioapic_add(acpi_handle root)
{
    return 0;
}



#define acpi_os_set_prepare_sleep(func, pm1a_ctrl, pm1b_ctrl) do { } while (0)





static inline int acpi_dev_runtime_suspend(struct device *dev)
{
    return 0;
}


static inline int acpi_dev_runtime_resume(struct device *dev)
{
    return 0;
}


static inline int acpi_subsys_runtime_suspend(struct device *dev)
{
    return 0;
}


static inline int acpi_subsys_runtime_resume(struct device *dev)
{
    return 0;
}


static inline struct acpi_device *acpi_dev_pm_get_node(struct device *dev)
{
    return NULL;
}


static inline int acpi_dev_pm_attach(struct device *dev, bool power_on)
{
    return -ENODEV;
}



static inline int acpi_dev_suspend_late(struct device *dev)
{
    return 0;
}


static inline int acpi_dev_resume_early(struct device *dev)
{
    return 0;
}


static inline int acpi_subsys_prepare(struct device *dev)
{
    return 0;
}


static inline void acpi_subsys_complete(struct device *dev) 
{
	
}


static inline int acpi_subsys_suspend_late(struct device *dev)
{
    return 0;
}


static inline int acpi_subsys_resume_early(struct device *dev)
{
    return 0;
}


static inline int acpi_subsys_suspend(struct device *dev)
{
    return 0;
}


static inline int acpi_subsys_freeze(struct device *dev)
{
    return 0;
}



static inline __printf(3, 4) void acpi_handle_printk(const char *level, void *handle, const char *fmt, ...) 
{
	
}



#define __acpi_handle_debug(descriptor, handle, fmt, ...)       \
    acpi_handle_printk(KERN_DEBUG, handle, fmt, ##__VA_ARGS__);



/*
 * acpi_handle_<level>: Print message with ACPI prefix and object path
 *
 * These interfaces acquire the global namespace mutex to obtain an object
 * path.  In interrupt context, it shows the object path as <n/a>.
 */
#define acpi_handle_emerg(handle, fmt, ...)             \
    acpi_handle_printk(KERN_EMERG, handle, fmt, ##__VA_ARGS__)
#define acpi_handle_alert(handle, fmt, ...)             \
    acpi_handle_printk(KERN_ALERT, handle, fmt, ##__VA_ARGS__)
#define acpi_handle_crit(handle, fmt, ...)              \
    acpi_handle_printk(KERN_CRIT, handle, fmt, ##__VA_ARGS__)
#define acpi_handle_err(handle, fmt, ...)               \
    acpi_handle_printk(KERN_ERR, handle, fmt, ##__VA_ARGS__)
#define acpi_handle_warn(handle, fmt, ...)              \
    acpi_handle_printk(KERN_WARNING, handle, fmt, ##__VA_ARGS__)
#define acpi_handle_notice(handle, fmt, ...)                \
    acpi_handle_printk(KERN_NOTICE, handle, fmt, ##__VA_ARGS__)
#define acpi_handle_info(handle, fmt, ...)              \
    acpi_handle_printk(KERN_INFO, handle, fmt, ##__VA_ARGS__)



#define acpi_handle_debug(handle, fmt, ...)             \
({                                  \
    0;                              \
})



struct acpi_gpio_params
{
    unsigned int crs_entry_index;
    unsigned int line_index;
    bool active_low;
};




struct acpi_gpio_mapping
{
    const char *name;
    const struct acpi_gpio_params *data;
    unsigned int size;
};



static inline int acpi_dev_add_driver_gpios(struct acpi_device *adev, const struct acpi_gpio_mapping *gpios)
{
    return -ENXIO;
}


static inline void acpi_dev_remove_driver_gpios(struct acpi_device *adev) 
{
	
}

static inline int devm_acpi_dev_add_driver_gpios(struct device *dev, const struct acpi_gpio_mapping *gpios)
{
    return -ENXIO;
}


static inline void devm_acpi_dev_remove_driver_gpios(struct device *dev) 
{
	
}

static inline int acpi_dev_gpio_irq_get(struct acpi_device *adev, int index)
{
    return -ENXIO;
}


/* Device properties */

#define MAX_ACPI_REFERENCE_ARGS 8

struct acpi_reference_args
{
    struct acpi_device *adev;
    size_t nargs;
    u64 args[MAX_ACPI_REFERENCE_ARGS];
};




static inline int acpi_dev_get_property(struct acpi_device *adev, const char *name, acpi_object_type type, const union acpi_object **obj)
{
    return -ENXIO;
}


static inline int __acpi_node_get_property_reference(struct fwnode_handle *fwnode, const char *name, size_t index, size_t num_args, struct acpi_reference_args *args)
{
    return -ENXIO;
}


static inline int acpi_node_get_property_reference(struct fwnode_handle *fwnode, const char *name, size_t index, struct acpi_reference_args *args)
{
    return -ENXIO;
}


static inline int acpi_node_prop_get(struct fwnode_handle *fwnode,  const char *propname, void **valptr)
{
    return -ENXIO;
}

static inline int acpi_dev_prop_get(struct acpi_device *adev, const char *propname, void **valptr)
{
    return -ENXIO;
}



static inline int acpi_dev_prop_read_single(struct acpi_device *adev, const char *propname, enum dev_prop_type proptype, void *val)
{
    return -ENXIO;
}


static inline int acpi_node_prop_read(struct fwnode_handle *fwnode, const char *propname, enum dev_prop_type proptype, void *val, size_t nval)
{
    return -ENXIO;
}

static inline int acpi_dev_prop_read(struct acpi_device *adev, const char *propname, enum dev_prop_type proptype, void *val, size_t nval)
{
    return -ENXIO;
}



static inline struct fwnode_handle * acpi_get_next_subnode(struct fwnode_handle *fwnode, struct fwnode_handle *child)
{
    return NULL;
}

static inline struct fwnode_handle * acpi_node_get_parent(struct fwnode_handle *fwnode)
{
    return NULL;
}

static inline struct fwnode_handle * acpi_graph_get_next_endpoint(struct fwnode_handle *fwnode,
                             struct fwnode_handle *prev)
{
    return ERR_PTR(-ENXIO);
}

static inline int acpi_graph_get_remote_endpoint(struct fwnode_handle *fwnode, struct fwnode_handle **remote, struct fwnode_handle **port, struct fwnode_handle **endpoint)
{
    return -ENXIO;
}



#define ACPI_DECLARE_PROBE_ENTRY(table, name, table_id, subtable, valid, data, fn) \
    static const void * __acpi_table_##name[]           \
        __attribute__((unused))                 \
         = { (void *) table_id,                 \
             (void *) subtable,                 \
             (void *) valid,                    \
             (void *) fn,                   \
             (void *) data }



#define acpi_probe_device_table(t)  ({ int __r = 0; __r;})



static inline void acpi_table_upgrade(void) 
{ 
	
}



static inline bool acpi_has_watchdog(void)
{
    return false;
}



static inline int parse_spcr(bool earlycon)
{
    return 0;
}


#if IS_ENABLED(CONFIG_ACPI_GENERIC_GSI)
int acpi_irq_get(acpi_handle handle, unsigned int index, struct resource *res);
#else
static inline int acpi_irq_get(acpi_handle handle, unsigned int index, struct resource *res)
{
    return -EINVAL;
}
#endif



#endif




