


/*
 * livepatch.h - Kernel Live Patching Core
 *
 * Copyright (C) 2014 Seth Jennings <sjenning@redhat.com>
 * Copyright (C) 2014 SUSE
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _LINUX_LIVEPATCH_H_
#define _LINUX_LIVEPATCH_H_



#include <linux/module.h>
#include <linux/ftrace.h>
#include <linux/completion.h>



static inline int klp_module_coming(struct module *mod)
{
    return 0;
}


static inline void klp_module_going(struct module *mod) 
{
	
}


static inline bool klp_patch_pending(struct task_struct *task)
{
    return false;
}


static inline void klp_update_patch_state(struct task_struct *task) 
{
	
}


static inline void klp_copy_process(struct task_struct *child) 
{
	
}



#endif



