


#ifndef _LINUX_KERNEL_VTIME_H
#define _LINUX_KERNEL_VTIME_H



#include <linux/context_tracking_state.h>


struct task_struct;



/*
 * vtime_accounting_cpu_enabled() definitions/declarations
 */
static inline bool vtime_accounting_cpu_enabled(void)
{
    return false;
}



/*
 * Common vtime APIs
 */


static inline void vtime_task_switch(struct task_struct *prev)
{
		
}

static inline void vtime_account_system(struct task_struct *tsk)
{
		
}




static inline void vtime_user_enter(struct task_struct *tsk)
{
		
}

static inline void vtime_user_exit(struct task_struct *tsk)
{
	
}

static inline void vtime_guest_enter(struct task_struct *tsk)
{
		
}

static inline void vtime_guest_exit(struct task_struct *tsk)
{
		
}

static inline void vtime_init_idle(struct task_struct *tsk, int cpu)
{
	
}




static inline void vtime_account_irq_enter(struct task_struct *tsk)
{	
	
}

static inline void vtime_account_irq_exit(struct task_struct *tsk)
{
		
}

static inline void vtime_flush(struct task_struct *tsk)
{
		
}



static inline void irqtime_account_irq(struct task_struct *tsk) 
{
	
}


static inline void account_irq_enter_time(struct task_struct *tsk)
{
    vtime_account_irq_enter(tsk);
    irqtime_account_irq(tsk);
}


static inline void account_irq_exit_time(struct task_struct *tsk)
{
    vtime_account_irq_exit(tsk);
    irqtime_account_irq(tsk);
}


#endif



