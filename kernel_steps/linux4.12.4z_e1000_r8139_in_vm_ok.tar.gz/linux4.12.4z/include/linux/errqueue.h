


#ifndef _LINUX_ERRQUEUE_H
#define _LINUX_ERRQUEUE_H 1


#include <net/ip.h>
#include <uapi/linux/errqueue.h>


#define SKB_EXT_ERR(skb) ((struct sock_exterr_skb *) ((skb)->cb))



struct sock_exterr_skb
{
    union
    {
        struct inet_skb_parm    h4;
    } header;
    struct sock_extended_err    ee;
    u16             addr_offset;
    __be16              port;
    u8              opt_stats: 1,
    unused: 7;
};

#endif



