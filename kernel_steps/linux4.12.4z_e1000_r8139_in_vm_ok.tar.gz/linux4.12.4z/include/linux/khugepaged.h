

#ifndef _LINUX_KHUGEPAGED_H
#define _LINUX_KHUGEPAGED_H

#include <linux/sched/coredump.h>



static inline int khugepaged_fork(struct mm_struct *mm, struct mm_struct *oldmm)
{
    return 0;
}


static inline void khugepaged_exit(struct mm_struct *mm)
{
	
}


static inline int khugepaged_enter(struct vm_area_struct *vma,
                                   unsigned long vm_flags)
{
    return 0;
}


static inline int khugepaged_enter_vma_merge(struct vm_area_struct *vma, unsigned long vm_flags)
{
    return 0;
}


#endif



