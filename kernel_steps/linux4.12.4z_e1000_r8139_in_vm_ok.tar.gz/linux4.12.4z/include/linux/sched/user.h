

#ifndef _LINUX_SCHED_USER_H
#define _LINUX_SCHED_USER_H


#include <linux/uidgid.h>
#include <linux/atomic.h>


struct key;



/*
 * Some day this will be a full-fledged user tracking system..
 */
struct user_struct
{
    atomic_t __count;   /* reference count */
    atomic_t processes; /* How many processes does this user have? */
    atomic_t sigpending;    /* How many pending signals does this user have? */

#ifdef CONFIG_EPOLL
    atomic_long_t epoll_watches; /* The number of file descriptors currently watched */
#endif


    unsigned long locked_shm; /* How many pages of mlocked shm ? */
    unsigned long unix_inflight;    /* How many files in flight in unix sockets */
    atomic_long_t pipe_bufs;  /* how many pages are allocated in pipe buffers */


    /* Hash table maintenance information */
    struct hlist_node uidhash_node;
    kuid_t uid;
};


extern int uids_sysfs_init(void);

extern struct user_struct *find_user(kuid_t);


extern struct user_struct root_user;


#define INIT_USER (&root_user)


/* per-UID process charging. */
extern struct user_struct * alloc_uid(kuid_t);
static inline struct user_struct *get_uid(struct user_struct *u)
{
    atomic_inc(&u->__count);
    return u;
}


extern void free_uid(struct user_struct *);


#endif



