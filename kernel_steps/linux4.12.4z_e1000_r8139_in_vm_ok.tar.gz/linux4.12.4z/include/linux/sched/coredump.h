

#ifndef _LINUX_SCHED_COREDUMP_H
#define _LINUX_SCHED_COREDUMP_H


#include <linux/mm_types.h>

#define SUID_DUMP_DISABLE   0   /* No setuid dumping */
#define SUID_DUMP_USER      1   /* Dump as user of process */
#define SUID_DUMP_ROOT      2   /* Dump as root */



/* mm flags */

/* for SUID_DUMP_* above */
#define MMF_DUMPABLE_BITS 2
#define MMF_DUMPABLE_MASK ((1 << MMF_DUMPABLE_BITS) - 1)


extern void set_dumpable(struct mm_struct *mm, int value);


/*
 * This returns the actual value of the suid_dumpable flag. For things
 * that are using this for checking for privilege transitions, it must
 * test against SUID_DUMP_USER rather than treating it as a boolean
 * value.
 */
static inline int __get_dumpable(unsigned long mm_flags)
{
    return mm_flags & MMF_DUMPABLE_MASK;
}


static inline int get_dumpable(struct mm_struct *mm)
{
    return __get_dumpable(mm->flags);
}



/* coredump filter bits */
#define MMF_DUMP_ANON_PRIVATE   2
#define MMF_DUMP_ANON_SHARED    3
#define MMF_DUMP_MAPPED_PRIVATE 4
#define MMF_DUMP_MAPPED_SHARED  5
#define MMF_DUMP_ELF_HEADERS    6
#define MMF_DUMP_HUGETLB_PRIVATE 7
#define MMF_DUMP_HUGETLB_SHARED  8
#define MMF_DUMP_DAX_PRIVATE    9
#define MMF_DUMP_DAX_SHARED 10

#define MMF_DUMP_FILTER_SHIFT   MMF_DUMPABLE_BITS
#define MMF_DUMP_FILTER_BITS    9
#define MMF_DUMP_FILTER_MASK \
    (((1 << MMF_DUMP_FILTER_BITS) - 1) << MMF_DUMP_FILTER_SHIFT)
#define MMF_DUMP_FILTER_DEFAULT \
    ((1 << MMF_DUMP_ANON_PRIVATE) | (1 << MMF_DUMP_ANON_SHARED) |\
     (1 << MMF_DUMP_HUGETLB_PRIVATE) | MMF_DUMP_MASK_DEFAULT_ELF)


#define MMF_DUMP_MASK_DEFAULT_ELF  0



/* leave room for more dump flags */
#define MMF_VM_MERGEABLE    16  /* KSM may merge identical pages */
#define MMF_VM_HUGEPAGE     17  /* set when VM_HUGEPAGE is set on vma */


/*
 * This one-shot flag is dropped due to necessity of changing exe once again
 * on NFS restore
 */
//#define MMF_EXE_FILE_CHANGED  18  /* see prctl_set_mm_exe_file() */



#define MMF_HAS_UPROBES     19  /* has uprobes */
#define MMF_RECALC_UPROBES  20  /* MMF_HAS_UPROBES can be wrong */
#define MMF_OOM_SKIP        21  /* mm is of no interest for the OOM killer */
#define MMF_UNSTABLE        22  /* mm is unstable for copy_from_user */
#define MMF_HUGE_ZERO_PAGE  23      /* mm has ever used the global huge zero page */



#define MMF_INIT_MASK       (MMF_DUMPABLE_MASK | MMF_DUMP_FILTER_MASK)


#endif


