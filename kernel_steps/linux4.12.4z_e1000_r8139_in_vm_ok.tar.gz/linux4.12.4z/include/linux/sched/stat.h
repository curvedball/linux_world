

#ifndef _LINUX_SCHED_STAT_H
#define _LINUX_SCHED_STAT_H



#include <linux/percpu.h>



/*
 * Various counters maintained by the scheduler and fork(),
 * exposed via /proc, sys.c or used by drivers via these APIs.
 *
 * ( Note that all these values are aquired without locking,
 *   so they can only be relied on in narrow circumstances. )
 */

extern unsigned long total_forks;
extern int nr_threads;


DECLARE_PER_CPU(unsigned long, process_counts);


extern int nr_processes(void);
extern unsigned long nr_running(void);
extern bool single_task_running(void);
extern unsigned long nr_iowait(void);
extern unsigned long nr_iowait_cpu(int cpu);
extern void get_iowait_load(unsigned long *nr_waiters, unsigned long *load);


static inline int sched_info_on(void)
{
    return 0;
}



#endif



