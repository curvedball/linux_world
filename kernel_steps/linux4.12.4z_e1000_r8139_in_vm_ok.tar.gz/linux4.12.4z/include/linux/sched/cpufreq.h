


#ifndef _LINUX_SCHED_CPUFREQ_H
#define _LINUX_SCHED_CPUFREQ_H


#include <linux/types.h>


/*
 * Interface between cpufreq drivers and the scheduler:
 */

#define SCHED_CPUFREQ_RT    	(1U << 0)
#define SCHED_CPUFREQ_DL    	(1U << 1)
#define SCHED_CPUFREQ_IOWAIT    (1U << 2)

#define SCHED_CPUFREQ_RT_DL (SCHED_CPUFREQ_RT | SCHED_CPUFREQ_DL)



#endif



