


#ifndef _LINUX_CONTEXT_TRACKING_H
#define _LINUX_CONTEXT_TRACKING_H


#include <linux/sched.h>
#include <linux/vtime.h>
#include <linux/context_tracking_state.h>
#include <asm/ptrace.h>



static inline void user_enter(void) 
{
	
}


static inline void user_exit(void) 
{

	
}


static inline void user_enter_irqoff(void) 
{

	
}


static inline void user_exit_irqoff(void) 
{

	
}


static inline enum ctx_state exception_enter(void)
{
    return 0;
}


static inline void exception_exit(enum ctx_state prev_ctx) 
{
	
}


static inline enum ctx_state ct_state(void)
{
    return CONTEXT_DISABLED;
}



#define CT_WARN_ON(cond) WARN_ON(context_tracking_is_enabled() && (cond))


static inline void context_tracking_init(void) 
{
	
}




static inline void guest_enter_irqoff(void)
{
    /*
     * This is running in ioctl context so its safe
     * to assume that it's the stime pending cputime
     * to flush.
     */
    vtime_account_system(current);
    current->flags |= PF_VCPU;
    rcu_virt_note_context_switch(smp_processor_id());
}



static inline void guest_exit_irqoff(void)
{
    /* Flush the guest cputime we spent on the guest */
    vtime_account_system(current);
    current->flags &= ~PF_VCPU;
}


static inline void guest_enter(void)
{
    unsigned long flags;

    local_irq_save(flags);
    guest_enter_irqoff();
    local_irq_restore(flags);
}


static inline void guest_exit(void)
{
    unsigned long flags;

    local_irq_save(flags);
    guest_exit_irqoff();
    local_irq_restore(flags);
}


#endif


