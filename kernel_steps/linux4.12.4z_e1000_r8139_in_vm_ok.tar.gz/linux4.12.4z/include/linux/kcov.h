


#ifndef _LINUX_KCOV_H
#define _LINUX_KCOV_H

#include <uapi/linux/kcov.h>



struct task_struct;

static inline void kcov_task_init(struct task_struct *t) 
{
	
}

static inline void kcov_task_exit(struct task_struct *t) 
{
	
}


#endif



