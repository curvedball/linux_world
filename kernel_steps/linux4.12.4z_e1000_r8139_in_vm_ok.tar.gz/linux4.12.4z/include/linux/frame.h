


#ifndef _LINUX_FRAME_H
#define _LINUX_FRAME_H


#define STACK_FRAME_NON_STANDARD(func)



#endif


