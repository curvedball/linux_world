
#ifndef _FIPS_H
#define _FIPS_H


#define fips_enabled 0


#endif


