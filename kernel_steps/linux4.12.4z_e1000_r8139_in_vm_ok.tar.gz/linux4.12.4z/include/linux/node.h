

/*
 * include/linux/node.h - generic node definition
 *
 * This is mainly for topological representation. We define the
 * basic 'struct node' here, which can be embedded in per-arch
 * definitions of processors.
 *
 * Basic handling of the devices is done in drivers/base/node.c
 * and system devices are handled in drivers/base/sys.c.
 *
 * Nodes are exported via driverfs in the class/node/devices/
 * directory.
 */
#ifndef _LINUX_NODE_H_
#define _LINUX_NODE_H_


#include <linux/device.h>
#include <linux/cpumask.h>
#include <linux/workqueue.h>


struct node
{
    struct device   dev;
};


struct memory_block;
extern struct node *node_devices[];


typedef  void (*node_registration_func_t)(struct node *);


extern void unregister_node(struct node *node);

static inline int register_one_node(int nid)
{
    return 0;
}


static inline int unregister_one_node(int nid)
{
    return 0;
}


static inline int register_cpu_under_node(unsigned int cpu, unsigned int nid)
{
    return 0;
}


static inline int unregister_cpu_under_node(unsigned int cpu, unsigned int nid)
{
    return 0;
}


static inline int register_mem_sect_under_node(struct memory_block *mem_blk, int nid)
{
    return 0;
}


static inline int unregister_mem_sect_under_nodes(struct memory_block *mem_blk, unsigned long phys_index)
{
    return 0;
}

static inline void register_hugetlbfs_with_node(node_registration_func_t reg, node_registration_func_t unreg)
{
	
}


#define to_node(device) container_of(device, struct node, dev)


#endif


