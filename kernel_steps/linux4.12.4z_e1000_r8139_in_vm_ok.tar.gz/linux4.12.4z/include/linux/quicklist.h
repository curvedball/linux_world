

#ifndef LINUX_QUICKLIST_H
#define LINUX_QUICKLIST_H



/*
 * Fast allocations and disposal of pages. Pages must be in the condition
 * as needed after allocation when they are freed. Per cpu lists of pages
 * are kept that only contain node local pages.
 *
 * (C) 2007, SGI. Christoph Lameter <cl@linux.com>
 */
#include <linux/kernel.h>
#include <linux/gfp.h>
#include <linux/percpu.h>



static inline unsigned long quicklist_total_size(void)
{
    return 0;
}



#endif


