


#ifndef __LINUX_STACKTRACE_H
#define __LINUX_STACKTRACE_H


#include <linux/types.h>


struct task_struct;
struct pt_regs;



#define save_stack_trace(trace)            				do { } while (0)
#define save_stack_trace_tsk(tsk, trace)       			do { } while (0)
#define save_stack_trace_user(trace)           			do { } while (0)
#define print_stack_trace(trace, spaces)       			do { } while (0)
#define snprint_stack_trace(buf, size, trace, spaces)  	do { } while (0)


#define save_stack_trace_tsk_reliable(tsk, trace)  		({ -ENOSYS; })



#endif




