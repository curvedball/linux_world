


/* include/net/dsfield.h - Manipulation of the Differentiated Services field */

/* Written 1998-2000 by Werner Almesberger, EPFL ICA */


#ifndef __NET_DSFIELD_H
#define __NET_DSFIELD_H


#include <linux/types.h>
#include <linux/ip.h>


#include <asm/byteorder.h>


static inline __u8 ipv4_get_dsfield(const struct iphdr *iph)
{
    return iph->tos;
}


static inline void ipv4_change_dsfield(struct iphdr *iph, __u8 mask,
                                       __u8 value)
{
    __u32 check = ntohs((__force __be16) iph->check);
    __u8 dsfield;

    dsfield = (iph->tos & mask) | value;
    check += iph->tos;

    if((check + 1) >> 16)
    {
        check = (check + 1) & 0xffff;
    }

    check -= dsfield;
    check += check >> 16; /* adjust carry */
    iph->check = (__force __sum16) htons(check);
    iph->tos = dsfield;
}


#endif



