


#ifndef __NET_WEXT_H
#define __NET_WEXT_H



struct net;


static inline int wext_handle_ioctl(struct net *net, struct iwreq *iwr, unsigned int cmd,
                                    void __user *arg)
{
    return -EINVAL;
}


static inline int compat_wext_handle_ioctl(struct net *net, unsigned int cmd, unsigned long arg)
{
    return -EINVAL;
}



static inline int wext_proc_init(struct net *net)
{
    return 0;
}


static inline void wext_proc_exit(struct net *net)
{
    return;
}



#define ioctl_private_call NULL
#define compat_private_call NULL



#endif



