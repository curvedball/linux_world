

/*
 * cls_cgroup.h         Control Group Classifier
 *
 * Authors: Thomas Graf <tgraf@suug.ch>
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 */

#ifndef _NET_CLS_CGROUP_H
#define _NET_CLS_CGROUP_H


#include <linux/cgroup.h>
#include <linux/hardirq.h>
#include <linux/rcupdate.h>
#include <net/sock.h>
#include <net/inet_sock.h>


static inline void sock_update_classid(struct sock_cgroup_data *skcd)
{
	
}


static inline u32 task_get_classid(const struct sk_buff *skb)
{
    return 0;
}

#endif


