

#ifndef NET_COMPAT_H
#define NET_COMPAT_H


struct sock;


/*
 * To avoid compiler warnings:
 */
#define compat_msghdr   msghdr
#define compat_mmsghdr  mmsghdr


int get_compat_msghdr(struct msghdr *, struct compat_msghdr __user *, struct sockaddr __user **, struct iovec **);


asmlinkage long compat_sys_sendmsg(int, struct compat_msghdr __user *, unsigned int);
asmlinkage long compat_sys_sendmmsg(int, struct compat_mmsghdr __user *, unsigned int, unsigned int);
asmlinkage long compat_sys_recvmsg(int, struct compat_msghdr __user *, unsigned int);
asmlinkage long compat_sys_recvmmsg(int, struct compat_mmsghdr __user *, unsigned int, unsigned int, struct compat_timespec __user *);
asmlinkage long compat_sys_getsockopt(int, int, int, char __user *, int __user *);



int put_cmsg_compat(struct msghdr*, int, int, int, void *);
int cmsghdr_from_user_compat_to_kern(struct msghdr *, struct sock *, unsigned char *, int);


int compat_mc_setsockopt(struct sock *, int, int, char __user *, unsigned int, int (*)(struct sock *, int, int, char __user *, unsigned int));
int compat_mc_getsockopt(struct sock *, int, int, char __user *, int __user *, int (*)(struct sock *, int, int, char __user *, int __user *));



#endif




