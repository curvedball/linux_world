

#ifndef __ACPI_REBOOT_H
#define __ACPI_REBOOT_H


static inline void acpi_reboot(void) 
{ 
	
}


#endif


